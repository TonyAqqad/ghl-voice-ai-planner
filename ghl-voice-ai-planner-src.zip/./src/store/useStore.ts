import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { 
  VoiceAgent, 
  Workflow, 
  PhoneNumber, 
  CustomField, 
  CustomValue, 
  Integration, 
  ComplianceSettings, 
  Template,
  AnalyticsSnapshot,
  AppState,
  Notification
} from '../types';

interface GHLStore {
  // App State
  appState: AppState;
  
  // Data Collections
  voiceAgents: VoiceAgent[];
  workflows: Workflow[];
  phoneNumbers: PhoneNumber[];
  customFields: CustomField[];
  customValues: CustomValue[];
  integrations: Integration[];
  compliance: ComplianceSettings | null;
  templates: Template[];
  analytics: AnalyticsSnapshot[];
  
  // UI State
  currentModule: string;
  darkMode: boolean;
  sidebarOpen: boolean;
  notifications: Notification[];
  
  // Actions
  setCurrentModule: (module: string) => void;
  toggleDarkMode: () => void;
  toggleSidebar: () => void;
  addNotification: (notification: Omit<Notification, 'id' | 'timestamp'>) => void;
  removeNotification: (id: string) => void;
  markNotificationRead: (id: string) => void;
  
  // Voice Agents
  addVoiceAgent: (agent: VoiceAgent) => void;
  updateVoiceAgent: (id: string, updates: Partial<VoiceAgent>) => void;
  deleteVoiceAgent: (id: string) => void;
  getVoiceAgent: (id: string) => VoiceAgent | undefined;
  
  // Workflows
  addWorkflow: (workflow: Workflow) => void;
  updateWorkflow: (id: string, updates: Partial<Workflow>) => void;
  deleteWorkflow: (id: string) => void;
  getWorkflow: (id: string) => Workflow | undefined;
  
  // Phone Numbers
  addPhoneNumber: (number: PhoneNumber) => void;
  updatePhoneNumber: (id: string, updates: Partial<PhoneNumber>) => void;
  deletePhoneNumber: (id: string) => void;
  
  // Custom Fields
  addCustomField: (field: CustomField) => void;
  updateCustomField: (id: string, updates: Partial<CustomField>) => void;
  deleteCustomField: (id: string) => void;
  
  // Custom Values
  addCustomValue: (value: CustomValue) => void;
  updateCustomValue: (id: string, updates: Partial<CustomValue>) => void;
  deleteCustomValue: (id: string) => void;
  
  // Integrations
  addIntegration: (integration: Integration) => void;
  updateIntegration: (id: string, updates: Partial<Integration>) => void;
  deleteIntegration: (id: string) => void;
  
  // Compliance
  updateCompliance: (settings: ComplianceSettings) => void;
  
  // Templates
  addTemplate: (template: Template) => void;
  updateTemplate: (id: string, updates: Partial<Template>) => void;
  deleteTemplate: (id: string) => void;
  
  // Analytics
  addAnalytics: (snapshot: AnalyticsSnapshot) => void;
  
  // Bulk Operations
  importData: (data: Partial<GHLStore>) => void;
  exportData: () => Partial<GHLStore>;
  clearAllData: () => void;
}

export const useStore = create<GHLStore>()(
  persist(
    (set, get) => ({
      // Initial State
      appState: {
        currentModule: 'voice-agents',
        darkMode: false,
        sidebarOpen: true,
        notifications: []
      },
      
      voiceAgents: [],
      workflows: [],
      phoneNumbers: [],
      customFields: [],
      customValues: [],
      integrations: [],
      compliance: null,
      templates: [],
      analytics: [],
      
      // UI State
      currentModule: 'voice-agents',
      darkMode: false,
      sidebarOpen: true,
      notifications: [],
      
      // Actions
      setCurrentModule: (module) => set({ currentModule: module }),
      toggleDarkMode: () => set((state) => ({ 
        darkMode: !state.darkMode,
        appState: { ...state.appState, darkMode: !state.darkMode }
      })),
      toggleSidebar: () => set((state) => ({ 
        sidebarOpen: !state.sidebarOpen,
        appState: { ...state.appState, sidebarOpen: !state.sidebarOpen }
      })),
      
      addNotification: (notification) => {
        const newNotification: Notification = {
          ...notification,
          id: Date.now().toString(),
          timestamp: new Date().toISOString(),
          read: false
        };
        set((state) => ({
          notifications: [...state.notifications, newNotification],
          appState: {
            ...state.appState,
            notifications: [...state.appState.notifications, newNotification]
          }
        }));
      },
      
      removeNotification: (id) => set((state) => ({
        notifications: state.notifications.filter(n => n.id !== id),
        appState: {
          ...state.appState,
          notifications: state.appState.notifications.filter(n => n.id !== id)
        }
      })),
      
      markNotificationRead: (id) => set((state) => ({
        notifications: state.notifications.map(n => 
          n.id === id ? { ...n, read: true } : n
        ),
        appState: {
          ...state.appState,
          notifications: state.appState.notifications.map(n => 
            n.id === id ? { ...n, read: true } : n
          )
        }
      })),
      
      // Voice Agents
      addVoiceAgent: (agent) => set((state) => ({
        voiceAgents: [...state.voiceAgents, agent]
      })),
      
      updateVoiceAgent: (id, updates) => set((state) => ({
        voiceAgents: state.voiceAgents.map(agent =>
          agent.id === id ? { ...agent, ...updates, updatedAt: new Date().toISOString() } : agent
        )
      })),
      
      deleteVoiceAgent: (id) => set((state) => ({
        voiceAgents: state.voiceAgents.filter(agent => agent.id !== id)
      })),
      
      getVoiceAgent: (id) => get().voiceAgents.find(agent => agent.id === id),
      
      // Workflows
      addWorkflow: (workflow) => set((state) => ({
        workflows: [...state.workflows, workflow]
      })),
      
      updateWorkflow: (id, updates) => set((state) => ({
        workflows: state.workflows.map(workflow =>
          workflow.id === id ? { ...workflow, ...updates, updatedAt: new Date().toISOString() } : workflow
        )
      })),
      
      deleteWorkflow: (id) => set((state) => ({
        workflows: state.workflows.filter(workflow => workflow.id !== id)
      })),
      
      getWorkflow: (id) => get().workflows.find(workflow => workflow.id === id),
      
      // Phone Numbers
      addPhoneNumber: (number) => set((state) => ({
        phoneNumbers: [...state.phoneNumbers, number]
      })),
      
      updatePhoneNumber: (id, updates) => set((state) => ({
        phoneNumbers: state.phoneNumbers.map(number =>
          number.id === id ? { ...number, ...updates } : number
        )
      })),
      
      deletePhoneNumber: (id) => set((state) => ({
        phoneNumbers: state.phoneNumbers.filter(number => number.id !== id)
      })),
      
      // Custom Fields
      addCustomField: (field) => set((state) => ({
        customFields: [...state.customFields, field]
      })),
      
      updateCustomField: (id, updates) => set((state) => ({
        customFields: state.customFields.map(field =>
          field.id === id ? { ...field, ...updates } : field
        )
      })),
      
      deleteCustomField: (id) => set((state) => ({
        customFields: state.customFields.filter(field => field.id !== id)
      })),
      
      // Custom Values
      addCustomValue: (value) => set((state) => ({
        customValues: [...state.customValues, value]
      })),
      
      updateCustomValue: (id, updates) => set((state) => ({
        customValues: state.customValues.map(value =>
          value.id === id ? { ...value, ...updates } : value
        )
      })),
      
      deleteCustomValue: (id) => set((state) => ({
        customValues: state.customValues.filter(value => value.id !== id)
      })),
      
      // Integrations
      addIntegration: (integration) => set((state) => ({
        integrations: [...state.integrations, integration]
      })),
      
      updateIntegration: (id, updates) => set((state) => ({
        integrations: state.integrations.map(integration =>
          integration.id === id ? { ...integration, ...updates } : integration
        )
      })),
      
      deleteIntegration: (id) => set((state) => ({
        integrations: state.integrations.filter(integration => integration.id !== id)
      })),
      
      // Compliance
      updateCompliance: (settings) => set({ compliance: settings }),
      
      // Templates
      addTemplate: (template) => set((state) => ({
        templates: [...state.templates, template]
      })),
      
      updateTemplate: (id, updates) => set((state) => ({
        templates: state.templates.map(template =>
          template.id === id ? { ...template, ...updates } : template
        )
      })),
      
      deleteTemplate: (id) => set((state) => ({
        templates: state.templates.filter(template => template.id !== id)
      })),
      
      // Analytics
      addAnalytics: (snapshot) => set((state) => ({
        analytics: [...state.analytics, snapshot]
      })),
      
      // Bulk Operations
      importData: (data) => set((state) => ({
        ...state,
        ...data
      })),
      
      exportData: () => {
        const state = get();
        return {
          voiceAgents: state.voiceAgents,
          workflows: state.workflows,
          phoneNumbers: state.phoneNumbers,
          customFields: state.customFields,
          customValues: state.customValues,
          integrations: state.integrations,
          compliance: state.compliance,
          templates: state.templates,
          analytics: state.analytics
        };
      },
      
      clearAllData: () => set({
        voiceAgents: [],
        workflows: [],
        phoneNumbers: [],
        customFields: [],
        customValues: [],
        integrations: [],
        compliance: null,
        templates: [],
        analytics: []
      })
    }),
    {
      name: 'ghl-voice-ai-planner',
      partialize: (state) => ({
        voiceAgents: state.voiceAgents,
        workflows: state.workflows,
        phoneNumbers: state.phoneNumbers,
        customFields: state.customFields,
        customValues: state.customValues,
        integrations: state.integrations,
        compliance: state.compliance,
        templates: state.templates,
        analytics: state.analytics,
        darkMode: state.darkMode
      })
    }
  )
);


