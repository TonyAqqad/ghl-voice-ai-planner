import React from 'react';
import { Plug, Plus } from 'lucide-react';

const IntegrationSetup: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Integration Setup</h1>
          <p className="text-muted-foreground mt-2">
            Connect external services and configure API integrations
          </p>
        </div>
        <button className="btn btn-primary flex items-center space-x-2">
          <Plus className="w-4 h-4" />
          <span>Add Integration</span>
        </button>
      </div>
      
      <div className="card">
        <div className="card-content text-center py-12">
          <Plug className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">
            Integration Configuration
          </h3>
          <p className="text-muted-foreground">
            Set up connections to OpenAI, ElevenLabs, Twilio, and other services
          </p>
        </div>
      </div>
    </div>
  );
};

export default IntegrationSetup;
