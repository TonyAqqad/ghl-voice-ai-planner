import React, { useState, useEffect } from 'react';
import { 
  DollarSign, 
  TrendingDown, 
  TrendingUp, 
  Target, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  RefreshCw, 
  Play, 
  Pause, 
  Settings, 
  Download, 
  Upload, 
  Save, 
  Edit, 
  Trash2, 
  Plus, 
  Minus, 
  ChevronDown, 
  ChevronRight, 
  Eye, 
  EyeOff, 
  Filter, 
  Search, 
  SortAsc, 
  SortDesc, 
  MoreHorizontal, 
  Star, 
  ThumbsUp, 
  ThumbsDown, 
  Heart, 
  Smile, 
  Frown, 
  Meh, 
  Award, 
  Trophy, 
  Medal, 
  Crown, 
  Flame, 
  Lightning, 
  Rocket, 
  Shield, 
  Lock, 
  Unlock, 
  Key, 
  Wrench, 
  Cog, 
  Sliders, 
  ToggleLeft, 
  ToggleRight, 
  Switch, 
  Power, 
  PowerOff, 
  Battery, 
  BatteryCharging, 
  Wifi, 
  WifiOff, 
  Signal, 
  SignalZero, 
  SignalOne, 
  SignalTwo, 
  SignalThree, 
  SignalFour, 
  SignalFive,
  MessageSquare,
  Mic,
  Headphones,
  Volume2,
  VolumeX,
  SkipForward,
  SkipBack,
  RotateCcw,
  BarChart3,
  LineChart,
  PieChart,
  Activity,
  Clock,
  Users,
  Phone,
  Bot,
  Brain,
  Database,
  Server,
  Globe,
  FileText,
  FileCheck,
  FileX,
  FileAlert,
  FileLock,
  FileShield,
  FileSearch,
  FileCode,
  FileImage,
  FileVideo,
  FileAudio,
  FileArchive,
  FileSpreadsheet,
  FilePresentation,
  FilePdf,
  FileWord,
  FileExcel,
  FilePowerpoint,
  FileZip,
  FileRar,
  File7z,
  FileTar,
  FileGz,
  FileBz2,
  FileXz,
  FileLz4,
  FileZstd,
  FileCab,
  FileIso,
  FileDmg,
  FileImg,
  FileVhd,
  FileVdi,
  FileVmdk,
  FileOva,
  FileOvf,
  FileVagrant,
  FileDocker,
  FileKubernetes,
  FileTerraform,
  FileAnsible,
  FileChef,
  FilePuppet,
  FileSalt,
  FileConsul,
  FileVault,
  FileNomad,
  FileDockerCompose,
  FileKustomize,
  FileHelm,
  FileIstio,
  FileLinkerd,
  FileEnvoy,
  FileNginx,
  FileApache,
  FileIis,
  FileTomcat,
  FileJetty,
  FileWildfly,
  FileWeblogic,
  FileWebsphere,
  FileGlassfish,
  FileJboss,
  FileResin,
  FileGeronimo,
  FileOpenliberty,
  FilePayara,
  FileTomee,
  FileWeld,
  FileDeltaspike,
  FileShiro,
  FileSpring,
  FileHibernate,
  FileMybatis,
  FileJpa,
  FileJdbc,
  FileJndi,
  FileJms,
  FileJta,
  FileJca,
  FileJaxb,
  FileJaxrs,
  FileJaxws,
  FileJsf,
  FileStruts,
  FileVaadin,
  FileGwt,
  FileWicket,
  FileTapestry,
  FileSeam,
  FileRichfaces,
  FilePrimefaces,
  FileIcefaces,
  FileOpenfaces,
  FileButterfaces,
  FileBootsfaces,
  FileOmnifaces,
  FileAngularfaces,
  FileAngular,
  FileReact,
  FileVue,
  FileSvelte,
  FileEmber,
  FileBackbone,
  FileKnockout,
  FileMithril,
  FilePreact,
  FileInferno,
  FileRiot,
  FileStencil,
  FileLit,
  FilePolymer,
  FileAurelia,
  FileMithril,
  FileHyperapp,
  FileAlpine,
  FileStimulus,
  FileTurbo,
  FileHotwire,
  FileLivewire,
  FileInertia,
  FileNext,
  FileNuxt,
  FileSapper,
  FileSveltekit,
  FileRemix,
  FileSolid,
  FileQwik,
  FileMarko,
  FileMithril,
  FileHyperapp,
  FileAlpine,
  FileStimulus,
  FileTurbo,
  FileHotwire,
  FileLivewire,
  FileInertia,
  FileNext,
  FileNuxt,
  FileSapper,
  FileSveltekit,
  FileRemix,
  FileSolid,
  FileQwik,
  FileMarko,
  Info,
  ExternalLink,
  Copy,
  Link,
  Unlink,
  Send,
  Receive,
  ArrowRight,
  ArrowLeft,
  ArrowUp,
  ArrowDown,
  RotateCw,
  RotateCcw,
  Move,
  MoveUp,
  MoveDown,
  MoveLeft,
  MoveRight,
  Maximize,
  Minimize,
  Maximize2,
  Minimize2,
  Square,
  Circle,
  Triangle,
  Hexagon,
  Octagon,
  Pentagon,
  Diamond,
  RectangleHorizontal,
  RectangleVertical,
  Ellipse,
  Oval,
  Parallelogram,
  Trapezoid,
  Rhombus,
  Kite,
  Star as StarIcon,
  Heart as HeartIcon,
  Smile as SmileIcon,
  Frown as FrownIcon,
  Meh as MehIcon,
  ThumbsUp as ThumbsUpIcon,
  ThumbsDown as ThumbsDownIcon,
  Award as AwardIcon,
  Trophy as TrophyIcon,
  Medal as MedalIcon,
  Crown as CrownIcon,
  Flame as FlameIcon,
  Lightning as LightningIcon,
  Rocket as RocketIcon,
  Shield as ShieldIcon,
  Lock as LockIcon,
  Unlock as UnlockIcon,
  Key as KeyIcon,
  Wrench as WrenchIcon,
  Cog as CogIcon,
  Sliders as SlidersIcon,
  ToggleLeft as ToggleLeftIcon,
  ToggleRight as ToggleRightIcon,
  Switch as SwitchIcon,
  Power as PowerIcon,
  PowerOff as PowerOffIcon,
  Battery as BatteryIcon,
  BatteryCharging as BatteryChargingIcon,
  Wifi as WifiIcon,
  WifiOff as WifiOffIcon,
  Signal as SignalIcon,
  SignalZero as SignalZeroIcon,
  SignalOne as SignalOneIcon,
  SignalTwo as SignalTwoIcon,
  SignalThree as SignalThreeIcon,
  SignalFour as SignalFourIcon,
  SignalFive as SignalFiveIcon,
  MessageSquare as MessageSquareIcon,
  Mic as MicIcon,
  Headphones as HeadphonesIcon,
  Volume2 as Volume2Icon,
  VolumeX as VolumeXIcon,
  Play as PlayIcon,
  Pause as PauseIcon,
  SkipForward as SkipForwardIcon,
  SkipBack as SkipBackIcon,
  RotateCcw as RotateCcwIcon,
  BarChart3 as BarChart3Icon,
  LineChart as LineChartIcon,
  PieChart as PieChartIcon,
  Activity as ActivityIcon,
  Clock as ClockIcon,
  Phone as PhoneIcon,
  Bot as BotIcon,
  Brain as BrainIcon,
  Target as TargetIcon,
  TrendingUp as TrendingUpIcon,
  TrendingDown as TrendingDownIcon,
  Database as DatabaseIcon,
  Server as ServerIcon,
  Globe as GlobeIcon,
  FileText as FileTextIcon,
  FileCheck as FileCheckIcon,
  FileX as FileXIcon,
  FileAlert as FileAlertIcon,
  FileLock as FileLockIcon,
  FileShield as FileShieldIcon,
  FileSearch as FileSearchIcon,
  FileCode as FileCodeIcon,
  FileImage as FileImageIcon,
  FileVideo as FileVideoIcon,
  FileAudio as FileAudioIcon,
  FileArchive as FileArchiveIcon,
  FileSpreadsheet as FileSpreadsheetIcon,
  FilePresentation as FilePresentationIcon,
  FilePdf as FilePdfIcon,
  FileWord as FileWordIcon,
  FileExcel as FileExcelIcon,
  FilePowerpoint as FilePowerpointIcon,
  FileZip as FileZipIcon,
  FileRar as FileRarIcon,
  File7z as File7zIcon,
  FileTar as FileTarIcon,
  FileGz as FileGzIcon,
  FileBz2 as FileBz2Icon,
  FileXz as FileXzIcon,
  FileLz4 as FileLz4Icon,
  FileZstd as FileZstdIcon,
  FileCab as FileCabIcon,
  FileIso as FileIsoIcon,
  FileDmg as FileDmgIcon,
  FileImg as FileImgIcon,
  FileVhd as FileVhdIcon,
  FileVdi as FileVdiIcon,
  FileVmdk as FileVmdkIcon,
  FileOva as FileOvaIcon,
  FileOvf as FileOvfIcon,
  FileVagrant as FileVagrantIcon,
  FileDocker as FileDockerIcon,
  FileKubernetes as FileKubernetesIcon,
  FileTerraform as FileTerraformIcon,
  FileAnsible as FileAnsibleIcon,
  FileChef as FileChefIcon,
  FilePuppet as FilePuppetIcon,
  FileSalt as FileSaltIcon,
  FileConsul as FileConsulIcon,
  FileVault as FileVaultIcon,
  FileNomad as FileNomadIcon,
  FileDockerCompose as FileDockerComposeIcon,
  FileKustomize as FileKustomizeIcon,
  FileHelm as FileHelmIcon,
  FileIstio as FileIstioIcon,
  FileLinkerd as FileLinkerdIcon,
  FileEnvoy as FileEnvoyIcon,
  FileNginx as FileNginxIcon,
  FileApache as FileApacheIcon,
  FileIis as FileIisIcon,
  FileTomcat as FileTomcatIcon,
  FileJetty as FileJettyIcon,
  FileWildfly as FileWildflyIcon,
  FileWeblogic as FileWeblogicIcon,
  FileWebsphere as FileWebsphereIcon,
  FileGlassfish as FileGlassfishIcon,
  FileJboss as FileJbossIcon,
  FileResin as FileResinIcon,
  FileGeronimo as FileGeronimoIcon,
  FileOpenliberty as FileOpenlibertyIcon,
  FilePayara as FilePayaraIcon,
  FileTomee as FileTomeeIcon,
  FileWeld as FileWeldIcon,
  FileDeltaspike as FileDeltaspikeIcon,
  FileShiro as FileShiroIcon,
  FileSpring as FileSpringIcon,
  FileHibernate as FileHibernateIcon,
  FileMybatis as FileMybatisIcon,
  FileJpa as FileJpaIcon,
  FileJdbc as FileJdbcIcon,
  FileJndi as FileJndiIcon,
  FileJms as FileJmsIcon,
  FileJta as FileJtaIcon,
  FileJca as FileJcaIcon,
  FileJaxb as FileJaxbIcon,
  FileJaxrs as FileJaxrsIcon,
  FileJaxws as FileJaxwsIcon,
  FileJsf as FileJsfIcon,
  FileStruts as FileStrutsIcon,
  FileVaadin as FileVaadinIcon,
  FileGwt as FileGwtIcon,
  FileWicket as FileWicketIcon,
  FileTapestry as FileTapestryIcon,
  FileSeam as FileSeamIcon,
  FileRichfaces as FileRichfacesIcon,
  FilePrimefaces as FilePrimefacesIcon,
  FileIcefaces as FileIcefacesIcon,
  FileOpenfaces as FileOpenfacesIcon,
  FileButterfaces as FileButterfacesIcon,
  FileBootsfaces as FileBootsfacesIcon,
  FileOmnifaces as FileOmnifacesIcon,
  FileAngularfaces as FileAngularfacesIcon,
  FileAngular as FileAngularIcon,
  FileReact as FileReactIcon,
  FileVue as FileVueIcon,
  FileSvelte as FileSvelteIcon,
  FileEmber as FileEmberIcon,
  FileBackbone as FileBackboneIcon,
  FileKnockout as FileKnockoutIcon,
  FileMithril as FileMithrilIcon,
  FilePreact as FilePreactIcon,
  FileInferno as FileInfernoIcon,
  FileRiot as FileRiotIcon,
  FileStencil as FileStencilIcon,
  FileLit as FileLitIcon,
  FilePolymer as FilePolymerIcon,
  FileAurelia as FileAureliaIcon,
  FileMithril as FileMithrilIcon,
  FileHyperapp as FileHyperappIcon,
  FileAlpine as FileAlpineIcon,
  FileStimulus as FileStimulusIcon,
  FileTurbo as FileTurboIcon,
  FileHotwire as FileHotwireIcon,
  FileLivewire as FileLivewireIcon,
  FileInertia as FileInertiaIcon,
  FileNext as FileNextIcon,
  FileNuxt as FileNuxtIcon,
  FileSapper as FileSapperIcon,
  FileSveltekit as FileSveltekitIcon,
  FileRemix as FileRemixIcon,
  FileSolid as FileSolidIcon,
  FileQwik as FileQwikIcon,
  FileMarko as FileMarkoIcon,
  FileMithril as FileMithrilIcon,
  FileHyperapp as FileHyperappIcon,
  FileAlpine as FileAlpineIcon,
  FileStimulus as FileStimulusIcon,
  FileTurbo as FileTurboIcon,
  FileHotwire as FileHotwireIcon,
  FileLivewire as FileLivewireIcon,
  FileInertia as FileInertiaIcon,
  FileNext as FileNextIcon,
  FileNuxt as FileNuxtIcon,
  FileSapper as FileSapperIcon,
  FileSveltekit as FileSveltekitIcon,
  FileRemix as FileRemixIcon,
  FileSolid as FileSolidIcon,
  FileQwik as FileQwikIcon,
  FileMarko as FileMarkoIcon
} from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';

interface CostBreakdown {
  id: string;
  category: 'voice_provider' | 'llm_provider' | 'api_calls' | 'storage' | 'bandwidth' | 'webhooks' | 'other';
  name: string;
  currentCost: number;
  projectedCost: number;
  budget: number;
  usage: number;
  limit: number;
  unit: string;
  trend: 'up' | 'down' | 'stable';
  change: number;
  lastUpdated: string;
}

interface BudgetAlert {
  id: string;
  type: 'budget_exceeded' | 'budget_warning' | 'unusual_spike' | 'cost_optimization';
  title: string;
  description: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  category: string;
  currentValue: number;
  threshold: number;
  suggestedAction: string;
  createdAt: string;
  isResolved: boolean;
}

interface OptimizationRecommendation {
  id: string;
  title: string;
  description: string;
  category: 'voice_optimization' | 'llm_optimization' | 'api_optimization' | 'storage_optimization' | 'workflow_optimization';
  potentialSavings: number;
  implementationEffort: 'low' | 'medium' | 'high';
  impact: 'low' | 'medium' | 'high';
  autoImplementable: boolean;
  steps: string[];
  estimatedSavings: number;
  paybackPeriod: number;
}

interface BudgetPlan {
  id: string;
  name: string;
  description: string;
  monthlyBudget: number;
  categories: Array<{
    category: string;
    budget: number;
    spent: number;
    remaining: number;
  }>;
  alerts: BudgetAlert[];
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

const CostOptimization: React.FC = () => {
  const { darkMode } = useStore();
  const [costBreakdowns, setCostBreakdowns] = useState<CostBreakdown[]>([]);
  const [budgetAlerts, setBudgetAlerts] = useState<BudgetAlert[]>([]);
  const [optimizationRecommendations, setOptimizationRecommendations] = useState<OptimizationRecommendation[]>([]);
  const [budgetPlans, setBudgetPlans] = useState<BudgetPlan[]>([]);
  const [selectedTimeframe, setSelectedTimeframe] = useState<'7d' | '30d' | '90d' | '1y'>('30d');
  const [activeTab, setActiveTab] = useState<'overview' | 'costs' | 'budgets' | 'optimization' | 'alerts'>('overview');

  // Sample data
  useEffect(() => {
    const sampleCostBreakdowns: CostBreakdown[] = [
      {
        id: 'cost_1',
        category: 'voice_provider',
        name: 'ElevenLabs Voice API',
        currentCost: 1250.50,
        projectedCost: 1400.00,
        budget: 1500.00,
        usage: 83.4,
        limit: 100,
        unit: 'USD',
        trend: 'up',
        change: 0.12,
        lastUpdated: '2024-01-15T14:30:00Z'
      },
      {
        id: 'cost_2',
        category: 'llm_provider',
        name: 'OpenAI GPT-4',
        currentCost: 890.25,
        projectedCost: 950.00,
        budget: 1000.00,
        usage: 89.0,
        limit: 100,
        unit: 'USD',
        trend: 'up',
        change: 0.07,
        lastUpdated: '2024-01-15T14:30:00Z'
      },
      {
        id: 'cost_3',
        category: 'api_calls',
        name: 'GHL API Calls',
        currentCost: 45.80,
        projectedCost: 50.00,
        budget: 100.00,
        usage: 45.8,
        limit: 100,
        unit: 'USD',
        trend: 'stable',
        change: 0.02,
        lastUpdated: '2024-01-15T14:30:00Z'
      },
      {
        id: 'cost_4',
        category: 'webhooks',
        name: 'Webhook Processing',
        currentCost: 12.30,
        projectedCost: 15.00,
        budget: 25.00,
        usage: 49.2,
        limit: 100,
        unit: 'USD',
        trend: 'up',
        change: 0.22,
        lastUpdated: '2024-01-15T14:30:00Z'
      }
    ];

    const sampleAlerts: BudgetAlert[] = [
      {
        id: 'alert_1',
        type: 'budget_warning',
        title: 'Voice API Budget Warning',
        description: 'ElevenLabs usage is at 83.4% of monthly budget',
        severity: 'medium',
        category: 'voice_provider',
        currentValue: 1250.50,
        threshold: 1200.00,
        suggestedAction: 'Consider optimizing voice usage or increasing budget',
        createdAt: '2024-01-15T14:30:00Z',
        isResolved: false
      },
      {
        id: 'alert_2',
        type: 'cost_optimization',
        title: 'LLM Cost Optimization Available',
        description: 'Switch to GPT-3.5 for non-critical conversations to save 60%',
        severity: 'low',
        category: 'llm_provider',
        currentValue: 890.25,
        threshold: 800.00,
        suggestedAction: 'Implement intelligent model selection based on conversation complexity',
        createdAt: '2024-01-15T13:45:00Z',
        isResolved: false
      }
    ];

    const sampleRecommendations: OptimizationRecommendation[] = [
      {
        id: 'rec_1',
        title: 'Implement Voice Caching',
        description: 'Cache frequently used voice responses to reduce API calls',
        category: 'voice_optimization',
        potentialSavings: 0.25,
        implementationEffort: 'medium',
        impact: 'high',
        autoImplementable: true,
        steps: [
          'Enable voice response caching',
          'Configure cache duration (24 hours)',
          'Set up cache invalidation rules'
        ],
        estimatedSavings: 312.50,
        paybackPeriod: 1
      },
      {
        id: 'rec_2',
        title: 'Smart Model Selection',
        description: 'Use GPT-3.5 for simple queries and GPT-4 for complex conversations',
        category: 'llm_optimization',
        potentialSavings: 0.40,
        implementationEffort: 'high',
        impact: 'high',
        autoImplementable: false,
        steps: [
          'Implement conversation complexity scoring',
          'Create model selection logic',
          'A/B test performance vs cost trade-offs'
        ],
        estimatedSavings: 356.10,
        paybackPeriod: 2
      },
      {
        id: 'rec_3',
        title: 'Optimize API Call Frequency',
        description: 'Reduce unnecessary API calls by implementing smarter batching',
        category: 'api_optimization',
        potentialSavings: 0.15,
        implementationEffort: 'low',
        impact: 'medium',
        autoImplementable: true,
        steps: [
          'Implement API call batching',
          'Add request deduplication',
          'Optimize call timing'
        ],
        estimatedSavings: 6.87,
        paybackPeriod: 0.5
      }
    ];

    const sampleBudgetPlans: BudgetPlan[] = [
      {
        id: 'plan_1',
        name: 'Production Budget',
        description: 'Main production environment budget',
        monthlyBudget: 3000.00,
        categories: [
          { category: 'Voice Provider', budget: 1500.00, spent: 1250.50, remaining: 249.50 },
          { category: 'LLM Provider', budget: 1000.00, spent: 890.25, remaining: 109.75 },
          { category: 'API Calls', budget: 100.00, spent: 45.80, remaining: 54.20 },
          { category: 'Webhooks', budget: 25.00, spent: 12.30, remaining: 12.70 },
          { category: 'Storage', budget: 50.00, spent: 23.45, remaining: 26.55 },
          { category: 'Other', budget: 325.00, spent: 156.20, remaining: 168.80 }
        ],
        alerts: sampleAlerts,
        isActive: true,
        createdAt: '2024-01-01T00:00:00Z',
        updatedAt: '2024-01-15T14:30:00Z'
      }
    ];

    setCostBreakdowns(sampleCostBreakdowns);
    setBudgetAlerts(sampleAlerts);
    setOptimizationRecommendations(sampleRecommendations);
    setBudgetPlans(sampleBudgetPlans);
  }, []);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'text-red-400 bg-red-100';
      case 'high': return 'text-orange-400 bg-orange-100';
      case 'medium': return 'text-yellow-400 bg-yellow-100';
      case 'low': return 'text-green-400 bg-green-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-4 h-4 text-red-400" />;
      case 'down': return <TrendingDown className="w-4 h-4 text-green-400" />;
      case 'stable': return <Minus className="w-4 h-4 text-gray-400" />;
      default: return <Minus className="w-4 h-4 text-gray-400" />;
    }
  };

  const getEffortColor = (effort: string) => {
    switch (effort) {
      case 'low': return 'text-green-400 bg-green-100';
      case 'medium': return 'text-yellow-400 bg-yellow-100';
      case 'high': return 'text-red-400 bg-red-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const renderOverviewTab = () => (
    <div className="space-y-6">
      {/* Cost Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Monthly Cost</p>
              <p className="text-2xl font-bold text-foreground">
                ${costBreakdowns.reduce((acc, cost) => acc + cost.currentCost, 0).toFixed(2)}
              </p>
            </div>
            <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-primary" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Budget Utilization</p>
              <p className="text-2xl font-bold text-blue-400">
                {Math.round((costBreakdowns.reduce((acc, cost) => acc + cost.currentCost, 0) / 
                  costBreakdowns.reduce((acc, cost) => acc + cost.budget, 0)) * 100)}%
              </p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Target className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Potential Savings</p>
              <p className="text-2xl font-bold text-green-400">
                ${optimizationRecommendations.reduce((acc, rec) => acc + rec.estimatedSavings, 0).toFixed(2)}
              </p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <TrendingDown className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Active Alerts</p>
              <p className="text-2xl font-bold text-red-400">
                {budgetAlerts.filter(alert => !alert.isResolved).length}
              </p>
            </div>
            <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Cost Breakdown Chart */}
      <div className="card p-6">
        <h2 className="text-xl font-semibold text-foreground mb-6">Cost Breakdown</h2>
        <div className="space-y-4">
          {costBreakdowns.map((cost) => (
            <div key={cost.id} className="flex items-center justify-between p-4 bg-secondary rounded-lg">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="font-medium text-foreground">{cost.name}</p>
                  <p className="text-sm text-muted-foreground">{cost.category.replace('_', ' ')}</p>
                </div>
              </div>
              <div className="flex items-center space-x-6">
                <div className="text-right">
                  <p className="text-sm font-medium text-foreground">${cost.currentCost.toFixed(2)}</p>
                  <p className="text-xs text-muted-foreground">Current</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-foreground">${cost.budget.toFixed(2)}</p>
                  <p className="text-xs text-muted-foreground">Budget</p>
                </div>
                <div className="flex items-center space-x-2">
                  {getTrendIcon(cost.trend)}
                  <span className="text-sm text-muted-foreground">
                    {cost.change > 0 ? '+' : ''}{(cost.change * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="w-20 bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-primary h-2 rounded-full"
                    style={{ width: `${cost.usage}%` }}
                  ></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderCostsTab = () => (
    <div className="space-y-6">
      {/* Cost Details */}
      <div className="space-y-4">
        {costBreakdowns.map((cost) => (
          <div key={cost.id} className="card p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="text-lg font-semibold text-foreground">{cost.name}</h3>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                    cost.usage > 90 ? 'text-red-400 bg-red-100' :
                    cost.usage > 75 ? 'text-yellow-400 bg-yellow-100' :
                    'text-green-400 bg-green-100'
                  }`}>
                    {cost.usage.toFixed(1)}% used
                  </div>
                </div>
                <p className="text-muted-foreground mb-3">{cost.category.replace('_', ' ')}</p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Current Cost</p>
                    <p className="text-lg font-bold text-foreground">${cost.currentCost.toFixed(2)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Projected Cost</p>
                    <p className="text-lg font-bold text-blue-400">${cost.projectedCost.toFixed(2)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Budget</p>
                    <p className="text-lg font-bold text-green-400">${cost.budget.toFixed(2)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Trend</p>
                    <div className="flex items-center space-x-1">
                      {getTrendIcon(cost.trend)}
                      <span className="text-sm text-muted-foreground">
                        {cost.change > 0 ? '+' : ''}{(cost.change * 100).toFixed(1)}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <button className="btn btn-outline btn-sm">
                  <Settings className="w-4 h-4 mr-2" />
                  Configure
                </button>
                <button className="btn btn-outline btn-sm">
                  <Eye className="w-4 h-4 mr-2" />
                  Details
                </button>
              </div>
            </div>
            
            {/* Usage Bar */}
            <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
              <div
                className={`h-2 rounded-full ${
                  cost.usage > 90 ? 'bg-red-400' :
                  cost.usage > 75 ? 'bg-yellow-400' :
                  'bg-green-400'
                }`}
                style={{ width: `${cost.usage}%` }}
              ></div>
            </div>
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>0</span>
              <span>{cost.usage.toFixed(1)}% used</span>
              <span>{cost.limit}% limit</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderOptimizationTab = () => (
    <div className="space-y-6">
      {/* Optimization Recommendations */}
      <div className="space-y-4">
        {optimizationRecommendations.map((rec) => (
          <div key={rec.id} className="card p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="text-lg font-semibold text-foreground">{rec.title}</h3>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${getEffortColor(rec.implementationEffort)}`}>
                    {rec.implementationEffort} effort
                  </div>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                    rec.impact === 'high' ? 'text-green-400 bg-green-100' :
                    rec.impact === 'medium' ? 'text-yellow-400 bg-yellow-100' :
                    'text-red-400 bg-red-100'
                  }`}>
                    {rec.impact} impact
                  </div>
                </div>
                <p className="text-muted-foreground mb-3">{rec.description}</p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Potential Savings</p>
                    <p className="text-lg font-bold text-green-400">${rec.estimatedSavings.toFixed(2)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Savings %</p>
                    <p className="text-lg font-bold text-blue-400">{(rec.potentialSavings * 100).toFixed(1)}%</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Payback Period</p>
                    <p className="text-lg font-bold text-purple-400">{rec.paybackPeriod} month(s)</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Auto-Implementable</p>
                    <p className="text-lg font-bold text-orange-400">
                      {rec.autoImplementable ? 'Yes' : 'No'}
                    </p>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                {rec.autoImplementable && (
                  <button className="btn btn-primary btn-sm">
                    <Wrench className="w-4 h-4 mr-2" />
                    Auto-Implement
                  </button>
                )}
                <button className="btn btn-outline btn-sm">
                  <Eye className="w-4 h-4 mr-2" />
                  Details
                </button>
              </div>
            </div>
            
            {/* Implementation Steps */}
            <div className="mt-4">
              <h4 className="font-medium text-foreground mb-2">Implementation Steps:</h4>
              <ol className="list-decimal list-inside space-y-1 text-sm text-muted-foreground">
                {rec.steps.map((step, idx) => (
                  <li key={idx}>{step}</li>
                ))}
              </ol>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="p-6 bg-background min-h-screen text-foreground">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Cost Optimization</h1>
            <p className="text-muted-foreground">
              Intelligent cost management and budget optimization for voice AI operations
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <button className="btn btn-outline">
              <Download className="w-4 h-4 mr-2" />
              Export Report
            </button>
            <button className="btn btn-outline">
              <Settings className="w-4 h-4 mr-2" />
              Budget Settings
            </button>
            <button className="btn btn-primary">
              <Wrench className="w-4 h-4 mr-2" />
              Auto-Optimize
            </button>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="mb-6">
        <div className="flex space-x-1 bg-secondary p-1 rounded-lg w-fit">
          {[
            { id: 'overview', label: 'Overview', icon: BarChart3 },
            { id: 'costs', label: 'Cost Analysis', icon: DollarSign },
            { id: 'budgets', label: 'Budget Management', icon: Target },
            { id: 'optimization', label: 'Optimization', icon: TrendingDown },
            { id: 'alerts', label: 'Alerts', icon: AlertTriangle }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-primary text-primary-foreground shadow-lg'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      {activeTab === 'overview' && renderOverviewTab()}
      {activeTab === 'costs' && renderCostsTab()}
      {activeTab === 'budgets' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Budget Management</h2>
          <p className="text-muted-foreground">Budget management interface will be displayed here.</p>
        </div>
      )}
      {activeTab === 'optimization' && renderOptimizationTab()}
      {activeTab === 'alerts' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Cost Alerts</h2>
          <p className="text-muted-foreground">Cost alerts and notifications interface will be displayed here.</p>
        </div>
      )}
    </div>
  );
};

export default CostOptimization;
