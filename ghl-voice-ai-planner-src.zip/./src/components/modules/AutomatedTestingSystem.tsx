import React, { useState, useEffect } from 'react';
import { 
  TestTube, 
  Play, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Clock, 
  BarChart3, 
  RefreshCw,
  Download,
  Eye,
  Search,
  Zap,
  Target,
  MessageSquare,
  Database,
  Shield
} from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';

interface TestCase {
  id: string;
  name: string;
  description: string;
  category: 'functionality' | 'performance' | 'integration' | 'security' | 'compliance';
  priority: 'low' | 'medium' | 'high' | 'critical';
  status: 'pending' | 'running' | 'passed' | 'failed' | 'skipped';
  agentId: string;
  agentName: string;
  duration: number;
  lastRun: string | null;
  passRate: number;
  steps: Array<{
    step: string;
    expected: string;
    actual: string;
    status: 'pending' | 'passed' | 'failed';
  }>;
  errorMessage?: string;
  performance: {
    responseTime: number;
    memoryUsage: number;
    cpuUsage: number;
  };
}

interface TestSuite {
  id: string;
  name: string;
  description: string;
  testCases: string[];
  status: 'pending' | 'running' | 'completed' | 'failed';
  createdAt: string;
  lastRun: string | null;
  passRate: number;
  totalDuration: number;
}

interface TestMetrics {
  totalTests: number;
  passedTests: number;
  failedTests: number;
  skippedTests: number;
  passRate: number;
  averageResponseTime: number;
  totalTestSuites: number;
  runningTests: number;
  lastTestRun: string | null;
}

const AutomatedTestingSystem: React.FC = () => {
  const { } = useStore();
  const [testCases, setTestCases] = useState<TestCase[]>([]);
  const [testSuites, setTestSuites] = useState<TestSuite[]>([]);
  const [metrics, setMetrics] = useState<TestMetrics>({
    totalTests: 0,
    passedTests: 0,
    failedTests: 0,
    skippedTests: 0,
    passRate: 0,
    averageResponseTime: 0,
    totalTestSuites: 0,
    runningTests: 0,
    lastTestRun: null
  });
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isRunningTests, setIsRunningTests] = useState(false);
  const [selectedTestSuite, setSelectedTestSuite] = useState<string>('all');

  // Sample data - in real app this would come from test execution engine
  useEffect(() => {
    const sampleTestCases: TestCase[] = [
      {
        id: 'test_1',
        name: 'F45 Trial Booking Flow',
        description: 'Test complete trial booking process from greeting to confirmation',
        category: 'functionality',
        priority: 'high',
        status: 'passed',
        agentId: 'agent_1',
        agentName: 'F45 Fitness Agent',
        duration: 45,
        lastRun: '2024-01-15T12:30:00Z',
        passRate: 0.95,
        steps: [
          { step: 'Agent greets caller', expected: 'Friendly greeting with value proposition', actual: 'Hey! This is Sarah from F45 Training...', status: 'passed' },
          { step: 'Collects fitness level', expected: 'Asks about current fitness level', actual: 'What\'s your current fitness level?', status: 'passed' },
          { step: 'Recommends class type', expected: 'Suggests appropriate class based on goals', actual: 'I think our F45 Core class would be perfect...', status: 'passed' },
          { step: 'Books trial appointment', expected: 'Successfully schedules trial class', actual: 'I\'ve got you booked for Tuesday at 6pm', status: 'passed' }
        ],
        performance: {
          responseTime: 1.2,
          memoryUsage: 45.6,
          cpuUsage: 12.3
        }
      },
      {
        id: 'test_2',
        name: 'Emergency Transfer Logic',
        description: 'Test emergency transfer detection and routing',
        category: 'functionality',
        priority: 'critical',
        status: 'failed',
        agentId: 'agent_3',
        agentName: 'Plumbing Emergency Agent',
        duration: 32,
        lastRun: '2024-01-15T12:25:00Z',
        passRate: 0.78,
        steps: [
          { step: 'Detects emergency keywords', expected: 'Recognizes urgent language', actual: 'Emergency detected', status: 'passed' },
          { step: 'Escalates to human', expected: 'Transfers to emergency dispatch', actual: 'Transfer initiated', status: 'passed' },
          { step: 'Sends notifications', expected: 'Alerts management team', actual: 'Notification sent', status: 'failed' },
          { step: 'Logs incident', expected: 'Records emergency details', actual: 'Logging failed', status: 'failed' }
        ],
        errorMessage: 'Notification service timeout - check webhook configuration',
        performance: {
          responseTime: 2.8,
          memoryUsage: 67.2,
          cpuUsage: 18.7
        }
      },
      {
        id: 'test_3',
        name: 'Intent Recognition Accuracy',
        description: 'Test intent recognition across different phrasings',
        category: 'performance',
        priority: 'high',
        status: 'passed',
        agentId: 'agent_2',
        agentName: 'Legal Consultation Agent',
        duration: 67,
        lastRun: '2024-01-15T12:20:00Z',
        passRate: 0.92,
        steps: [
          { step: 'Personal injury intent', expected: 'Recognizes injury-related keywords', actual: 'Intent: personal_injury (0.94)', status: 'passed' },
          { step: 'Family law intent', expected: 'Identifies family legal matters', actual: 'Intent: family_law (0.89)', status: 'passed' },
          { step: 'Business law intent', expected: 'Detects commercial legal needs', actual: 'Intent: business_law (0.91)', status: 'passed' },
          { step: 'Criminal defense intent', expected: 'Recognizes criminal charges', actual: 'Intent: criminal_defense (0.96)', status: 'passed' }
        ],
        performance: {
          responseTime: 0.8,
          memoryUsage: 34.1,
          cpuUsage: 8.9
        }
      },
      {
        id: 'test_4',
        name: 'GHL Integration Webhooks',
        description: 'Test webhook delivery to GoHighLevel',
        category: 'integration',
        priority: 'high',
        status: 'running',
        agentId: 'agent_4',
        agentName: 'Martial Arts Agent',
        duration: 0,
        lastRun: null,
        passRate: 0.0,
        steps: [
          { step: 'Contact creation', expected: 'Creates contact in GHL', actual: 'Pending...', status: 'pending' },
          { step: 'Custom field update', expected: 'Updates martial arts fields', actual: 'Pending...', status: 'pending' },
          { step: 'Tag assignment', expected: 'Adds appropriate tags', actual: 'Pending...', status: 'pending' },
          { step: 'Workflow trigger', expected: 'Starts follow-up workflow', actual: 'Pending...', status: 'pending' }
        ],
        performance: {
          responseTime: 0,
          memoryUsage: 0,
          cpuUsage: 0
        }
      },
      {
        id: 'test_5',
        name: 'Data Privacy Compliance',
        description: 'Test GDPR and TCPA compliance features',
        category: 'compliance',
        priority: 'critical',
        status: 'passed',
        agentId: 'agent_5',
        agentName: 'Construction Agent',
        duration: 23,
        lastRun: '2024-01-15T12:15:00Z',
        passRate: 1.0,
        steps: [
          { step: 'DNC list check', expected: 'Checks against DNC registry', actual: 'DNC check passed', status: 'passed' },
          { step: 'Consent recording', expected: 'Records consent properly', actual: 'Consent logged', status: 'passed' },
          { step: 'Data encryption', expected: 'Encrypts sensitive data', actual: 'Data encrypted', status: 'passed' },
          { step: 'Retention policy', expected: 'Follows data retention rules', actual: 'Retention compliant', status: 'passed' }
        ],
        performance: {
          responseTime: 0.5,
          memoryUsage: 12.8,
          cpuUsage: 3.2
        }
      }
    ];

    const sampleTestSuites: TestSuite[] = [
      {
        id: 'suite_1',
        name: 'F45 Agent Test Suite',
        description: 'Complete testing suite for F45 Fitness Agent',
        testCases: ['test_1'],
        status: 'completed',
        createdAt: '2024-01-15T10:00:00Z',
        lastRun: '2024-01-15T12:30:00Z',
        passRate: 0.95,
        totalDuration: 45
      },
      {
        id: 'suite_2',
        name: 'Emergency Response Suite',
        description: 'Critical emergency handling tests',
        testCases: ['test_2'],
        status: 'failed',
        createdAt: '2024-01-15T09:30:00Z',
        lastRun: '2024-01-15T12:25:00Z',
        passRate: 0.78,
        totalDuration: 32
      },
      {
        id: 'suite_3',
        name: 'Integration Test Suite',
        description: 'GHL integration and webhook tests',
        testCases: ['test_4'],
        status: 'running',
        createdAt: '2024-01-15T11:00:00Z',
        lastRun: null,
        passRate: 0.0,
        totalDuration: 0
      }
    ];

    setTestCases(sampleTestCases);
    setTestSuites(sampleTestSuites);
    
    // Calculate metrics
    const passed = sampleTestCases.filter(t => t.status === 'passed').length;
    const failed = sampleTestCases.filter(t => t.status === 'failed').length;
    const skipped = sampleTestCases.filter(t => t.status === 'skipped').length;
    const running = sampleTestCases.filter(t => t.status === 'running').length;
    const avgResponseTime = sampleTestCases.reduce((sum, t) => sum + t.performance.responseTime, 0) / sampleTestCases.length;
    
    setMetrics({
      totalTests: sampleTestCases.length,
      passedTests: passed,
      failedTests: failed,
      skippedTests: skipped,
      passRate: passed / sampleTestCases.length,
      averageResponseTime: avgResponseTime,
      totalTestSuites: sampleTestSuites.length,
      runningTests: running,
      lastTestRun: sampleTestCases.find(t => t.lastRun)?.lastRun || null
    });
  }, []);

  const categories = [
    { id: 'all', name: 'All Categories', icon: BarChart3 },
    { id: 'functionality', name: 'Functionality', icon: TestTube },
    { id: 'performance', name: 'Performance', icon: Zap },
    { id: 'integration', name: 'Integration', icon: Database },
    { id: 'security', name: 'Security', icon: Shield },
    { id: 'compliance', name: 'Compliance', icon: CheckCircle }
  ];

  const statuses = [
    { id: 'all', name: 'All Status', color: 'text-gray-400' },
    { id: 'passed', name: 'Passed', color: 'text-green-400' },
    { id: 'failed', name: 'Failed', color: 'text-red-400' },
    { id: 'running', name: 'Running', color: 'text-blue-400' },
    { id: 'pending', name: 'Pending', color: 'text-yellow-400' },
    { id: 'skipped', name: 'Skipped', color: 'text-gray-400' }
  ];

  const filteredTestCases = testCases.filter(testCase => {
    const matchesSearch = testCase.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         testCase.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || testCase.category === selectedCategory;
    const matchesStatus = selectedStatus === 'all' || testCase.status === selectedStatus;
    const matchesSuite = selectedTestSuite === 'all' || testSuites.find(s => s.testCases.includes(testCase.id))?.id === selectedTestSuite;
    return matchesSearch && matchesCategory && matchesStatus && matchesSuite;
  });

  const handleRunTest = (testId: string) => {
    setTestCases(prev => 
      prev.map(t => 
        t.id === testId 
          ? { ...t, status: 'running' as const, lastRun: new Date().toISOString() }
          : t
      )
    );
    toast.success(`Running test: ${testCases.find(t => t.id === testId)?.name}`);
  };


  const handleRunAllTests = () => {
    setIsRunningTests(true);
    setTestCases(prev => 
      prev.map(t => ({ ...t, status: 'running' as const, lastRun: new Date().toISOString() }))
    );
    toast.success('Running all tests...');
    
    // Simulate test execution
    setTimeout(() => {
      setIsRunningTests(false);
      toast.success('All tests completed');
    }, 5000);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'passed': return 'text-green-400 bg-green-100';
      case 'failed': return 'text-red-400 bg-red-100';
      case 'running': return 'text-blue-400 bg-blue-100';
      case 'pending': return 'text-yellow-400 bg-yellow-100';
      case 'skipped': return 'text-gray-400 bg-gray-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'text-red-400 bg-red-100';
      case 'high': return 'text-orange-400 bg-orange-100';
      case 'medium': return 'text-yellow-400 bg-yellow-100';
      case 'low': return 'text-green-400 bg-green-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const renderTestCaseCard = (testCase: TestCase) => (
    <div key={testCase.id} className="card p-6 hover:shadow-lg transition-all duration-200">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <h3 className="text-lg font-semibold text-foreground">{testCase.name}</h3>
            <div className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(testCase.status)}`}>
              {testCase.status}
            </div>
            <div className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(testCase.priority)}`}>
              {testCase.priority}
            </div>
          </div>
          <p className="text-muted-foreground mb-3">{testCase.description}</p>
          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
            <div className="flex items-center space-x-1">
              <MessageSquare className="w-4 h-4" />
              <span>{testCase.agentName}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Clock className="w-4 h-4" />
              <span>{testCase.duration}s</span>
            </div>
            <div className="flex items-center space-x-1">
              <Target className="w-4 h-4" />
              <span>{Math.round(testCase.passRate * 100)}% pass rate</span>
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {/* Test Steps */}
        <div>
          <h4 className="font-medium text-foreground mb-2">Test Steps:</h4>
          <div className="space-y-2">
            {testCase.steps.map((step, index) => (
              <div key={index} className="flex items-start space-x-3 p-2 bg-secondary rounded">
                <div className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-medium mt-0.5 ${
                  step.status === 'passed' ? 'bg-green-100 text-green-600' :
                  step.status === 'failed' ? 'bg-red-100 text-red-600' :
                  'bg-gray-100 text-gray-600'
                }`}>
                  {step.status === 'passed' ? '✓' : step.status === 'failed' ? '✗' : index + 1}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground">{step.step}</p>
                  <p className="text-xs text-muted-foreground">Expected: {step.expected}</p>
                  <p className="text-xs text-muted-foreground">Actual: {step.actual}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Performance Metrics */}
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-secondary p-3 rounded">
            <p className="text-sm text-muted-foreground">Response Time</p>
            <p className="text-lg font-semibold text-foreground">{testCase.performance.responseTime}s</p>
          </div>
          <div className="bg-secondary p-3 rounded">
            <p className="text-sm text-muted-foreground">Memory Usage</p>
            <p className="text-lg font-semibold text-foreground">{testCase.performance.memoryUsage}MB</p>
          </div>
          <div className="bg-secondary p-3 rounded">
            <p className="text-sm text-muted-foreground">CPU Usage</p>
            <p className="text-lg font-semibold text-foreground">{testCase.performance.cpuUsage}%</p>
          </div>
        </div>

        {/* Error Message */}
        {testCase.errorMessage && (
          <div className="bg-red-100 border border-red-200 rounded p-3">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 text-red-600" />
              <span className="text-sm font-medium text-red-800">Error:</span>
            </div>
            <p className="text-sm text-red-700 mt-1">{testCase.errorMessage}</p>
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center justify-between pt-4 border-t border-border">
          <div className="text-sm text-muted-foreground">
            Last run: {testCase.lastRun ? new Date(testCase.lastRun).toLocaleString() : 'Never'}
          </div>
          <div className="flex items-center space-x-2">
            {testCase.status === 'pending' && (
              <button
                onClick={() => handleRunTest(testCase.id)}
                className="btn btn-primary btn-sm"
              >
                <Play className="w-4 h-4 mr-2" />
                Run Test
              </button>
            )}
            {testCase.status === 'running' && (
              <div className="flex items-center space-x-2 text-blue-400">
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span className="text-sm">Running...</span>
              </div>
            )}
            <button className="btn btn-outline btn-sm">
              <Eye className="w-4 h-4 mr-2" />
              View Details
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="p-6 bg-background min-h-screen text-foreground">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Automated Testing System</h1>
            <p className="text-muted-foreground">
              Comprehensive testing and validation for voice AI agents with real-time monitoring
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <button
              onClick={handleRunAllTests}
              disabled={isRunningTests}
              className="btn btn-primary"
            >
              {isRunningTests ? (
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Play className="w-4 h-4 mr-2" />
              )}
              {isRunningTests ? 'Running...' : 'Run All Tests'}
            </button>
            <button className="btn btn-outline">
              <Download className="w-4 h-4 mr-2" />
              Export Results
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Tests</p>
              <p className="text-2xl font-bold text-foreground">{metrics.totalTests}</p>
            </div>
            <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
              <TestTube className="w-6 h-6 text-primary" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Passed</p>
              <p className="text-2xl font-bold text-green-400">{metrics.passedTests}</p>
              <p className="text-sm text-green-400">
                {Math.round(metrics.passRate * 100)}% pass rate
              </p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Failed</p>
              <p className="text-2xl font-bold text-red-400">{metrics.failedTests}</p>
            </div>
            <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
              <XCircle className="w-6 h-6 text-red-600" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Avg Response</p>
              <p className="text-2xl font-bold text-foreground">{metrics.averageResponseTime.toFixed(1)}s</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Clock className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="card p-6 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <input
                type="text"
                placeholder="Search tests..."
                className="w-full pl-10 input"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          <div className="flex space-x-2">
            <select
              className="input"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              {categories.map(category => (
                <option key={category.id} value={category.id}>{category.name}</option>
              ))}
            </select>
            <select
              className="input"
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
            >
              {statuses.map(status => (
                <option key={status.id} value={status.id}>{status.name}</option>
              ))}
            </select>
            <select
              className="input"
              value={selectedTestSuite}
              onChange={(e) => setSelectedTestSuite(e.target.value)}
            >
              <option value="all">All Test Suites</option>
              {testSuites.map(suite => (
                <option key={suite.id} value={suite.id}>{suite.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Test Cases Grid */}
      <div className="space-y-6">
        {filteredTestCases.map(renderTestCaseCard)}
      </div>

      {filteredTestCases.length === 0 && (
        <div className="text-center py-12">
          <TestTube className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
          <h3 className="text-lg font-semibold text-foreground mb-2">No tests found</h3>
          <p className="text-muted-foreground mb-4">
            Try adjusting your filters or create new test cases
          </p>
          <button className="btn btn-primary">
            <TestTube className="w-4 h-4 mr-2" />
            Create Test Case
          </button>
        </div>
      )}
    </div>
  );
};

export default AutomatedTestingSystem;
