import React, { useState, useEffect } from 'react';
import { 
  Store, 
  Star, 
  Download, 
  Upload, 
  Share2, 
  Heart, 
  ThumbsUp, 
  ThumbsDown, 
  MessageSquare, 
  Eye, 
  Filter, 
  Search, 
  SortAsc, 
  SortDesc, 
  MoreHorizontal, 
  ChevronDown, 
  ChevronRight, 
  Plus, 
  Minus, 
  Edit, 
  Trash2, 
  Save, 
  RefreshCw, 
  Settings, 
  Cog, 
  Sliders, 
  ToggleLeft, 
  ToggleRight, 
  Switch, 
  Power, 
  PowerOff, 
  Battery, 
  BatteryCharging, 
  Wifi, 
  WifiOff, 
  Signal, 
  SignalZero, 
  SignalOne, 
  SignalTwo, 
  SignalThree, 
  SignalFour, 
  SignalFive,
  Mic,
  Headphones,
  Volume2,
  VolumeX,
  Play,
  Pause,
  SkipForward,
  SkipBack,
  RotateCcw,
  BarChart3,
  LineChart,
  PieChart,
  Activity,
  Clock,
  Users,
  Phone,
  Bot,
  Brain,
  Zap,
  Target,
  TrendingUp,
  TrendingDown,
  Database,
  Server,
  Globe,
  FileText,
  FileCheck,
  FileX,
  FileAlert,
  FileLock,
  FileShield,
  FileSearch,
  FileCode,
  FileImage,
  FileVideo,
  FileAudio,
  FileArchive,
  FileSpreadsheet,
  FilePresentation,
  FilePdf,
  FileWord,
  FileExcel,
  FilePowerpoint,
  FileZip,
  FileRar,
  File7z,
  FileTar,
  FileGz,
  FileBz2,
  FileXz,
  FileLz4,
  FileZstd,
  FileCab,
  FileIso,
  FileDmg,
  FileImg,
  FileVhd,
  FileVdi,
  FileVmdk,
  FileOva,
  FileOvf,
  FileVagrant,
  FileDocker,
  FileKubernetes,
  FileTerraform,
  FileAnsible,
  FileChef,
  FilePuppet,
  FileSalt,
  FileConsul,
  FileVault,
  FileNomad,
  FileDockerCompose,
  FileKustomize,
  FileHelm,
  FileIstio,
  FileLinkerd,
  FileEnvoy,
  FileNginx,
  FileApache,
  FileIis,
  FileTomcat,
  FileJetty,
  FileWildfly,
  FileWeblogic,
  FileWebsphere,
  FileGlassfish,
  FileJboss,
  FileResin,
  FileGeronimo,
  FileOpenliberty,
  FilePayara,
  FileTomee,
  FileWeld,
  FileDeltaspike,
  FileShiro,
  FileSpring,
  FileHibernate,
  FileMybatis,
  FileJpa,
  FileJdbc,
  FileJndi,
  FileJms,
  FileJta,
  FileJca,
  FileJaxb,
  FileJaxrs,
  FileJaxws,
  FileJsf,
  FileStruts,
  FileVaadin,
  FileGwt,
  FileWicket,
  FileTapestry,
  FileSeam,
  FileRichfaces,
  FilePrimefaces,
  FileIcefaces,
  FileOpenfaces,
  FileButterfaces,
  FileBootsfaces,
  FileOmnifaces,
  FileAngularfaces,
  FileAngular,
  FileReact,
  FileVue,
  FileSvelte,
  FileEmber,
  FileBackbone,
  FileKnockout,
  FileMithril,
  FilePreact,
  FileInferno,
  FileRiot,
  FileStencil,
  FileLit,
  FilePolymer,
  FileAurelia,
  FileMithril,
  FileHyperapp,
  FileAlpine,
  FileStimulus,
  FileTurbo,
  FileHotwire,
  FileLivewire,
  FileInertia,
  FileNext,
  FileNuxt,
  FileSapper,
  FileSveltekit,
  FileRemix,
  FileSolid,
  FileQwik,
  FileMarko,
  FileMithril,
  FileHyperapp,
  FileAlpine,
  FileStimulus,
  FileTurbo,
  FileHotwire,
  FileLivewire,
  FileInertia,
  FileNext,
  FileNuxt,
  FileSapper,
  FileSveltekit,
  FileRemix,
  FileSolid,
  FileQwik,
  FileMarko,
  Award,
  Trophy,
  Medal,
  Crown,
  Flame,
  Lightning,
  Rocket,
  Shield,
  Lock,
  Unlock,
  Key,
  Wrench,
  Info,
  AlertTriangle,
  CheckCircle,
  XCircle
} from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';

interface MarketplaceAgent {
  id: string;
  name: string;
  description: string;
  author: {
    id: string;
    name: string;
    avatar: string;
    verified: boolean;
    rating: number;
    totalAgents: number;
  };
  category: 'fitness' | 'legal' | 'healthcare' | 'real_estate' | 'automotive' | 'education' | 'finance' | 'retail' | 'hospitality' | 'technology';
  industry: string;
  tags: string[];
  price: {
    type: 'free' | 'premium' | 'subscription';
    amount: number;
    currency: string;
  };
  rating: {
    average: number;
    count: number;
    distribution: {
      five: number;
      four: number;
      three: number;
      two: number;
      one: number;
    };
  };
  downloads: number;
  likes: number;
  shares: number;
  status: 'published' | 'draft' | 'pending' | 'rejected' | 'featured';
  featured: boolean;
  verified: boolean;
  createdAt: string;
  updatedAt: string;
  version: string;
  compatibility: {
    minVersion: string;
    maxVersion: string;
    platforms: string[];
  };
  requirements: {
    ghlVersion: string;
    voiceProvider: string;
    llmProvider: string;
    customFields: number;
    workflows: number;
  };
  screenshots: string[];
  demoUrl: string;
  documentation: string;
  support: {
    email: string;
    documentation: string;
    community: string;
  };
  reviews: Array<{
    id: string;
    userId: string;
    userName: string;
    userAvatar: string;
    rating: number;
    comment: string;
    helpful: number;
    createdAt: string;
  }>;
  stats: {
    conversionRate: number;
    avgDuration: number;
    satisfactionScore: number;
    successRate: number;
  };
}

interface MarketplaceCategory {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  agentCount: number;
  featured: boolean;
}

interface MarketplaceStats {
  totalAgents: number;
  totalDownloads: number;
  totalAuthors: number;
  totalRevenue: number;
  featuredAgents: number;
  topCategories: Array<{
    category: string;
    count: number;
    growth: number;
  }>;
  topAuthors: Array<{
    author: string;
    agents: number;
    downloads: number;
    rating: number;
  }>;
}

const AgentMarketplace: React.FC = () => {
  const { darkMode } = useStore();
  const [agents, setAgents] = useState<MarketplaceAgent[]>([]);
  const [categories, setCategories] = useState<MarketplaceCategory[]>([]);
  const [stats, setStats] = useState<MarketplaceStats>({
    totalAgents: 0,
    totalDownloads: 0,
    totalAuthors: 0,
    totalRevenue: 0,
    featuredAgents: 0,
    topCategories: [],
    topAuthors: []
  });
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedPrice, setSelectedPrice] = useState<string>('all');
  const [selectedRating, setSelectedRating] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<string>('popular');
  const [activeTab, setActiveTab] = useState<'browse' | 'featured' | 'trending' | 'new' | 'my_agents' | 'favorites'>('browse');

  // Sample data - in real app this would come from marketplace API
  useEffect(() => {
    const sampleAgents: MarketplaceAgent[] = [
      {
        id: 'agent_1',
        name: 'F45 Fitness Trial Booking Pro',
        description: 'Advanced F45 fitness trial booking agent with membership qualification, class scheduling, and payment processing. Includes 6 industry-specific templates and GHL integration.',
        author: {
          id: 'author_1',
          name: 'Fitness AI Solutions',
          avatar: 'https://via.placeholder.com/40',
          verified: true,
          rating: 4.8,
          totalAgents: 12
        },
        category: 'fitness',
        industry: 'Fitness & Wellness',
        tags: ['fitness', 'trial-booking', 'membership', 'scheduling', 'payment'],
        price: {
          type: 'premium',
          amount: 299,
          currency: 'USD'
        },
        rating: {
          average: 4.7,
          count: 156,
          distribution: {
            five: 120,
            four: 28,
            three: 6,
            two: 2,
            one: 0
          }
        },
        downloads: 1247,
        likes: 89,
        shares: 23,
        status: 'published',
        featured: true,
        verified: true,
        createdAt: '2024-01-10T10:00:00Z',
        updatedAt: '2024-01-15T14:30:00Z',
        version: '2.1.0',
        compatibility: {
          minVersion: '2.0.0',
          maxVersion: '3.0.0',
          platforms: ['GHL', 'VAPI', 'ElevenLabs']
        },
        requirements: {
          ghlVersion: '2.0+',
          voiceProvider: 'ElevenLabs',
          llmProvider: 'OpenAI GPT-4',
          customFields: 8,
          workflows: 4
        },
        screenshots: [
          'https://via.placeholder.com/400x300',
          'https://via.placeholder.com/400x300',
          'https://via.placeholder.com/400x300'
        ],
        demoUrl: 'https://demo.fitness-ai.com/f45-agent',
        documentation: 'https://docs.fitness-ai.com/f45-agent',
        support: {
          email: 'support@fitness-ai.com',
          documentation: 'https://docs.fitness-ai.com',
          community: 'https://community.fitness-ai.com'
        },
        reviews: [
          {
            id: 'review_1',
            userId: 'user_1',
            userName: 'Sarah Johnson',
            userAvatar: 'https://via.placeholder.com/32',
            rating: 5,
            comment: 'Amazing agent! Increased our trial bookings by 40% in the first month. The integration with GHL is seamless.',
            helpful: 12,
            createdAt: '2024-01-14T16:30:00Z'
          },
          {
            id: 'review_2',
            userId: 'user_2',
            userName: 'Mike Chen',
            userAvatar: 'https://via.placeholder.com/32',
            rating: 4,
            comment: 'Great functionality, but could use more customization options. Overall very satisfied.',
            helpful: 8,
            createdAt: '2024-01-13T11:15:00Z'
          }
        ],
        stats: {
          conversionRate: 0.23,
          avgDuration: 195,
          satisfactionScore: 0.91,
          successRate: 0.87
        }
      },
      {
        id: 'agent_2',
        name: 'Legal Consultation Booking Assistant',
        description: 'Professional legal consultation booking agent with case type qualification, attorney matching, and appointment scheduling. Includes compliance features and multi-language support.',
        author: {
          id: 'author_2',
          name: 'LegalTech Pro',
          avatar: 'https://via.placeholder.com/40',
          verified: true,
          rating: 4.9,
          totalAgents: 8
        },
        category: 'legal',
        industry: 'Legal Services',
        tags: ['legal', 'consultation', 'booking', 'compliance', 'multi-language'],
        price: {
          type: 'premium',
          amount: 499,
          currency: 'USD'
        },
        rating: {
          average: 4.8,
          count: 89,
          distribution: {
            five: 75,
            four: 12,
            three: 2,
            two: 0,
            one: 0
          }
        },
        downloads: 567,
        likes: 45,
        shares: 18,
        status: 'published',
        featured: true,
        verified: true,
        createdAt: '2024-01-08T09:00:00Z',
        updatedAt: '2024-01-15T10:20:00Z',
        version: '1.5.2',
        compatibility: {
          minVersion: '2.0.0',
          maxVersion: '3.0.0',
          platforms: ['GHL', 'VAPI', 'ElevenLabs']
        },
        requirements: {
          ghlVersion: '2.0+',
          voiceProvider: 'ElevenLabs',
          llmProvider: 'OpenAI GPT-4',
          customFields: 12,
          workflows: 6
        },
        screenshots: [
          'https://via.placeholder.com/400x300',
          'https://via.placeholder.com/400x300'
        ],
        demoUrl: 'https://demo.legaltech.com/consultation-agent',
        documentation: 'https://docs.legaltech.com/consultation-agent',
        support: {
          email: 'support@legaltech.com',
          documentation: 'https://docs.legaltech.com',
          community: 'https://community.legaltech.com'
        },
        reviews: [
          {
            id: 'review_3',
            userId: 'user_3',
            userName: 'David Martinez',
            userAvatar: 'https://via.placeholder.com/32',
            rating: 5,
            comment: 'Perfect for our law firm. The compliance features are excellent and the multi-language support is a game-changer.',
            helpful: 15,
            createdAt: '2024-01-12T14:45:00Z'
          }
        ],
        stats: {
          conversionRate: 0.18,
          avgDuration: 240,
          satisfactionScore: 0.88,
          successRate: 0.82
        }
      },
      {
        id: 'agent_3',
        name: 'Plumbing Emergency Dispatch',
        description: 'Emergency plumbing dispatch agent with priority routing, technician matching, and real-time status updates. Includes emergency protocols and customer safety features.',
        author: {
          id: 'author_3',
          name: 'Emergency Services AI',
          avatar: 'https://via.placeholder.com/40',
          verified: false,
          rating: 4.6,
          totalAgents: 5
        },
        category: 'healthcare',
        industry: 'Emergency Services',
        tags: ['emergency', 'plumbing', 'dispatch', 'priority', 'safety'],
        price: {
          type: 'free',
          amount: 0,
          currency: 'USD'
        },
        rating: {
          average: 4.5,
          count: 34,
          distribution: {
            five: 25,
            four: 7,
            three: 2,
            two: 0,
            one: 0
          }
        },
        downloads: 234,
        likes: 23,
        shares: 7,
        status: 'published',
        featured: false,
        verified: false,
        createdAt: '2024-01-05T16:00:00Z',
        updatedAt: '2024-01-14T08:30:00Z',
        version: '1.2.1',
        compatibility: {
          minVersion: '2.0.0',
          maxVersion: '3.0.0',
          platforms: ['GHL', 'VAPI']
        },
        requirements: {
          ghlVersion: '2.0+',
          voiceProvider: 'ElevenLabs',
          llmProvider: 'OpenAI GPT-3.5',
          customFields: 6,
          workflows: 3
        },
        screenshots: [
          'https://via.placeholder.com/400x300'
        ],
        demoUrl: 'https://demo.emergency-ai.com/plumbing-dispatch',
        documentation: 'https://docs.emergency-ai.com/plumbing-dispatch',
        support: {
          email: 'support@emergency-ai.com',
          documentation: 'https://docs.emergency-ai.com',
          community: 'https://community.emergency-ai.com'
        },
        reviews: [],
        stats: {
          conversionRate: 0.95,
          avgDuration: 120,
          satisfactionScore: 0.94,
          successRate: 0.98
        }
      }
    ];

    const sampleCategories: MarketplaceCategory[] = [
      {
        id: 'fitness',
        name: 'Fitness & Wellness',
        description: 'Fitness studios, gyms, personal trainers, and wellness services',
        icon: '💪',
        color: 'text-orange-400',
        agentCount: 45,
        featured: true
      },
      {
        id: 'legal',
        name: 'Legal Services',
        description: 'Law firms, legal consultations, and legal service providers',
        icon: '⚖️',
        color: 'text-blue-400',
        agentCount: 23,
        featured: true
      },
      {
        id: 'healthcare',
        name: 'Healthcare',
        description: 'Medical practices, clinics, and healthcare service providers',
        icon: '🏥',
        color: 'text-green-400',
        agentCount: 67,
        featured: true
      },
      {
        id: 'real_estate',
        name: 'Real Estate',
        description: 'Real estate agents, property management, and real estate services',
        icon: '🏠',
        color: 'text-purple-400',
        agentCount: 34,
        featured: false
      },
      {
        id: 'automotive',
        name: 'Automotive',
        description: 'Car dealerships, auto repair, and automotive services',
        icon: '🚗',
        color: 'text-red-400',
        agentCount: 28,
        featured: false
      },
      {
        id: 'education',
        name: 'Education',
        description: 'Schools, training centers, and educational service providers',
        icon: '🎓',
        color: 'text-indigo-400',
        agentCount: 19,
        featured: false
      }
    ];

    const sampleStats: MarketplaceStats = {
      totalAgents: 156,
      totalDownloads: 15432,
      totalAuthors: 89,
      totalRevenue: 125000,
      featuredAgents: 12,
      topCategories: [
        { category: 'Fitness & Wellness', count: 45, growth: 0.15 },
        { category: 'Healthcare', count: 67, growth: 0.22 },
        { category: 'Legal Services', count: 23, growth: 0.08 },
        { category: 'Real Estate', count: 34, growth: 0.12 }
      ],
      topAuthors: [
        { author: 'Fitness AI Solutions', agents: 12, downloads: 3245, rating: 4.8 },
        { author: 'LegalTech Pro', agents: 8, downloads: 2156, rating: 4.9 },
        { author: 'Healthcare AI', agents: 15, downloads: 1890, rating: 4.7 }
      ]
    };

    setAgents(sampleAgents);
    setCategories(sampleCategories);
    setStats(sampleStats);
  }, []);

  const getPriceColor = (type: string) => {
    switch (type) {
      case 'free': return 'text-green-400 bg-green-100';
      case 'premium': return 'text-blue-400 bg-blue-100';
      case 'subscription': return 'text-purple-400 bg-purple-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'published': return 'text-green-400 bg-green-100';
      case 'draft': return 'text-yellow-400 bg-yellow-100';
      case 'pending': return 'text-blue-400 bg-blue-100';
      case 'rejected': return 'text-red-400 bg-red-100';
      case 'featured': return 'text-purple-400 bg-purple-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${
          i < Math.floor(rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'
        }`}
      />
    ));
  };

  const renderBrowseTab = () => (
    <div className="space-y-6">
      {/* Categories */}
      <div className="card p-6">
        <h2 className="text-xl font-semibold text-foreground mb-6">Categories</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`p-4 rounded-lg border-2 transition-all duration-200 ${
                selectedCategory === category.id
                  ? 'border-primary bg-primary/10'
                  : 'border-border hover:border-primary/50'
              }`}
            >
              <div className="text-3xl mb-2">{category.icon}</div>
              <h3 className="font-semibold text-foreground text-sm">{category.name}</h3>
              <p className="text-xs text-muted-foreground">{category.agentCount} agents</p>
            </button>
          ))}
        </div>
      </div>

      {/* Agents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {agents.map((agent) => (
          <div key={agent.id} className="card p-6 hover:shadow-lg transition-all duration-200">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-2">
                  <h3 className="font-semibold text-foreground">{agent.name}</h3>
                  {agent.featured && (
                    <span className="px-2 py-1 bg-purple-100 text-purple-600 text-xs font-medium rounded-full">
                      Featured
                    </span>
                  )}
                  {agent.verified && (
                    <CheckCircle className="w-4 h-4 text-blue-400" />
                  )}
                </div>
                <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                  {agent.description}
                </p>
                <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Star className="w-3 h-3" />
                    <span>{agent.rating.average}</span>
                    <span>({agent.rating.count})</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Download className="w-3 h-3" />
                    <span>{agent.downloads}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Heart className="w-3 h-3" />
                    <span>{agent.likes}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Author */}
            <div className="flex items-center space-x-3 mb-4">
              <img
                src={agent.author.avatar}
                alt={agent.author.name}
                className="w-8 h-8 rounded-full"
              />
              <div>
                <p className="text-sm font-medium text-foreground">{agent.author.name}</p>
                <p className="text-xs text-muted-foreground">
                  {agent.author.verified && '✓ '}Verified Author
                </p>
              </div>
            </div>

            {/* Price */}
            <div className="flex items-center justify-between mb-4">
              <div className={`px-3 py-1 rounded-full text-sm font-medium ${getPriceColor(agent.price.type)}`}>
                {agent.price.type === 'free' ? 'Free' : `$${agent.price.amount}`}
              </div>
              <div className="flex items-center space-x-2">
                <button className="btn btn-outline btn-sm">
                  <Eye className="w-4 h-4 mr-2" />
                  Preview
                </button>
                <button className="btn btn-primary btn-sm">
                  <Download className="w-4 h-4 mr-2" />
                  Install
                </button>
              </div>
            </div>

            {/* Tags */}
            <div className="flex flex-wrap gap-1">
              {agent.tags.slice(0, 3).map((tag) => (
                <span
                  key={tag}
                  className="px-2 py-1 bg-secondary text-xs text-muted-foreground rounded"
                >
                  {tag}
                </span>
              ))}
              {agent.tags.length > 3 && (
                <span className="px-2 py-1 bg-secondary text-xs text-muted-foreground rounded">
                  +{agent.tags.length - 3} more
                </span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderFeaturedTab = () => (
    <div className="space-y-6">
      <div className="card p-6">
        <h2 className="text-xl font-semibold text-foreground mb-6">Featured Agents</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {agents.filter(agent => agent.featured).map((agent) => (
            <div key={agent.id} className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 p-6 rounded-lg border border-purple-200">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <h3 className="text-lg font-semibold text-foreground">{agent.name}</h3>
                    <span className="px-2 py-1 bg-purple-100 text-purple-600 text-xs font-medium rounded-full">
                      Featured
                    </span>
                  </div>
                  <p className="text-muted-foreground mb-3">{agent.description}</p>
                  <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                    <div className="flex items-center space-x-1">
                      {renderStars(agent.rating.average)}
                      <span className="ml-1">{agent.rating.average}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Download className="w-4 h-4" />
                      <span>{agent.downloads} downloads</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className={`px-3 py-1 rounded-full text-sm font-medium ${getPriceColor(agent.price.type)}`}>
                  {agent.price.type === 'free' ? 'Free' : `$${agent.price.amount}`}
                </div>
                <button className="btn btn-primary">
                  <Download className="w-4 h-4 mr-2" />
                  Install Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="p-6 bg-background min-h-screen text-foreground">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Agent Marketplace</h1>
            <p className="text-muted-foreground">
              Discover, share, and install voice AI agents from the community
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <button className="btn btn-outline">
              <Upload className="w-4 h-4 mr-2" />
              Publish Agent
            </button>
            <button className="btn btn-outline">
              <Settings className="w-4 h-4 mr-2" />
              My Agents
            </button>
            <button className="btn btn-primary">
              <Plus className="w-4 h-4 mr-2" />
              Create Agent
            </button>
          </div>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Agents</p>
              <p className="text-2xl font-bold text-foreground">{stats.totalAgents}</p>
            </div>
            <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
              <Bot className="w-6 h-6 text-primary" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Downloads</p>
              <p className="text-2xl font-bold text-foreground">{stats.totalDownloads.toLocaleString()}</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <Download className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Authors</p>
              <p className="text-2xl font-bold text-foreground">{stats.totalAuthors}</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Revenue</p>
              <p className="text-2xl font-bold text-foreground">${stats.totalRevenue.toLocaleString()}</p>
            </div>
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <Trophy className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="mb-6">
        <div className="flex space-x-1 bg-secondary p-1 rounded-lg w-fit">
          {[
            { id: 'browse', label: 'Browse All', icon: Store },
            { id: 'featured', label: 'Featured', icon: Star },
            { id: 'trending', label: 'Trending', icon: TrendingUp },
            { id: 'new', label: 'New', icon: Plus },
            { id: 'my_agents', label: 'My Agents', icon: Bot },
            { id: 'favorites', label: 'Favorites', icon: Heart }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-primary text-primary-foreground shadow-lg'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Filters */}
      <div className="card p-6 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <input
                type="text"
                placeholder="Search agents..."
                className="w-full pl-10 input"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          <div className="flex space-x-2">
            <select
              className="input"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              <option value="all">All Categories</option>
              {categories.map(category => (
                <option key={category.id} value={category.id}>{category.name}</option>
              ))}
            </select>
            <select
              className="input"
              value={selectedPrice}
              onChange={(e) => setSelectedPrice(e.target.value)}
            >
              <option value="all">All Prices</option>
              <option value="free">Free</option>
              <option value="premium">Premium</option>
              <option value="subscription">Subscription</option>
            </select>
            <select
              className="input"
              value={selectedRating}
              onChange={(e) => setSelectedRating(e.target.value)}
            >
              <option value="all">All Ratings</option>
              <option value="5">5 Stars</option>
              <option value="4">4+ Stars</option>
              <option value="3">3+ Stars</option>
            </select>
            <select
              className="input"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
            >
              <option value="popular">Most Popular</option>
              <option value="rating">Highest Rated</option>
              <option value="newest">Newest</option>
              <option value="price_low">Price: Low to High</option>
              <option value="price_high">Price: High to Low</option>
            </select>
          </div>
        </div>
      </div>

      {/* Content */}
      {activeTab === 'browse' && renderBrowseTab()}
      {activeTab === 'featured' && renderFeaturedTab()}
      {activeTab === 'trending' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Trending Agents</h2>
          <p className="text-muted-foreground">Trending agents interface will be displayed here.</p>
        </div>
      )}
      {activeTab === 'new' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">New Agents</h2>
          <p className="text-muted-foreground">New agents interface will be displayed here.</p>
        </div>
      )}
      {activeTab === 'my_agents' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">My Agents</h2>
          <p className="text-muted-foreground">My agents management interface will be displayed here.</p>
        </div>
      )}
      {activeTab === 'favorites' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Favorites</h2>
          <p className="text-muted-foreground">Favorites interface will be displayed here.</p>
        </div>
      )}
    </div>
  );
};

export default AgentMarketplace;
