import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Trash2, 
  Eye, 
  Download, 
  Plus, 
  Edit,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Activity,
  Clock,
  BarChart3,
  FileText,
  TestTube,
  Zap,
  Phone,
  MessageSquare,
  Calendar,
  CreditCard,
  Bug
} from 'lucide-react';

interface TestCase {
  id: string;
  name: string;
  description: string;
  steps: string[];
  expected: string;
  status: 'pending' | 'pass' | 'fail' | 'warning' | 'running';
  category: string;
  duration?: number;
  timestamp?: Date;
}

interface TestResult {
  id: string;
  name: string;
  status: 'pass' | 'fail' | 'warning';
  duration: number;
  timestamp: Date;
  details: string;
  transcript?: string;
}

interface TestScenario {
  id: string;
  name: string;
  description: string;
  steps: string[];
  expected: string;
  category: string;
}

const QAGoldenPack: React.FC = () => {
  const [testCases, setTestCases] = useState<TestCase[]>([]);
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [scenarios, setScenarios] = useState<TestScenario[]>([]);
  const [activeTab, setActiveTab] = useState<'test-cases' | 'scenarios' | 'reports' | 'analytics'>('test-cases');
  const [isRunning, setIsRunning] = useState(false);
  const [testProgress, setTestProgress] = useState(0);
  const [currentTest, setCurrentTest] = useState<string | null>(null);
  const [logs, setLogs] = useState<Array<{ type: string; message: string; timestamp: string }>>([
    { type: 'info', message: 'QA Golden Pack initialized. Ready for testing.', timestamp: new Date().toLocaleTimeString() }
  ]);

  const predefinedScenarios: TestScenario[] = [
    {
      id: '1',
      name: 'Lead Qualification',
      description: 'Test agent\'s ability to qualify leads through conversation',
      steps: ['User expresses interest in service', 'Agent asks qualifying questions', 'Agent captures lead information', 'Agent schedules follow-up'],
      expected: 'Lead information captured in GHL with proper qualification score',
      category: 'sales'
    },
    {
      id: '2',
      name: 'Appointment Booking',
      description: 'Test appointment scheduling functionality',
      steps: ['User requests appointment', 'Agent checks availability', 'Agent books appointment', 'Agent sends confirmation'],
      expected: 'Appointment created in calendar with confirmation sent',
      category: 'scheduling'
    },
    {
      id: '3',
      name: 'Customer Support',
      description: 'Test support ticket creation and routing',
      steps: ['User reports issue', 'Agent categorizes problem', 'Agent creates support ticket', 'Agent provides resolution or escalates'],
      expected: 'Support ticket created with proper categorization and routing',
      category: 'support'
    },
    {
      id: '4',
      name: 'Payment Processing',
      description: 'Test payment collection and processing',
      steps: ['User wants to make payment', 'Agent collects payment info', 'Agent processes payment', 'Agent confirms transaction'],
      expected: 'Payment processed successfully with confirmation',
      category: 'billing'
    }
  ];

  const defaultTestCases: TestCase[] = [
    {
      id: '1',
      name: 'Basic Greeting',
      description: 'Test agent responds to basic greeting',
      steps: ['User says "Hello"', 'Agent responds with greeting'],
      expected: 'Agent greets user professionally',
      status: 'pending',
      category: 'basic'
    },
    {
      id: '2',
      name: 'Lead Qualification',
      description: 'Test lead qualification process',
      steps: ['User expresses interest', 'Agent asks qualifying questions', 'Agent captures lead information'],
      expected: 'Lead information captured in GHL',
      status: 'pending',
      category: 'sales'
    },
    {
      id: '3',
      name: 'Appointment Booking',
      description: 'Test appointment scheduling',
      steps: ['User requests appointment', 'Agent checks availability', 'Agent books appointment'],
      expected: 'Appointment created in calendar',
      status: 'pending',
      category: 'scheduling'
    },
    {
      id: '4',
      name: 'Payment Processing',
      description: 'Test payment collection',
      steps: ['User wants to make payment', 'Agent collects payment info', 'Agent processes payment'],
      expected: 'Payment processed successfully',
      status: 'pending',
      category: 'billing'
    },
    {
      id: '5',
      name: 'Error Handling',
      description: 'Test error handling and recovery',
      steps: ['Simulate error condition', 'Agent handles error gracefully', 'Agent provides alternative solution'],
      expected: 'Error handled without call termination',
      status: 'pending',
      category: 'error'
    }
  ];

  useEffect(() => {
    loadTestCases();
    loadScenarios();
  }, []);

  const loadTestCases = () => {
    const saved = localStorage.getItem('ghl-test-cases');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setTestCases(parsed.map((tc: any) => ({
          ...tc,
          timestamp: tc.timestamp ? new Date(tc.timestamp) : undefined
        })));
      } catch (error) {
        console.error('Failed to load test cases:', error);
        setTestCases(defaultTestCases);
      }
    } else {
      setTestCases(defaultTestCases);
    }
  };

  const loadScenarios = () => {
    const saved = localStorage.getItem('ghl-scenarios');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setScenarios([...predefinedScenarios, ...parsed]);
      } catch (error) {
        console.error('Failed to load scenarios:', error);
        setScenarios(predefinedScenarios);
      }
    } else {
      setScenarios(predefinedScenarios);
    }
  };

  const saveTestCases = (newTestCases: TestCase[]) => {
    localStorage.setItem('ghl-test-cases', JSON.stringify(newTestCases));
    setTestCases(newTestCases);
  };

  const addLog = (type: string, message: string) => {
    const newLog = {
      type,
      message,
      timestamp: new Date().toLocaleTimeString()
    };
    setLogs(prev => [...prev, newLog]);
  };

  const runAllTests = async () => {
    if (isRunning) return;
    
    setIsRunning(true);
    setTestProgress(0);
    addLog('info', 'Starting test suite execution...');
    
    let passed = 0;
    let failed = 0;
    let warnings = 0;
    
    for (let i = 0; i < testCases.length; i++) {
      const testCase = testCases[i];
      setCurrentTest(testCase.id);
      setTestProgress((i / testCases.length) * 100);
      
      try {
        const result = await runTestCase(testCase.id);
        if (result.status === 'pass') passed++;
        else if (result.status === 'fail') failed++;
        else if (result.status === 'warning') warnings++;
      } catch (error) {
        failed++;
        addLog('error', `Test ${testCase.name} failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
      
      // Simulate test execution time
      await delay(1000 + Math.random() * 2000);
    }
    
    setTestProgress(100);
    setCurrentTest(null);
    addLog('success', `Test suite completed: ${passed} passed, ${failed} failed, ${warnings} warnings`);
    
    setIsRunning(false);
  };

  const runTestCase = async (testId: string) => {
    const testCase = testCases.find(t => t.id === testId);
    if (!testCase) throw new Error('Test case not found');
    
    addLog('info', `Running test: ${testCase.name}`);
    
    // Update test case status to running
    const updatedTestCases = testCases.map(tc => 
      tc.id === testId ? { ...tc, status: 'running' as const } : tc
    );
    saveTestCases(updatedTestCases);
    
    // Simulate test execution
    const success = Math.random() > 0.2; // 80% success rate
    const status = success ? 'pass' : (Math.random() > 0.5 ? 'fail' : 'warning');
    const duration = Math.random() * 3000 + 1000;
    
    // Update test case status
    const finalTestCases = updatedTestCases.map(tc => 
      tc.id === testId ? { ...tc, status: status as any, duration, timestamp: new Date() } : tc
    );
    saveTestCases(finalTestCases);
    
    const result: TestResult = {
      id: testId,
      name: testCase.name,
      status,
      duration,
      timestamp: new Date(),
      details: success ? 'Test passed successfully' : 'Test failed with errors',
      transcript: generateMockTranscript(testCase.name)
    };
    
    setTestResults(prev => [result, ...prev]);
    
    addLog(status === 'pass' ? 'success' : status === 'fail' ? 'error' : 'warning', 
      `${testCase.name}: ${result.details}`);
    
    return result;
  };

  const generateMockTranscript = (testName: string): string => {
    const transcripts: { [key: string]: string } = {
      'Basic Greeting': `User: Hello\nAgent: Hi there! Thank you for calling. How can I help you today?\nUser: I'm interested in your services\nAgent: Great! I'd be happy to help you learn more about what we offer.`,
      'Lead Qualification': `User: I'm looking for marketing help\nAgent: That's wonderful! I'd love to help you with your marketing needs. Can you tell me a bit about your business?\nUser: We're a small restaurant\nAgent: Perfect! What's your biggest marketing challenge right now?`,
      'Appointment Booking': `User: I'd like to schedule a consultation\nAgent: I'd be happy to help you schedule that. What day works best for you?\nUser: How about next Tuesday?\nAgent: Let me check our availability... Yes, we have Tuesday at 2 PM available.`,
      'Payment Processing': `User: I want to pay my invoice\nAgent: I can help you with that. What's your invoice number?\nUser: INV-12345\nAgent: Perfect, I found your invoice. The amount is $500. How would you like to pay?`,
      'Error Handling': `User: I'm having trouble with my account\nAgent: I understand your frustration. Let me help you resolve this issue. Can you describe what's happening?\nUser: I can't log in\nAgent: I'll reset your password and send you a new one via email.`
    };
    
    return transcripts[testName] || 'Mock transcript not available';
  };

  const createTestCase = () => {
    const name = prompt('Enter test case name:');
    if (name) {
      const testCase: TestCase = {
        id: Date.now().toString(),
        name,
        description: 'New test case',
        steps: [],
        expected: '',
        status: 'pending',
        category: 'custom'
      };
      
      const newTestCases = [...testCases, testCase];
      saveTestCases(newTestCases);
      addLog('success', `Created test case: ${name}`);
    }
  };

  const editTestCase = (testId: string) => {
    const testCase = testCases.find(t => t.id === testId);
    if (testCase) {
      const newName = prompt('Enter new name:', testCase.name);
      if (newName) {
        const updatedTestCases = testCases.map(tc => 
          tc.id === testId ? { ...tc, name: newName } : tc
        );
        saveTestCases(updatedTestCases);
      }
    }
  };

  const deleteTestCase = (testId: string) => {
    if (confirm('Are you sure you want to delete this test case?')) {
      const updatedTestCases = testCases.filter(t => t.id !== testId);
      saveTestCases(updatedTestCases);
      addLog('warning', 'Test case deleted');
    }
  };

  const exportReport = () => {
    const report = {
      timestamp: new Date().toISOString(),
      summary: {
        total: testCases.length,
        passed: testCases.filter(t => t.status === 'pass').length,
        failed: testCases.filter(t => t.status === 'fail').length,
        warnings: testCases.filter(t => t.status === 'warning').length
      },
      testCases,
      results: testResults
    };
    
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `qa_report_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    addLog('success', 'Test report exported');
  };

  const clearLogs = () => {
    setLogs([{ type: 'info', message: 'Logs cleared.', timestamp: new Date().toLocaleTimeString() }]);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pass': return 'text-green-400';
      case 'fail': return 'text-red-400';
      case 'warning': return 'text-yellow-400';
      case 'running': return 'text-blue-400';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pass': return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'fail': return <XCircle className="w-4 h-4 text-red-400" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
      case 'running': return <Activity className="w-4 h-4 text-blue-400 animate-pulse" />;
      default: return <Clock className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const getLogColor = (type: string) => {
    switch (type) {
      case 'error': return 'text-red-400';
      case 'warning': return 'text-yellow-400';
      case 'success': return 'text-green-400';
      case 'info': return 'text-blue-400';
      default: return 'text-muted-foreground';
    }
  };

  const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

  const stats = {
    total: testCases.length,
    passed: testCases.filter(t => t.status === 'pass').length,
    failed: testCases.filter(t => t.status === 'fail').length,
    warnings: testCases.filter(t => t.status === 'warning').length
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground gradient-text">QA Golden Pack</h1>
          <p className="text-muted-foreground mt-2">Comprehensive testing framework for validating voice AI agents and workflows</p>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={runAllTests} 
            disabled={isRunning}
            className="btn btn-primary flex items-center gap-2"
          >
            {isRunning ? (
              <>
                <Activity className="w-4 h-4 animate-spin" />
                Running Tests...
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                Run All Tests
              </>
            )}
          </button>
          <button onClick={createTestCase} className="btn btn-outline flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Create Test Case
          </button>
          <button onClick={exportReport} className="btn btn-outline flex items-center gap-2">
            <Download className="w-4 h-4" />
            Export Report
          </button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="card p-6 text-center">
          <div className="text-3xl font-bold gradient-text mb-2">{stats.total}</div>
          <div className="text-sm text-muted-foreground">Total Tests</div>
        </div>
        <div className="card p-6 text-center">
          <div className="text-3xl font-bold text-green-400 mb-2">{stats.passed}</div>
          <div className="text-sm text-muted-foreground">Passed</div>
        </div>
        <div className="card p-6 text-center">
          <div className="text-3xl font-bold text-red-400 mb-2">{stats.failed}</div>
          <div className="text-sm text-muted-foreground">Failed</div>
        </div>
        <div className="card p-6 text-center">
          <div className="text-3xl font-bold text-yellow-400 mb-2">{stats.warnings}</div>
          <div className="text-sm text-muted-foreground">Warnings</div>
        </div>
      </div>

      {/* Test Progress */}
      {isRunning && (
        <div className="card p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Test Execution Progress</h3>
          <div className="w-full bg-muted rounded-full h-4 relative overflow-hidden mb-4">
            <div 
              className="progress-bar bg-primary rounded-full h-full transition-all duration-500"
              style={{ width: `${testProgress}%` }}
            />
          </div>
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>{currentTest ? `Running: ${testCases.find(t => t.id === currentTest)?.name}` : 'Preparing tests...'}</span>
            <span>{Math.round(testProgress)}%</span>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex border-b border-border">
        {[
          { id: 'test-cases', label: 'Test Cases', icon: TestTube },
          { id: 'scenarios', label: 'Test Scenarios', icon: FileText },
          { id: 'reports', label: 'Test Reports', icon: BarChart3 },
          { id: 'analytics', label: 'Analytics', icon: Activity }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-2 px-4 py-2 border-b-2 transition-colors ${
              activeTab === tab.id
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'test-cases' && (
        <div className="space-y-4">
          <div className="card p-6">
            <h3 className="text-xl font-semibold text-foreground mb-4">Voice AI Test Cases</h3>
            <div className="space-y-4">
              {testCases.map((testCase) => (
                <div key={testCase.id} className={`test-case p-4 rounded-lg border ${
                  testCase.status === 'pass' ? 'border-green-400 bg-green-400/10' :
                  testCase.status === 'fail' ? 'border-red-400 bg-red-400/10' :
                  testCase.status === 'warning' ? 'border-yellow-400 bg-yellow-400/10' :
                  testCase.status === 'running' ? 'border-blue-400 bg-blue-400/10' :
                  'border-border'
                }`}>
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        {getStatusIcon(testCase.status)}
                        <h4 className="font-medium text-foreground">{testCase.name}</h4>
                        <span className={`text-sm font-medium ${getStatusColor(testCase.status)}`}>
                          {testCase.status.toUpperCase()}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">{testCase.description}</p>
                      <div className="flex items-center gap-4 text-xs">
                        <span className="px-2 py-1 rounded bg-muted">{testCase.category}</span>
                        {testCase.duration && (
                          <span className="text-muted-foreground">
                            Duration: {Math.round(testCase.duration / 1000)}s
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => runTestCase(testCase.id)}
                        disabled={isRunning}
                        className="btn btn-primary btn-sm flex items-center gap-1"
                      >
                        <Play className="w-3 h-3" />
                        Run
                      </button>
                      <button 
                        onClick={() => editTestCase(testCase.id)}
                        className="btn btn-outline btn-sm flex items-center gap-1"
                      >
                        <Edit className="w-3 h-3" />
                        Edit
                      </button>
                      <button 
                        onClick={() => deleteTestCase(testCase.id)}
                        className="btn btn-destructive btn-sm flex items-center gap-1"
                      >
                        <Trash2 className="w-3 h-3" />
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'scenarios' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="card p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Predefined Scenarios</h3>
            <div className="space-y-3">
              {scenarios.map((scenario) => (
                <div key={scenario.id} className="card p-4">
                  <h4 className="font-medium text-foreground">{scenario.name}</h4>
                  <p className="text-sm text-muted-foreground mb-2">{scenario.description}</p>
                  <div className="flex gap-2">
                    <button className="btn btn-primary btn-sm">Run Scenario</button>
                    <button className="btn btn-outline btn-sm">Edit</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="card p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Custom Scenarios</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Scenario Name</label>
                <input 
                  type="text" 
                  className="w-full p-2 rounded-md bg-card border border-border" 
                  placeholder="Enter scenario name" 
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Test Steps</label>
                <textarea 
                  className="w-full p-2 rounded-md bg-card border border-border h-32" 
                  placeholder="Describe the test steps..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Expected Outcome</label>
                <textarea 
                  className="w-full p-2 rounded-md bg-card border border-border h-24" 
                  placeholder="What should happen?"
                />
              </div>
              <button className="btn btn-primary">Save Scenario</button>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'reports' && (
        <div className="space-y-6">
          <div className="card p-6">
            <h3 className="text-xl font-semibold text-foreground mb-4">Latest Test Report</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-400 mb-2">{stats.passed}</div>
                <div className="text-sm text-muted-foreground">Tests Passed</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-red-400 mb-2">{stats.failed}</div>
                <div className="text-sm text-muted-foreground">Tests Failed</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-400 mb-2">
                  {testResults.length > 0 ? Math.round(testResults.reduce((acc, r) => acc + r.duration, 0) / 1000) : 0}s
                </div>
                <div className="text-sm text-muted-foreground">Total Duration</div>
              </div>
            </div>
            
            <div className="space-y-4">
              <h4 className="font-medium text-foreground">Recent Test Results</h4>
              <div className="space-y-2">
                {testResults.slice(0, 5).map((result) => (
                  <div key={result.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(result.status)}
                      <span className="font-medium">{result.name}</span>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>{Math.round(result.duration / 1000)}s</span>
                      <span>{result.timestamp.toLocaleTimeString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="card p-6">
            <h3 className="text-xl font-semibold text-foreground mb-4">Call Transcripts</h3>
            <div className="space-y-4">
              {testResults.slice(0, 3).map((result) => (
                <div key={result.id} className="transcript p-4 bg-muted rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium">{result.name}</h4>
                    <span className="text-sm text-muted-foreground">{result.timestamp.toLocaleString()}</span>
                  </div>
                  <div className="text-sm whitespace-pre-line">{result.transcript}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'analytics' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="card p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Test Performance</h3>
            <div className="space-y-4">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Average Response Time</span>
                <span className="font-medium">1.2s</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Success Rate</span>
                <span className="font-medium text-green-400">94.5%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Intent Recognition</span>
                <span className="font-medium text-green-400">97.8%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Action Execution</span>
                <span className="font-medium text-green-400">92.1%</span>
              </div>
            </div>
          </div>
          
          <div className="card p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Common Issues</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Timeout Errors</span>
                <span className="text-red-400">12</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Intent Misclassification</span>
                <span className="text-yellow-400">8</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Action Failures</span>
                <span className="text-red-400">5</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Webhook Timeouts</span>
                <span className="text-yellow-400">3</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Test Logs */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold text-foreground">Test Execution Logs</h3>
          <button onClick={clearLogs} className="btn btn-outline flex items-center gap-2">
            <Trash2 className="w-4 h-4" />
            Clear Logs
          </button>
        </div>
        <div className="bg-muted p-4 rounded-md h-64 overflow-y-auto font-mono text-sm">
          {logs.map((log, index) => (
            <div key={index} className={`py-1 ${getLogColor(log.type)}`}>
              [{log.timestamp}] {log.message}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default QAGoldenPack;
