import React, { useState, useEffect } from 'react';
import { 
  Bot, 
  Sparkles, 
  Zap, 
  Target, 
  Settings, 
  Play, 
  Pause, 
  RefreshCw, 
  Download, 
  Upload, 
  Save, 
  Edit, 
  Trash2, 
  Plus, 
  Minus, 
  ChevronDown, 
  ChevronRight, 
  Eye, 
  EyeOff, 
  Filter, 
  Search, 
  SortAsc, 
  SortDesc, 
  MoreHorizontal, 
  Star, 
  ThumbsUp, 
  ThumbsDown, 
  Heart, 
  Smile, 
  Frown, 
  Meh, 
  Award, 
  Trophy, 
  Medal, 
  Crown, 
  Flame, 
  Lightning, 
  Rocket, 
  Shield, 
  Lock, 
  Unlock, 
  Key, 
  Wrench, 
  Cog, 
  Sliders, 
  ToggleLeft, 
  ToggleRight, 
  Switch, 
  Power, 
  PowerOff, 
  Battery, 
  BatteryCharging, 
  Wifi, 
  WifiOff, 
  Signal, 
  SignalZero, 
  SignalOne, 
  SignalTwo, 
  SignalThree, 
  SignalFour, 
  SignalFive,
  MessageSquare,
  Mic,
  Headphones,
  Volume2,
  VolumeX,
  SkipForward,
  SkipBack,
  RotateCcw,
  BarChart3,
  LineChart,
  PieChart,
  Activity,
  Clock,
  Users,
  Phone,
  Brain,
  TrendingUp,
  TrendingDown,
  Database,
  Server,
  Globe,
  FileText,
  FileCheck,
  FileX,
  FileAlert,
  FileLock,
  FileShield,
  FileSearch,
  FileCode,
  FileImage,
  FileVideo,
  FileAudio,
  FileArchive,
  FileSpreadsheet,
  FilePresentation,
  FilePdf,
  FileWord,
  FileExcel,
  FilePowerpoint,
  FileZip,
  FileRar,
  File7z,
  FileTar,
  FileGz,
  FileBz2,
  FileXz,
  FileLz4,
  FileZstd,
  FileCab,
  FileIso,
  FileDmg,
  FileImg,
  FileVhd,
  FileVdi,
  FileVmdk,
  FileOva,
  FileOvf,
  FileVagrant,
  FileDocker,
  FileKubernetes,
  FileTerraform,
  FileAnsible,
  FileChef,
  FilePuppet,
  FileSalt,
  FileConsul,
  FileVault,
  FileNomad,
  FileDockerCompose,
  FileKustomize,
  FileHelm,
  FileIstio,
  FileLinkerd,
  FileEnvoy,
  FileNginx,
  FileApache,
  FileIis,
  FileTomcat,
  FileJetty,
  FileWildfly,
  FileWeblogic,
  FileWebsphere,
  FileGlassfish,
  FileJboss,
  FileResin,
  FileGeronimo,
  FileOpenliberty,
  FilePayara,
  FileTomee,
  FileWeld,
  FileDeltaspike,
  FileShiro,
  FileSpring,
  FileHibernate,
  FileMybatis,
  FileJpa,
  FileJdbc,
  FileJndi,
  FileJms,
  FileJta,
  FileJca,
  FileJaxb,
  FileJaxrs,
  FileJaxws,
  FileJsf,
  FileStruts,
  FileVaadin,
  FileGwt,
  FileWicket,
  FileTapestry,
  FileSeam,
  FileRichfaces,
  FilePrimefaces,
  FileIcefaces,
  FileOpenfaces,
  FileButterfaces,
  FileBootsfaces,
  FileOmnifaces,
  FileAngularfaces,
  FileAngular,
  FileReact,
  FileVue,
  FileSvelte,
  FileEmber,
  FileBackbone,
  FileKnockout,
  FileMithril,
  FilePreact,
  FileInferno,
  FileRiot,
  FileStencil,
  FileLit,
  FilePolymer,
  FileAurelia,
  FileMithril,
  FileHyperapp,
  FileAlpine,
  FileStimulus,
  FileTurbo,
  FileHotwire,
  FileLivewire,
  FileInertia,
  FileNext,
  FileNuxt,
  FileSapper,
  FileSveltekit,
  FileRemix,
  FileSolid,
  FileQwik,
  FileMarko,
  FileMithril,
  FileHyperapp,
  FileAlpine,
  FileStimulus,
  FileTurbo,
  FileHotwire,
  FileLivewire,
  FileInertia,
  FileNext,
  FileNuxt,
  FileSapper,
  FileSveltekit,
  FileRemix,
  FileSolid,
  FileQwik,
  FileMarko,
  Info,
  AlertTriangle,
  CheckCircle,
  XCircle,
  ExternalLink,
  Copy,
  Link,
  Unlink,
  Send,
  Receive,
  ArrowRight,
  ArrowLeft,
  ArrowUp,
  ArrowDown,
  RotateCw,
  RotateCcw,
  Move,
  MoveUp,
  MoveDown,
  MoveLeft,
  MoveRight,
  Maximize,
  Minimize,
  Maximize2,
  Minimize2,
  Square,
  Circle,
  Triangle,
  Hexagon,
  Octagon,
  Pentagon,
  Diamond,
  RectangleHorizontal,
  RectangleVertical,
  Ellipse,
  Oval,
  Parallelogram,
  Trapezoid,
  Rhombus,
  Kite,
  Star as StarIcon,
  Heart as HeartIcon,
  Smile as SmileIcon,
  Frown as FrownIcon,
  Meh as MehIcon,
  ThumbsUp as ThumbsUpIcon,
  ThumbsDown as ThumbsDownIcon,
  Award as AwardIcon,
  Trophy as TrophyIcon,
  Medal as MedalIcon,
  Crown as CrownIcon,
  Flame as FlameIcon,
  Lightning as LightningIcon,
  Rocket as RocketIcon,
  Shield as ShieldIcon,
  Lock as LockIcon,
  Unlock as UnlockIcon,
  Key as KeyIcon,
  Wrench as WrenchIcon,
  Cog as CogIcon,
  Sliders as SlidersIcon,
  ToggleLeft as ToggleLeftIcon,
  ToggleRight as ToggleRightIcon,
  Switch as SwitchIcon,
  Power as PowerIcon,
  PowerOff as PowerOffIcon,
  Battery as BatteryIcon,
  BatteryCharging as BatteryChargingIcon,
  Wifi as WifiIcon,
  WifiOff as WifiOffIcon,
  Signal as SignalIcon,
  SignalZero as SignalZeroIcon,
  SignalOne as SignalOneIcon,
  SignalTwo as SignalTwoIcon,
  SignalThree as SignalThreeIcon,
  SignalFour as SignalFourIcon,
  SignalFive as SignalFiveIcon,
  MessageSquare as MessageSquareIcon,
  Mic as MicIcon,
  Headphones as HeadphonesIcon,
  Volume2 as Volume2Icon,
  VolumeX as VolumeXIcon,
  Play as PlayIcon,
  Pause as PauseIcon,
  SkipForward as SkipForwardIcon,
  SkipBack as SkipBackIcon,
  RotateCcw as RotateCcwIcon,
  BarChart3 as BarChart3Icon,
  LineChart as LineChartIcon,
  PieChart as PieChartIcon,
  Activity as ActivityIcon,
  Clock as ClockIcon,
  Phone as PhoneIcon,
  Bot as BotIcon,
  Brain as BrainIcon,
  Target as TargetIcon,
  TrendingUp as TrendingUpIcon,
  TrendingDown as TrendingDownIcon,
  Database as DatabaseIcon,
  Server as ServerIcon,
  Globe as GlobeIcon,
  FileText as FileTextIcon,
  FileCheck as FileCheckIcon,
  FileX as FileXIcon,
  FileAlert as FileAlertIcon,
  FileLock as FileLockIcon,
  FileShield as FileShieldIcon,
  FileSearch as FileSearchIcon,
  FileCode as FileCodeIcon,
  FileImage as FileImageIcon,
  FileVideo as FileVideoIcon,
  FileAudio as FileAudioIcon,
  FileArchive as FileArchiveIcon,
  FileSpreadsheet as FileSpreadsheetIcon,
  FilePresentation as FilePresentationIcon,
  FilePdf as FilePdfIcon,
  FileWord as FileWordIcon,
  FileExcel as FileExcelIcon,
  FilePowerpoint as FilePowerpointIcon,
  FileZip as FileZipIcon,
  FileRar as FileRarIcon,
  File7z as File7zIcon,
  FileTar as FileTarIcon,
  FileGz as FileGzIcon,
  FileBz2 as FileBz2Icon,
  FileXz as FileXzIcon,
  FileLz4 as FileLz4Icon,
  FileZstd as FileZstdIcon,
  FileCab as FileCabIcon,
  FileIso as FileIsoIcon,
  FileDmg as FileDmgIcon,
  FileImg as FileImgIcon,
  FileVhd as FileVhdIcon,
  FileVdi as FileVdiIcon,
  FileVmdk as FileVmdkIcon,
  FileOva as FileOvaIcon,
  FileOvf as FileOvfIcon,
  FileVagrant as FileVagrantIcon,
  FileDocker as FileDockerIcon,
  FileKubernetes as FileKubernetesIcon,
  FileTerraform as FileTerraformIcon,
  FileAnsible as FileAnsibleIcon,
  FileChef as FileChefIcon,
  FilePuppet as FilePuppetIcon,
  FileSalt as FileSaltIcon,
  FileConsul as FileConsulIcon,
  FileVault as FileVaultIcon,
  FileNomad as FileNomadIcon,
  FileDockerCompose as FileDockerComposeIcon,
  FileKustomize as FileKustomizeIcon,
  FileHelm as FileHelmIcon,
  FileIstio as FileIstioIcon,
  FileLinkerd as FileLinkerdIcon,
  FileEnvoy as FileEnvoyIcon,
  FileNginx as FileNginxIcon,
  FileApache as FileApacheIcon,
  FileIis as FileIisIcon,
  FileTomcat as FileTomcatIcon,
  FileJetty as FileJettyIcon,
  FileWildfly as FileWildflyIcon,
  FileWeblogic as FileWeblogicIcon,
  FileWebsphere as FileWebsphereIcon,
  FileGlassfish as FileGlassfishIcon,
  FileJboss as FileJbossIcon,
  FileResin as FileResinIcon,
  FileGeronimo as FileGeronimoIcon,
  FileOpenliberty as FileOpenlibertyIcon,
  FilePayara as FilePayaraIcon,
  FileTomee as FileTomeeIcon,
  FileWeld as FileWeldIcon,
  FileDeltaspike as FileDeltaspikeIcon,
  FileShiro as FileShiroIcon,
  FileSpring as FileSpringIcon,
  FileHibernate as FileHibernateIcon,
  FileMybatis as FileMybatisIcon,
  FileJpa as FileJpaIcon,
  FileJdbc as FileJdbcIcon,
  FileJndi as FileJndiIcon,
  FileJms as FileJmsIcon,
  FileJta as FileJtaIcon,
  FileJca as FileJcaIcon,
  FileJaxb as FileJaxbIcon,
  FileJaxrs as FileJaxrsIcon,
  FileJaxws as FileJaxwsIcon,
  FileJsf as FileJsfIcon,
  FileStruts as FileStrutsIcon,
  FileVaadin as FileVaadinIcon,
  FileGwt as FileGwtIcon,
  FileWicket as FileWicketIcon,
  FileTapestry as FileTapestryIcon,
  FileSeam as FileSeamIcon,
  FileRichfaces as FileRichfacesIcon,
  FilePrimefaces as FilePrimefacesIcon,
  FileIcefaces as FileIcefacesIcon,
  FileOpenfaces as FileOpenfacesIcon,
  FileButterfaces as FileButterfacesIcon,
  FileBootsfaces as FileBootsfacesIcon,
  FileOmnifaces as FileOmnifacesIcon,
  FileAngularfaces as FileAngularfacesIcon,
  FileAngular as FileAngularIcon,
  FileReact as FileReactIcon,
  FileVue as FileVueIcon,
  FileSvelte as FileSvelteIcon,
  FileEmber as FileEmberIcon,
  FileBackbone as FileBackboneIcon,
  FileKnockout as FileKnockoutIcon,
  FileMithril as FileMithrilIcon,
  FilePreact as FilePreactIcon,
  FileInferno as FileInfernoIcon,
  FileRiot as FileRiotIcon,
  FileStencil as FileStencilIcon,
  FileLit as FileLitIcon,
  FilePolymer as FilePolymerIcon,
  FileAurelia as FileAureliaIcon,
  FileMithril as FileMithrilIcon,
  FileHyperapp as FileHyperappIcon,
  FileAlpine as FileAlpineIcon,
  FileStimulus as FileStimulusIcon,
  FileTurbo as FileTurboIcon,
  FileHotwire as FileHotwireIcon,
  FileLivewire as FileLivewireIcon,
  FileInertia as FileInertiaIcon,
  FileNext as FileNextIcon,
  FileNuxt as FileNuxtIcon,
  FileSapper as FileSapperIcon,
  FileSveltekit as FileSveltekitIcon,
  FileRemix as FileRemixIcon,
  FileSolid as FileSolidIcon,
  FileQwik as FileQwikIcon,
  FileMarko as FileMarkoIcon,
  FileMithril as FileMithrilIcon,
  FileHyperapp as FileHyperappIcon,
  FileAlpine as FileAlpineIcon,
  FileStimulus as FileStimulusIcon,
  FileTurbo as FileTurboIcon,
  FileHotwire as FileHotwireIcon,
  FileLivewire as FileLivewireIcon,
  FileInertia as FileInertiaIcon,
  FileNext as FileNextIcon,
  FileNuxt as FileNuxtIcon,
  FileSapper as FileSapperIcon,
  FileSveltekit as FileSveltekitIcon,
  FileRemix as FileRemixIcon,
  FileSolid as FileSolidIcon,
  FileQwik as FileQwikIcon,
  FileMarko as FileMarkoIcon
} from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';

interface AITemplate {
  id: string;
  name: string;
  description: string;
  industry: string;
  category: string;
  complexity: 'beginner' | 'intermediate' | 'advanced' | 'enterprise';
  ghlBestPractices: {
    customFields: string[];
    workflows: string[];
    pipelines: string[];
    tags: string[];
    mergeTags: string[];
    webhooks: string[];
    compliance: string[];
  };
  voiceConfig: {
    provider: string;
    voiceId: string;
    language: string;
    accent: string;
    speed: number;
    pitch: number;
    emotion: string;
  };
  llmConfig: {
    provider: string;
    model: string;
    temperature: number;
    maxTokens: number;
    systemPrompt: string;
    userPrompt: string;
  };
  conversationFlow: {
    intents: Array<{
      name: string;
      description: string;
      examples: string[];
      responses: string[];
      ghlActions: string[];
    }>;
    fallbacks: Array<{
      scenario: string;
      response: string;
      action: string;
    }>;
    transfers: Array<{
      condition: string;
      department: string;
      priority: string;
    }>;
  };
  performanceMetrics: {
    expectedConversionRate: number;
    expectedAvgDuration: number;
    expectedCostPerCall: number;
    expectedSuccessRate: number;
  };
  deployment: {
    readinessScore: number;
    requirements: string[];
    dependencies: string[];
    estimatedSetupTime: string;
  };
  createdAt: string;
  updatedAt: string;
  author: string;
  downloads: number;
  rating: number;
  tags: string[];
}

interface TemplateGenerationRequest {
  industry: string;
  businessType: string;
  goals: string[];
  targetAudience: string;
  keyServices: string[];
  complianceRequirements: string[];
  budget: 'low' | 'medium' | 'high' | 'enterprise';
  complexity: 'simple' | 'moderate' | 'complex' | 'enterprise';
  customRequirements: string;
}

const AITemplateGenerator: React.FC = () => {
  const { darkMode } = useStore();
  const [templates, setTemplates] = useState<AITemplate[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [activeTab, setActiveTab] = useState<'generator' | 'templates' | 'best-practices' | 'analytics'>('generator');
  const [generationRequest, setGenerationRequest] = useState<TemplateGenerationRequest>({
    industry: '',
    businessType: '',
    goals: [],
    targetAudience: '',
    keyServices: [],
    complianceRequirements: [],
    budget: 'medium',
    complexity: 'moderate',
    customRequirements: ''
  });

  // Sample templates with GHL best practices
  useEffect(() => {
    const sampleTemplates: AITemplate[] = [
      {
        id: 'template_1',
        name: 'F45 Fitness Trial Booking Pro',
        description: 'Advanced F45 fitness trial booking agent with membership qualification, class scheduling, and payment processing. Includes 6 industry-specific templates and GHL integration.',
        industry: 'Fitness & Wellness',
        category: 'Appointment Booking',
        complexity: 'advanced',
        ghlBestPractices: {
          customFields: [
            'fitness_goals',
            'current_fitness_level',
            'preferred_class_times',
            'injury_history',
            'membership_interest',
            'referral_source',
            'trial_date_preference',
            'emergency_contact'
          ],
          workflows: [
            'Trial Booking Follow-up',
            'Membership Conversion',
            'No-Show Recovery',
            'Referral Tracking'
          ],
          pipelines: [
            'Fitness Leads',
            'Trial Bookings',
            'Membership Prospects',
            'Active Members'
          ],
          tags: [
            'fitness_lead',
            'trial_booked',
            'high_intent',
            'membership_interested',
            'no_show',
            'converted'
          ],
          mergeTags: [
            '{{contact.first_name}}',
            '{{contact.last_name}}',
            '{{contact.email}}',
            '{{contact.phone}}',
            '{{custom.fitness_goals}}',
            '{{custom.trial_date}}',
            '{{custom.preferred_class_time}}'
          ],
          webhooks: [
            'trial_booking_webhook',
            'membership_conversion_webhook',
            'class_reminder_webhook'
          ],
          compliance: [
            'TCPA_compliant',
            'GDPR_compliant',
            'health_data_protection',
            'emergency_protocols'
          ]
        },
        voiceConfig: {
          provider: 'ElevenLabs',
          voiceId: 'sarah_fitness',
          language: 'en-US',
          accent: 'American',
          speed: 0.9,
          pitch: 1.1,
          emotion: 'enthusiastic'
        },
        llmConfig: {
          provider: 'OpenAI',
          model: 'gpt-4',
          temperature: 0.7,
          maxTokens: 150,
          systemPrompt: 'You are an enthusiastic F45 fitness trainer and sales professional. Your goal is to book trial classes and convert leads to memberships. Be energetic, helpful, and focus on the health benefits and community aspects of F45.',
          userPrompt: 'Help the customer book a trial class and understand the benefits of F45 membership.'
        },
        conversationFlow: {
          intents: [
            {
              name: 'trial_booking',
              description: 'Customer wants to book a trial class',
              examples: [
                'I want to try a class',
                'Can I book a trial?',
                'What classes do you have?',
                'I\'m interested in F45'
              ],
              responses: [
                'That\'s fantastic! I\'d love to help you book a trial class. What\'s your fitness level and what are your goals?',
                'Great choice! F45 is perfect for all fitness levels. When would you like to come in for your trial?'
              ],
              ghlActions: [
                'Update custom field: trial_interest = true',
                'Add tag: trial_interested',
                'Move to pipeline: Trial Bookings'
              ]
            },
            {
              name: 'membership_inquiry',
              description: 'Customer asks about membership options',
              examples: [
                'How much does membership cost?',
                'What membership options do you have?',
                'Tell me about your packages'
              ],
              responses: [
                'We have several membership options to fit your lifestyle. Let me tell you about our most popular packages...',
                'Great question! Our memberships are designed to give you maximum value and flexibility.'
              ],
              ghlActions: [
                'Update custom field: membership_interest = true',
                'Add tag: membership_interested',
                'Send membership info via SMS'
              ]
            }
          ],
          fallbacks: [
            {
              scenario: 'Customer is confused or needs clarification',
              response: 'I understand this might be a lot of information. Let me break it down simply - what specific aspect of F45 would you like to know more about?',
              action: 'Continue conversation with simplified approach'
            },
            {
              scenario: 'Customer is not ready to book',
              response: 'No problem at all! I can send you some information about F45 and our classes. What\'s the best way to reach you?',
              action: 'Add to nurture sequence'
            }
          ],
          transfers: [
            {
              condition: 'Customer has specific injury concerns',
              department: 'Fitness Director',
              priority: 'high'
            },
            {
              condition: 'Customer wants to speak to manager',
              department: 'General Manager',
              priority: 'medium'
            }
          ]
        },
        performanceMetrics: {
          expectedConversionRate: 0.23,
          expectedAvgDuration: 195,
          expectedCostPerCall: 0.85,
          expectedSuccessRate: 0.87
        },
        deployment: {
          readinessScore: 95,
          requirements: [
            'GHL location with calendar integration',
            'ElevenLabs API key',
            'OpenAI API key',
            'Custom fields configured',
            'Workflows set up'
          ],
          dependencies: [
            'F45 class schedule API',
            'Payment processing system',
            'SMS notifications'
          ],
          estimatedSetupTime: '2-3 hours'
        },
        createdAt: '2024-01-15T10:00:00Z',
        updatedAt: '2024-01-15T14:30:00Z',
        author: 'AI Template Generator',
        downloads: 1247,
        rating: 4.8,
        tags: ['fitness', 'trial-booking', 'membership', 'scheduling', 'payment', 'ghl-optimized']
      }
    ];

    setTemplates(sampleTemplates);
  }, []);

  const handleGenerateTemplate = async () => {
    if (!generationRequest.industry || !generationRequest.businessType) {
      toast.error('Please fill in the required fields to generate a template.');
      return;
    }

    setIsGenerating(true);
    setGenerationProgress(0);

    // Simulate AI generation process
    const progressInterval = setInterval(() => {
      setGenerationProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          setIsGenerating(false);
          toast.success('AI template generated successfully!');
          return 100;
        }
        return prev + 10;
      });
    }, 500);

    // Simulate generation completion
    setTimeout(() => {
      clearInterval(progressInterval);
      setIsGenerating(false);
      setGenerationProgress(100);
      toast.success('AI template generated successfully!');
    }, 5000);
  };

  const renderGeneratorTab = () => (
    <div className="space-y-6">
      {/* AI Generation Form */}
      <div className="card p-6">
        <h2 className="text-xl font-semibold text-foreground mb-6 flex items-center">
          <Sparkles className="w-6 h-6 mr-2 text-primary" />
          AI Template Generator
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-2">
              Industry *
            </label>
            <select
              className="w-full input"
              value={generationRequest.industry}
              onChange={(e) => setGenerationRequest(prev => ({ ...prev, industry: e.target.value }))}
            >
              <option value="">Select Industry</option>
              <option value="fitness">Fitness & Wellness</option>
              <option value="legal">Legal Services</option>
              <option value="healthcare">Healthcare</option>
              <option value="real_estate">Real Estate</option>
              <option value="automotive">Automotive</option>
              <option value="education">Education</option>
              <option value="finance">Finance</option>
              <option value="retail">Retail</option>
              <option value="hospitality">Hospitality</option>
              <option value="technology">Technology</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-2">
              Business Type *
            </label>
            <input
              type="text"
              className="w-full input"
              placeholder="e.g., Fitness Studio, Law Firm, Medical Practice"
              value={generationRequest.businessType}
              onChange={(e) => setGenerationRequest(prev => ({ ...prev, businessType: e.target.value }))}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-2">
              Target Audience
            </label>
            <input
              type="text"
              className="w-full input"
              placeholder="e.g., Young professionals, Seniors, Families"
              value={generationRequest.targetAudience}
              onChange={(e) => setGenerationRequest(prev => ({ ...prev, targetAudience: e.target.value }))}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-2">
              Budget Level
            </label>
            <select
              className="w-full input"
              value={generationRequest.budget}
              onChange={(e) => setGenerationRequest(prev => ({ ...prev, budget: e.target.value as any }))}
            >
              <option value="low">Low ($0-500/month)</option>
              <option value="medium">Medium ($500-2000/month)</option>
              <option value="high">High ($2000-5000/month)</option>
              <option value="enterprise">Enterprise ($5000+/month)</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-2">
              Complexity Level
            </label>
            <select
              className="w-full input"
              value={generationRequest.complexity}
              onChange={(e) => setGenerationRequest(prev => ({ ...prev, complexity: e.target.value as any }))}
            >
              <option value="simple">Simple (Basic booking)</option>
              <option value="moderate">Moderate (Multi-step process)</option>
              <option value="complex">Complex (Advanced features)</option>
              <option value="enterprise">Enterprise (Full automation)</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-2">
              Key Services
            </label>
            <input
              type="text"
              className="w-full input"
              placeholder="e.g., Trial classes, Consultations, Emergency services"
              value={generationRequest.keyServices.join(', ')}
              onChange={(e) => setGenerationRequest(prev => ({ 
                ...prev, 
                keyServices: e.target.value.split(',').map(s => s.trim()).filter(s => s) 
              }))}
            />
          </div>
        </div>

        <div className="mt-6">
          <label className="block text-sm font-medium text-muted-foreground mb-2">
            Custom Requirements
          </label>
          <textarea
            className="w-full input"
            rows={4}
            placeholder="Describe any specific requirements, compliance needs, or special features..."
            value={generationRequest.customRequirements}
            onChange={(e) => setGenerationRequest(prev => ({ ...prev, customRequirements: e.target.value }))}
          />
        </div>

        <div className="mt-6">
          <label className="block text-sm font-medium text-muted-foreground mb-2">
            Goals
          </label>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {[
              'Increase Bookings',
              'Reduce No-Shows',
              'Improve Conversion',
              'Enhance Customer Experience',
              'Automate Follow-ups',
              'Generate Leads',
              'Qualify Prospects',
              'Reduce Costs'
            ].map((goal) => (
              <label key={goal} className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={generationRequest.goals.includes(goal)}
                  onChange={(e) => {
                    if (e.target.checked) {
                      setGenerationRequest(prev => ({ ...prev, goals: [...prev.goals, goal] }));
                    } else {
                      setGenerationRequest(prev => ({ ...prev, goals: prev.goals.filter(g => g !== goal) }));
                    }
                  }}
                  className="rounded border-border"
                />
                <span className="text-sm text-foreground">{goal}</span>
              </label>
            ))}
          </div>
        </div>

        <div className="mt-6">
          <label className="block text-sm font-medium text-muted-foreground mb-2">
            Compliance Requirements
          </label>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {[
              'TCPA Compliance',
              'GDPR Compliance',
              'HIPAA Compliance',
              'PCI Compliance',
              'SOX Compliance',
              'CCPA Compliance',
              'ADA Compliance',
              'Industry Specific'
            ].map((compliance) => (
              <label key={compliance} className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={generationRequest.complianceRequirements.includes(compliance)}
                  onChange={(e) => {
                    if (e.target.checked) {
                      setGenerationRequest(prev => ({ ...prev, complianceRequirements: [...prev.complianceRequirements, compliance] }));
                    } else {
                      setGenerationRequest(prev => ({ ...prev, complianceRequirements: prev.complianceRequirements.filter(c => c !== compliance) }));
                    }
                  }}
                  className="rounded border-border"
                />
                <span className="text-sm text-foreground">{compliance}</span>
              </label>
            ))}
          </div>
        </div>

        <div className="mt-8 flex justify-end">
          <button
            onClick={handleGenerateTemplate}
            disabled={isGenerating}
            className="btn btn-primary btn-lg"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                Generating... {generationProgress}%
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 mr-2" />
                Generate AI Template
              </>
            )}
          </button>
        </div>

        {isGenerating && (
          <div className="mt-4">
            <div className="w-full bg-secondary rounded-full h-2">
              <div
                className="bg-primary h-2 rounded-full transition-all duration-300"
                style={{ width: `${generationProgress}%` }}
              ></div>
            </div>
            <p className="text-sm text-muted-foreground mt-2">
              AI is analyzing your requirements and generating an optimized template...
            </p>
          </div>
        )}
      </div>
    </div>
  );

  const renderTemplatesTab = () => (
    <div className="space-y-6">
      {/* Generated Templates */}
      <div className="space-y-4">
        {templates.map((template) => (
          <div key={template.id} className="card p-6 hover:shadow-lg transition-all duration-200">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="text-lg font-semibold text-foreground">{template.name}</h3>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                    template.complexity === 'enterprise' ? 'text-purple-400 bg-purple-100' :
                    template.complexity === 'advanced' ? 'text-blue-400 bg-blue-100' :
                    template.complexity === 'intermediate' ? 'text-green-400 bg-green-100' :
                    'text-gray-400 bg-gray-100'
                  }`}>
                    {template.complexity}
                  </div>
                  <div className="px-2 py-1 rounded-full text-xs font-medium text-green-400 bg-green-100">
                    GHL Optimized
                  </div>
                </div>
                <p className="text-muted-foreground mb-3">{template.description}</p>
                <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Target className="w-4 h-4" />
                    <span>{template.industry}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{template.deployment.estimatedSetupTime}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <CheckCircle className="w-4 h-4" />
                    <span>{template.deployment.readinessScore}% Ready</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4" />
                    <span>{template.rating}/5</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <button className="btn btn-outline btn-sm">
                  <Eye className="w-4 h-4 mr-2" />
                  Preview
                </button>
                <button className="btn btn-primary btn-sm">
                  <Download className="w-4 h-4 mr-2" />
                  Use Template
                </button>
              </div>
            </div>
            
            {/* GHL Best Practices */}
            <div className="mt-4">
              <h4 className="font-medium text-foreground mb-2">GHL Best Practices Included:</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Custom Fields ({template.ghlBestPractices.customFields.length})</p>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {template.ghlBestPractices.customFields.slice(0, 3).map((field) => (
                      <span key={field} className="px-2 py-1 bg-primary/10 text-primary text-xs rounded">
                        {field}
                      </span>
                    ))}
                    {template.ghlBestPractices.customFields.length > 3 && (
                      <span className="px-2 py-1 bg-secondary text-muted-foreground text-xs rounded">
                        +{template.ghlBestPractices.customFields.length - 3} more
                      </span>
                    )}
                  </div>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Workflows ({template.ghlBestPractices.workflows.length})</p>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {template.ghlBestPractices.workflows.slice(0, 2).map((workflow) => (
                      <span key={workflow} className="px-2 py-1 bg-blue-100 text-blue-600 text-xs rounded">
                        {workflow}
                      </span>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Compliance ({template.ghlBestPractices.compliance.length})</p>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {template.ghlBestPractices.compliance.slice(0, 2).map((compliance) => (
                      <span key={compliance} className="px-2 py-1 bg-green-100 text-green-600 text-xs rounded">
                        {compliance}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Performance Metrics */}
            <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Expected Conversion</p>
                <p className="text-lg font-bold text-green-400">
                  {Math.round(template.performanceMetrics.expectedConversionRate * 100)}%
                </p>
              </div>
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Avg Duration</p>
                <p className="text-lg font-bold text-blue-400">
                  {template.performanceMetrics.expectedAvgDuration}s
                </p>
              </div>
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Cost per Call</p>
                <p className="text-lg font-bold text-purple-400">
                  ${template.performanceMetrics.expectedCostPerCall}
                </p>
              </div>
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Success Rate</p>
                <p className="text-lg font-bold text-orange-400">
                  {Math.round(template.performanceMetrics.expectedSuccessRate * 100)}%
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="p-6 bg-background min-h-screen text-foreground">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">AI Template Generator</h1>
            <p className="text-muted-foreground">
              Generate intelligent voice AI templates optimized for GoHighLevel with industry best practices
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <button className="btn btn-outline">
              <Download className="w-4 h-4 mr-2" />
              Export Templates
            </button>
            <button className="btn btn-outline">
              <Settings className="w-4 h-4 mr-2" />
              Generator Settings
            </button>
            <button className="btn btn-primary">
              <Plus className="w-4 h-4 mr-2" />
              New Generation
            </button>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="mb-6">
        <div className="flex space-x-1 bg-secondary p-1 rounded-lg w-fit">
          {[
            { id: 'generator', label: 'AI Generator', icon: Sparkles },
            { id: 'templates', label: 'Generated Templates', icon: Bot },
            { id: 'best-practices', label: 'GHL Best Practices', icon: CheckCircle },
            { id: 'analytics', label: 'Generation Analytics', icon: BarChart3 }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-primary text-primary-foreground shadow-lg'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      {activeTab === 'generator' && renderGeneratorTab()}
      {activeTab === 'templates' && renderTemplatesTab()}
      {activeTab === 'best-practices' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">GHL Best Practices Library</h2>
          <p className="text-muted-foreground">Comprehensive library of GoHighLevel best practices and optimization techniques.</p>
        </div>
      )}
      {activeTab === 'analytics' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Generation Analytics</h2>
          <p className="text-muted-foreground">Analytics and insights on template generation performance and usage.</p>
        </div>
      )}
    </div>
  );
};

export default AITemplateGenerator;
