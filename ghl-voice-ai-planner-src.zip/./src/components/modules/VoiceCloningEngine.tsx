import React, { useState, useEffect } from 'react';
import { Mic, Play, Pause, Download, Upload, Settings, RefreshCw, Volume2, VolumeX, Zap, CheckCircle, AlertTriangle, Brain, Target, BarChart3 } from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';
import { v4 as uuidv4 } from 'uuid';

interface VoiceProfile {
  id: string;
  name: string;
  description: string;
  gender: 'male' | 'female' | 'neutral';
  age: 'young' | 'adult' | 'mature' | 'senior';
  accent: 'american' | 'british' | 'australian' | 'canadian' | 'custom';
  language: string;
  tone: 'professional' | 'friendly' | 'authoritative' | 'empathetic' | 'energetic';
  pitch: number; // 0-100
  speed: number; // 0-100
  clarity: number; // 0-100
  emotion: 'neutral' | 'happy' | 'sad' | 'excited' | 'calm' | 'urgent';
  status: 'draft' | 'training' | 'ready' | 'failed';
  trainingProgress: number;
  qualityScore: number;
  createdAt: string;
  lastUsed: string | null;
  usageCount: number;
  audioSamples: AudioSample[];
}

interface AudioSample {
  id: string;
  voiceProfileId: string;
  text: string;
  duration: number;
  quality: number;
  url: string;
  createdAt: string;
}

interface VoiceTrainingSession {
  id: string;
  voiceProfileId: string;
  status: 'active' | 'completed' | 'failed' | 'paused';
  startTime: string;
  endTime: string | null;
  duration: number | null;
  samplesProcessed: number;
  totalSamples: number;
  progress: number;
  qualityMetrics: {
    clarity: number;
    naturalness: number;
    consistency: number;
    emotionAccuracy: number;
  };
  errors: string[];
}

interface VoiceCustomization {
  id: string;
  voiceProfileId: string;
  type: 'pitch' | 'speed' | 'tone' | 'emotion' | 'accent';
  value: any;
  intensity: number; // 0-100
  isActive: boolean;
  createdAt: string;
}

const VoiceCloningEngine: React.FC = () => {
  const { voiceAgents } = useStore();
  const [voiceProfiles, setVoiceProfiles] = useState<VoiceProfile[]>([]);
  const [trainingSessions, setTrainingSessions] = useState<VoiceTrainingSession[]>([]);
  const [customizations, setCustomizations] = useState<VoiceCustomization[]>([]);
  const [selectedProfileId, setSelectedProfileId] = useState<string>('');
  const [isTraining, setIsTraining] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isPlaying, setIsPlaying] = useState<string | null>(null);

  // State for new voice profile
  const [newProfileName, setNewProfileName] = useState('');
  const [newProfileDescription, setNewProfileDescription] = useState('');
  const [newProfileGender, setNewProfileGender] = useState<VoiceProfile['gender']>('neutral');
  const [newProfileAge, setNewProfileAge] = useState<VoiceProfile['age']>('adult');
  const [newProfileAccent, setNewProfileAccent] = useState<VoiceProfile['accent']>('american');
  const [newProfileLanguage, setNewProfileLanguage] = useState('en-US');
  const [newProfileTone, setNewProfileTone] = useState<VoiceProfile['tone']>('professional');

  useEffect(() => {
    // Mock data for voice profiles
    const mockProfiles: VoiceProfile[] = [
      {
        id: uuidv4(),
        name: 'Professional Sarah',
        description: 'Friendly and professional female voice for customer service',
        gender: 'female',
        age: 'adult',
        accent: 'american',
        language: 'en-US',
        tone: 'professional',
        pitch: 65,
        speed: 75,
        clarity: 90,
        emotion: 'neutral',
        status: 'ready',
        trainingProgress: 100,
        qualityScore: 94,
        createdAt: '2023-10-20T10:00:00Z',
        lastUsed: '2023-10-26T18:30:00Z',
        usageCount: 156,
        audioSamples: []
      },
      {
        id: uuidv4(),
        name: 'Energetic Mike',
        description: 'High-energy male voice for sales and marketing',
        gender: 'male',
        age: 'adult',
        accent: 'american',
        language: 'en-US',
        tone: 'energetic',
        pitch: 45,
        speed: 85,
        clarity: 88,
        emotion: 'excited',
        status: 'training',
        trainingProgress: 67,
        qualityScore: 0,
        createdAt: '2023-10-25T14:00:00Z',
        lastUsed: null,
        usageCount: 0,
        audioSamples: []
      },
      {
        id: uuidv4(),
        name: 'Calm Emma',
        description: 'Soothing female voice for healthcare and support',
        gender: 'female',
        age: 'mature',
        accent: 'british',
        language: 'en-GB',
        tone: 'empathetic',
        pitch: 70,
        speed: 60,
        clarity: 92,
        emotion: 'calm',
        status: 'ready',
        trainingProgress: 100,
        qualityScore: 96,
        createdAt: '2023-10-22T09:00:00Z',
        lastUsed: '2023-10-26T16:45:00Z',
        usageCount: 89,
        audioSamples: []
      }
    ];

    setVoiceProfiles(mockProfiles);
    setSelectedProfileId(mockProfiles[0]?.id || '');

    // Mock training sessions
    const mockSessions: VoiceTrainingSession[] = [
      {
        id: uuidv4(),
        voiceProfileId: mockProfiles[1].id,
        status: 'active',
        startTime: '2023-10-26T17:00:00Z',
        endTime: null,
        duration: null,
        samplesProcessed: 45,
        totalSamples: 100,
        progress: 45,
        qualityMetrics: {
          clarity: 78,
          naturalness: 82,
          consistency: 75,
          emotionAccuracy: 80
        },
        errors: []
      }
    ];

    setTrainingSessions(mockSessions);
  }, []);

  const handleCreateVoiceProfile = () => {
    if (!newProfileName) {
      toast.error('Voice profile name is required.');
      return;
    }

    const newProfile: VoiceProfile = {
      id: uuidv4(),
      name: newProfileName,
      description: newProfileDescription,
      gender: newProfileGender,
      age: newProfileAge,
      accent: newProfileAccent,
      language: newProfileLanguage,
      tone: newProfileTone,
      pitch: 50,
      speed: 70,
      clarity: 85,
      emotion: 'neutral',
      status: 'draft',
      trainingProgress: 0,
      qualityScore: 0,
      createdAt: new Date().toISOString(),
      lastUsed: null,
      usageCount: 0,
      audioSamples: []
    };

    setVoiceProfiles(prev => [...prev, newProfile]);
    setSelectedProfileId(newProfile.id);
    resetForm();
    toast.success('Voice profile created successfully!');
  };

  const handleStartTraining = async (profileId: string) => {
    setIsTraining(true);
    toast.loading('Starting voice training...', { id: 'voice-training' });

    // Simulate training process
    await new Promise(resolve => setTimeout(resolve, 3000));

    const newSession: VoiceTrainingSession = {
      id: uuidv4(),
      voiceProfileId: profileId,
      status: 'active',
      startTime: new Date().toISOString(),
      endTime: null,
      duration: null,
      samplesProcessed: 0,
      totalSamples: 100,
      progress: 0,
      qualityMetrics: {
        clarity: 0,
        naturalness: 0,
        consistency: 0,
        emotionAccuracy: 0
      },
      errors: []
    };

    setTrainingSessions(prev => [newSession, ...prev]);
    setVoiceProfiles(prev => 
      prev.map(p => p.id === profileId ? { ...p, status: 'training' as const } : p)
    );

    setIsTraining(false);
    toast.success('Voice training started!', { id: 'voice-training');
  };

  const handleRecordSample = () => {
    setIsRecording(true);
    toast.loading('Recording audio sample...', { id: 'recording');

    // Simulate recording
    setTimeout(() => {
      setIsRecording(false);
      toast.success('Audio sample recorded successfully!', { id: 'recording');
    }, 2000);
  };

  const handlePlaySample = (sampleId: string) => {
    setIsPlaying(sampleId);
    toast.info('Playing audio sample...');

    // Simulate playback
    setTimeout(() => {
      setIsPlaying(null);
    }, 3000);
  };

  const resetForm = () => {
    setNewProfileName('');
    setNewProfileDescription('');
    setNewProfileGender('neutral');
    setNewProfileAge('adult');
    setNewProfileAccent('american');
    setNewProfileLanguage('en-US');
    setNewProfileTone('professional');
  };

  const getStatusColor = (status: VoiceProfile['status']) => {
    switch (status) {
      case 'ready': return 'text-green-500';
      case 'training': return 'text-yellow-500';
      case 'failed': return 'text-red-500';
      case 'draft': return 'text-muted-foreground';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusIcon = (status: VoiceProfile['status']) => {
    switch (status) {
      case 'ready': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'training': return <RefreshCw className="w-4 h-4 text-yellow-500 animate-spin" />;
      case 'failed': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'draft': return <Settings className="w-4 h-4 text-muted-foreground" />;
      default: return <Settings className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const selectedProfile = voiceProfiles.find(p => p.id === selectedProfileId);
  const activeTrainingSession = trainingSessions.find(s => s.status === 'active');

  return (
    <div className="p-6 bg-background min-h-screen text-foreground">
      <h1 className="text-3xl font-bold gradient-text mb-6">Advanced Voice Cloning & Customization Engine</h1>
      <p className="text-muted-foreground mb-8">
        Create, train, and customize unique voice profiles with AI-powered voice cloning technology. Build personalized voice experiences for your Voice AI agents.
      </p>

      {/* Voice Profile Creation */}
      <div className="card p-6 mb-8">
        <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
          <Mic className="w-6 h-6 mr-2 text-blue-400" /> Create New Voice Profile
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
          <div>
            <label htmlFor="profile-name" className="block text-sm font-medium text-muted-foreground mb-1">
              Profile Name
            </label>
            <input
              type="text"
              id="profile-name"
              className="w-full input"
              value={newProfileName}
              onChange={(e) => setNewProfileName(e.target.value)}
              placeholder="e.g., Professional Sarah"
            />
          </div>
          <div>
            <label htmlFor="profile-description" className="block text-sm font-medium text-muted-foreground mb-1">
              Description
            </label>
            <input
              type="text"
              id="profile-description"
              className="w-full input"
              value={newProfileDescription}
              onChange={(e) => setNewProfileDescription(e.target.value)}
              placeholder="Brief description of the voice"
            />
          </div>
          <div>
            <label htmlFor="profile-gender" className="block text-sm font-medium text-muted-foreground mb-1">
              Gender
            </label>
            <select
              id="profile-gender"
              className="w-full input"
              value={newProfileGender}
              onChange={(e) => setNewProfileGender(e.target.value as VoiceProfile['gender'])}
            >
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="neutral">Neutral</option>
            </select>
          </div>
          <div>
            <label htmlFor="profile-age" className="block text-sm font-medium text-muted-foreground mb-1">
              Age Range
            </label>
            <select
              id="profile-age"
              className="w-full input"
              value={newProfileAge}
              onChange={(e) => setNewProfileAge(e.target.value as VoiceProfile['age'])}
            >
              <option value="young">Young (18-25)</option>
              <option value="adult">Adult (26-45)</option>
              <option value="mature">Mature (46-65)</option>
              <option value="senior">Senior (65+)</option>
            </select>
          </div>
          <div>
            <label htmlFor="profile-accent" className="block text-sm font-medium text-muted-foreground mb-1">
              Accent
            </label>
            <select
              id="profile-accent"
              className="w-full input"
              value={newProfileAccent}
              onChange={(e) => setNewProfileAccent(e.target.value as VoiceProfile['accent'])}
            >
              <option value="american">American</option>
              <option value="british">British</option>
              <option value="australian">Australian</option>
              <option value="canadian">Canadian</option>
              <option value="custom">Custom</option>
            </select>
          </div>
          <div>
            <label htmlFor="profile-tone" className="block text-sm font-medium text-muted-foreground mb-1">
              Tone
            </label>
            <select
              id="profile-tone"
              className="w-full input"
              value={newProfileTone}
              onChange={(e) => setNewProfileTone(e.target.value as VoiceProfile['tone'])}
            >
              <option value="professional">Professional</option>
              <option value="friendly">Friendly</option>
              <option value="authoritative">Authoritative</option>
              <option value="empathetic">Empathetic</option>
              <option value="energetic">Energetic</option>
            </select>
          </div>
        </div>
        <div className="flex justify-end gap-3">
          <button onClick={resetForm} className="btn btn-secondary">
            <RefreshCw className="w-5 h-5 mr-2" /> Clear
          </button>
          <button onClick={handleCreateVoiceProfile} className="btn btn-primary">
            <Mic className="w-5 h-5 mr-2" /> Create Profile
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Voice Profiles */}
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
            <Volume2 className="w-6 h-6 mr-2 text-green-400" /> Voice Profiles
          </h2>
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {voiceProfiles.map((profile) => (
              <div key={profile.id} className="bg-secondary p-4 rounded-lg border border-border">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-medium text-foreground flex items-center">
                      {getStatusIcon(profile.status)} {profile.name}
                    </h3>
                    <p className="text-sm text-muted-foreground">{profile.description}</p>
                  </div>
                  <span className={`text-sm font-medium ${getStatusColor(profile.status)}`}>
                    {profile.status.charAt(0).toUpperCase() + profile.status.slice(1)}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground mb-3">
                  <div>Gender: {profile.gender}</div>
                  <div>Age: {profile.age}</div>
                  <div>Accent: {profile.accent}</div>
                  <div>Tone: {profile.tone}</div>
                  <div>Quality: {profile.qualityScore}/100</div>
                  <div>Usage: {profile.usageCount} times</div>
                </div>
                {profile.status === 'training' && (
                  <div className="mb-3">
                    <div className="flex justify-between text-xs text-muted-foreground mb-1">
                      <span>Training Progress</span>
                      <span>{profile.trainingProgress}%</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <div
                        className="bg-yellow-500 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${profile.trainingProgress}%` }}
                      ></div>
                    </div>
                  </div>
                )}
                <div className="flex justify-end gap-2">
                  {profile.status === 'draft' && (
                    <button
                      onClick={() => handleStartTraining(profile.id)}
                      className="btn btn-sm btn-primary"
                      disabled={isTraining}
                    >
                      <Zap className="w-4 h-4 mr-1" /> Start Training
                    </button>
                  )}
                  {profile.status === 'ready' && (
                    <button
                      onClick={() => setSelectedProfileId(profile.id)}
                      className="btn btn-sm btn-outline"
                    >
                      <Settings className="w-4 h-4 mr-1" /> Customize
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Voice Customization */}
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
            <Settings className="w-6 h-6 mr-2 text-purple-400" /> Voice Customization
          </h2>
          {selectedProfile ? (
            <div className="space-y-4">
              <div className="bg-secondary p-4 rounded-lg">
                <h3 className="font-medium text-foreground mb-2">{selectedProfile.name}</h3>
                <div className="space-y-3">
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-1">
                      Pitch ({selectedProfile.pitch})
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={selectedProfile.pitch}
                      className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-primary"
                      onChange={(e) => {
                        setVoiceProfiles(prev => 
                          prev.map(p => p.id === selectedProfile.id ? { ...p, pitch: Number(e.target.value) } : p)
                        );
                      }}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-1">
                      Speed ({selectedProfile.speed})
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={selectedProfile.speed}
                      className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-primary"
                      onChange={(e) => {
                        setVoiceProfiles(prev => 
                          prev.map(p => p.id === selectedProfile.id ? { ...p, speed: Number(e.target.value) } : p)
                        );
                      }}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-1">
                      Clarity ({selectedProfile.clarity})
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={selectedProfile.clarity}
                      className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-primary"
                      onChange={(e) => {
                        setVoiceProfiles(prev => 
                          prev.map(p => p.id === selectedProfile.id ? { ...p, clarity: Number(e.target.value) } : p)
                        );
                      }}
                    />
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleRecordSample}
                  className="btn btn-primary flex-1"
                  disabled={isRecording}
                >
                  {isRecording ? (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Recording...
                    </>
                  ) : (
                    <>
                      <Mic className="w-4 h-4 mr-2" /> Record Sample
                    </>
                  )}
                </button>
                <button className="btn btn-outline">
                  <Download className="w-4 h-4 mr-2" /> Export
                </button>
              </div>
            </div>
          ) : (
            <p className="text-muted-foreground text-center py-8">Select a voice profile to customize</p>
          )}
        </div>
      </div>

      {/* Training Sessions */}
      {activeTrainingSession && (
        <div className="card p-6 mt-6">
          <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
            <Brain className="w-6 h-6 mr-2 text-orange-400" /> Active Training Session
          </h2>
          <div className="bg-secondary p-4 rounded-lg">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-medium text-foreground">
                Training: {voiceProfiles.find(p => p.id === activeTrainingSession.voiceProfileId)?.name}
              </h3>
              <span className="text-sm text-muted-foreground">
                {activeTrainingSession.samplesProcessed}/{activeTrainingSession.totalSamples} samples
              </span>
            </div>
            <div className="mb-4">
              <div className="flex justify-between text-sm text-muted-foreground mb-1">
                <span>Progress</span>
                <span>{activeTrainingSession.progress}%</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-3">
                <div
                  className="bg-orange-500 h-3 rounded-full transition-all duration-300"
                  style={{ width: `${activeTrainingSession.progress}%` }}
                ></div>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <p className="text-muted-foreground">Clarity</p>
                <p className="font-medium text-foreground">{activeTrainingSession.qualityMetrics.clarity}%</p>
              </div>
              <div>
                <p className="text-muted-foreground">Naturalness</p>
                <p className="font-medium text-foreground">{activeTrainingSession.qualityMetrics.naturalness}%</p>
              </div>
              <div>
                <p className="text-muted-foreground">Consistency</p>
                <p className="font-medium text-foreground">{activeTrainingSession.qualityMetrics.consistency}%</p>
              </div>
              <div>
                <p className="text-muted-foreground">Emotion Accuracy</p>
                <p className="font-medium text-foreground">{activeTrainingSession.qualityMetrics.emotionAccuracy}%</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VoiceCloningEngine;
