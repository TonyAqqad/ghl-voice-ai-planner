import React, { useState, useEffect } from 'react';
import { Workflow, Zap, Play, Pause, StopCircle, Settings, Plus, Edit, Trash2, Clock, CheckCircle, AlertTriangle, Info, RefreshCw, Target, BarChart3 } from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';
import { v4 as uuidv4 } from 'uuid';

interface WorkflowStep {
  id: string;
  type: 'trigger' | 'condition' | 'action' | 'delay' | 'webhook' | 'ai_decision';
  name: string;
  config: any;
  position: { x: number; y: number };
  connections: string[];
}

interface WorkflowOrchestration {
  id: string;
  name: string;
  description: string;
  status: 'draft' | 'active' | 'paused' | 'error';
  steps: WorkflowStep[];
  triggers: string[];
  lastExecuted: string | null;
  executionCount: number;
  successRate: number;
  avgExecutionTime: number;
  createdAt: string;
  lastModified: string;
}

interface ExecutionLog {
  id: string;
  workflowId: string;
  status: 'success' | 'error' | 'running';
  startTime: string;
  endTime: string | null;
  duration: number | null;
  errorMessage: string | null;
  stepsExecuted: string[];
  data: any;
}

const WorkflowOrchestrationEngine: React.FC = () => {
  const { darkMode, voiceAgents } = useStore();
  const [workflows, setWorkflows] = useState<WorkflowOrchestration[]>([]);
  const [executionLogs, setExecutionLogs] = useState<ExecutionLog[]>([]);
  const [selectedWorkflowId, setSelectedWorkflowId] = useState<string>('');
  const [isExecuting, setIsExecuting] = useState(false);

  // State for new/editing workflow
  const [newWorkflowName, setNewWorkflowName] = useState('');
  const [newWorkflowDescription, setNewWorkflowDescription] = useState('');
  const [editingWorkflowId, setEditingWorkflowId] = useState<string | null>(null);

  // State for workflow designer
  const [selectedStepId, setSelectedStepId] = useState<string | null>(null);
  const [isDesignerOpen, setIsDesignerOpen] = useState(false);

  useEffect(() => {
    // Mock data for workflows
    const mockWorkflows: WorkflowOrchestration[] = [
      {
        id: uuidv4(),
        name: 'Solar Lead Qualification & Follow-up',
        description: 'Automated workflow for qualifying solar leads and scheduling follow-up calls.',
        status: 'active',
        steps: [
          {
            id: uuidv4(),
            type: 'trigger',
            name: 'New Lead Created',
            config: { source: 'ghl_form', conditions: ['solar_interest'] },
            position: { x: 100, y: 100 },
            connections: ['step2'],
          },
          {
            id: uuidv4(),
            type: 'ai_decision',
            name: 'AI Lead Scoring',
            config: { model: 'gpt-4', criteria: ['budget', 'timeline', 'location'] },
            position: { x: 300, y: 100 },
            connections: ['step3'],
          },
          {
            id: uuidv4(),
            type: 'condition',
            name: 'High Value Lead?',
            config: { condition: 'score > 80', truePath: 'step4', falsePath: 'step5' },
            position: { x: 500, y: 100 },
            connections: [],
          },
          {
            id: uuidv4(),
            type: 'action',
            name: 'Schedule Immediate Call',
            config: { action: 'schedule_call', priority: 'high', agent: 'solar_specialist' },
            position: { x: 700, y: 50 },
            connections: ['step6'],
          },
          {
            id: uuidv4(),
            type: 'action',
            name: 'Add to Nurture Campaign',
            config: { action: 'add_to_campaign', campaign: 'solar_nurture', delay: '24h' },
            position: { x: 700, y: 150 },
            connections: ['step6'],
          },
          {
            id: uuidv4(),
            type: 'webhook',
            name: 'Update GHL Pipeline',
            config: { url: 'https://hooks.gohighlevel.com/update-pipeline', method: 'POST' },
            position: { x: 900, y: 100 },
            connections: [],
          },
        ],
        triggers: ['new_lead', 'form_submission'],
        lastExecuted: '2023-10-26T18:30:00Z',
        executionCount: 45,
        successRate: 92.5,
        avgExecutionTime: 2.3,
        createdAt: '2023-10-20T10:00:00Z',
        lastModified: '2023-10-25T15:30:00Z',
      },
      {
        id: uuidv4(),
        name: 'F45 Trial Booking Automation',
        description: 'Automated workflow for F45 trial class bookings and reminders.',
        status: 'active',
        steps: [
          {
            id: uuidv4(),
            type: 'trigger',
            name: 'Trial Interest Form',
            config: { source: 'f45_website', conditions: ['trial_interest'] },
            position: { x: 100, y: 100 },
            connections: ['step2'],
          },
          {
            id: uuidv4(),
            type: 'delay',
            name: 'Wait 2 Hours',
            config: { duration: 7200, reason: 'avoid_immediate_follow_up' },
            position: { x: 300, y: 100 },
            connections: ['step3'],
          },
          {
            id: uuidv4(),
            type: 'action',
            name: 'Send Trial Reminder',
            config: { action: 'send_sms', template: 'f45_trial_reminder', channel: 'sms' },
            position: { x: 500, y: 100 },
            connections: ['step4'],
          },
          {
            id: uuidv4(),
            type: 'ai_decision',
            name: 'Check Availability',
            config: { model: 'gpt-4', task: 'check_class_availability', location: 'dynamic' },
            position: { x: 700, y: 100 },
            connections: ['step5'],
          },
          {
            id: uuidv4(),
            type: 'webhook',
            name: 'Book Trial Class',
            config: { url: 'https://api.f45.com/book-trial', method: 'POST' },
            position: { x: 900, y: 100 },
            connections: [],
          },
        ],
        triggers: ['form_submission', 'trial_interest'],
        lastExecuted: '2023-10-26T19:15:00Z',
        executionCount: 23,
        successRate: 87.0,
        avgExecutionTime: 1.8,
        createdAt: '2023-10-22T14:00:00Z',
        lastModified: '2023-10-24T11:20:00Z',
      },
    ];

    setWorkflows(mockWorkflows);
    setSelectedWorkflowId(mockWorkflows[0]?.id || '');

    // Mock execution logs
    const mockLogs: ExecutionLog[] = [
      {
        id: uuidv4(),
        workflowId: mockWorkflows[0].id,
        status: 'success',
        startTime: '2023-10-26T18:30:00Z',
        endTime: '2023-10-26T18:30:02Z',
        duration: 2.3,
        errorMessage: null,
        stepsExecuted: ['step1', 'step2', 'step3', 'step4', 'step6'],
        data: { leadId: 'lead_123', score: 85, action: 'immediate_call' },
      },
      {
        id: uuidv4(),
        workflowId: mockWorkflows[1].id,
        status: 'success',
        startTime: '2023-10-26T19:15:00Z',
        endTime: '2023-10-26T19:15:01Z',
        duration: 1.8,
        errorMessage: null,
        stepsExecuted: ['step1', 'step2', 'step3', 'step4', 'step5'],
        data: { trialId: 'trial_456', classTime: '2023-10-28T09:00:00Z' },
      },
    ];

    setExecutionLogs(mockLogs);
  }, []);

  // --- Workflow Handlers ---
  const handleSaveWorkflow = () => {
    if (!newWorkflowName) {
      toast.error('Workflow name is required.');
      return;
    }

    const newWorkflow: WorkflowOrchestration = {
      id: editingWorkflowId || uuidv4(),
      name: newWorkflowName,
      description: newWorkflowDescription,
      status: 'draft',
      steps: [],
      triggers: [],
      lastExecuted: null,
      executionCount: 0,
      successRate: 0,
      avgExecutionTime: 0,
      createdAt: editingWorkflowId ? workflows.find(w => w.id === editingWorkflowId)?.createdAt || new Date().toISOString() : new Date().toISOString(),
      lastModified: new Date().toISOString(),
    };

    if (editingWorkflowId) {
      setWorkflows(prev => prev.map(w => w.id === editingWorkflowId ? newWorkflow : w));
      toast.success('Workflow updated successfully!');
    } else {
      setWorkflows(prev => [...prev, newWorkflow]);
      toast.success('Workflow created successfully!');
    }
    resetWorkflowForm();
  };

  const handleEditWorkflow = (workflow: WorkflowOrchestration) => {
    setEditingWorkflowId(workflow.id);
    setNewWorkflowName(workflow.name);
    setNewWorkflowDescription(workflow.description);
    toast.info(`Editing workflow: ${workflow.name}`);
  };

  const handleDeleteWorkflow = (id: string) => {
    if (window.confirm('Are you sure you want to delete this workflow?')) {
      setWorkflows(prev => prev.filter(w => w.id !== id));
      setExecutionLogs(prev => prev.filter(log => log.workflowId !== id));
      toast.success('Workflow deleted!');
      if (editingWorkflowId === id) resetWorkflowForm();
    }
  };

  const handleStartWorkflow = async (id: string) => {
    setIsExecuting(true);
    toast.loading('Starting workflow execution...', { id: 'workflow-start' });

    // Simulate execution
    await new Promise(resolve => setTimeout(resolve, 2000));

    const workflow = workflows.find(w => w.id === id);
    if (workflow) {
      setWorkflows(prev => prev.map(w => w.id === id ? { ...w, status: 'active', lastExecuted: new Date().toISOString() } : w));
      
      // Add execution log
      const newLog: ExecutionLog = {
        id: uuidv4(),
        workflowId: id,
        status: 'success',
        startTime: new Date().toISOString(),
        endTime: new Date().toISOString(),
        duration: Math.random() * 3 + 1,
        errorMessage: null,
        stepsExecuted: workflow.steps.map(s => s.id),
        data: { executionId: uuidv4(), status: 'completed' },
      };
      setExecutionLogs(prev => [newLog, ...prev]);
    }

    setIsExecuting(false);
    toast.success('Workflow started successfully!', { id: 'workflow-start' });
  };

  const handlePauseWorkflow = (id: string) => {
    setWorkflows(prev => prev.map(w => w.id === id ? { ...w, status: 'paused' } : w));
    toast.info('Workflow paused.');
  };

  const handleStopWorkflow = (id: string) => {
    setWorkflows(prev => prev.map(w => w.id === id ? { ...w, status: 'draft' } : w));
    toast.success('Workflow stopped.');
  };

  const resetWorkflowForm = () => {
    setNewWorkflowName('');
    setNewWorkflowDescription('');
    setEditingWorkflowId(null);
  };

  const getStatusColor = (status: WorkflowOrchestration['status']) => {
    switch (status) {
      case 'active': return 'text-green-500';
      case 'paused': return 'text-yellow-500';
      case 'error': return 'text-red-500';
      case 'draft': return 'text-muted-foreground';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusIcon = (status: WorkflowOrchestration['status']) => {
    switch (status) {
      case 'active': return <Play className="w-4 h-4 text-green-500" />;
      case 'paused': return <Pause className="w-4 h-4 text-yellow-500" />;
      case 'error': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'draft': return <Settings className="w-4 h-4 text-muted-foreground" />;
      default: return <Settings className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const selectedWorkflow = workflows.find(w => w.id === selectedWorkflowId);
  const workflowLogs = executionLogs.filter(log => log.workflowId === selectedWorkflowId);

  return (
    <div className="p-6 bg-background min-h-screen text-foreground">
      <h1 className="text-3xl font-bold gradient-text mb-6">Advanced Workflow Automation & Orchestration Engine</h1>
      <p className="text-muted-foreground mb-8">
        Design, execute, and monitor complex multi-step workflows that orchestrate Voice AI agents, GHL integrations, and external services with intelligent decision-making and error handling.
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Workflow Management */}
        <div className="lg:col-span-2">
          <div className="card p-6 mb-6">
            <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
              <Workflow className="w-6 h-6 mr-2 text-purple-400" /> Workflow Management
            </h2>
            <div className="mb-4">
              <label htmlFor="workflow-name" className="block text-sm font-medium text-muted-foreground mb-1">
                Workflow Name
              </label>
              <input
                type="text"
                id="workflow-name"
                className="w-full input"
                value={newWorkflowName}
                onChange={(e) => setNewWorkflowName(e.target.value)}
                placeholder="e.g., Solar Lead Qualification & Follow-up"
              />
            </div>
            <div className="mb-4">
              <label htmlFor="workflow-description" className="block text-sm font-medium text-muted-foreground mb-1">
                Description
              </label>
              <textarea
                id="workflow-description"
                className="w-full input"
                rows={2}
                value={newWorkflowDescription}
                onChange={(e) => setNewWorkflowDescription(e.target.value)}
                placeholder="Brief description of what this workflow accomplishes"
              />
            </div>
            <div className="flex justify-end gap-3">
              <button onClick={resetWorkflowForm} className="btn btn-secondary">
                <RefreshCw className="w-5 h-5 mr-2" /> Clear
              </button>
              <button onClick={handleSaveWorkflow} className="btn btn-primary">
                <Plus className="w-5 h-5 mr-2" /> {editingWorkflowId ? 'Update Workflow' : 'Create Workflow'}
              </button>
            </div>
          </div>

          <div className="card p-6">
            <h2 className="text-xl font-semibold text-foreground mb-4">Active Workflows</h2>
            {workflows.length === 0 ? (
              <p className="text-muted-foreground">No workflows configured yet.</p>
            ) : (
              <div className="space-y-4">
                {workflows.map((workflow) => (
                  <div key={workflow.id} className="bg-secondary p-4 rounded-lg border border-border">
                    <div className="flex justify-between items-center mb-2">
                      <h3 className="font-medium text-foreground flex items-center">
                        {getStatusIcon(workflow.status)} {workflow.name}
                      </h3>
                      <span className={`text-sm font-semibold ${getStatusColor(workflow.status)}`}>
                        {workflow.status.charAt(0).toUpperCase() + workflow.status.slice(1)}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">{workflow.description}</p>
                    <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground mb-3">
                      <div>Steps: <span className="font-medium text-foreground">{workflow.steps.length}</span></div>
                      <div>Executions: <span className="font-medium text-foreground">{workflow.executionCount}</span></div>
                      <div>Success Rate: <span className="font-medium text-foreground">{workflow.successRate.toFixed(1)}%</span></div>
                      <div>Avg. Time: <span className="font-medium text-foreground">{workflow.avgExecutionTime.toFixed(1)}s</span></div>
                    </div>
                    <div className="flex justify-end gap-2">
                      {workflow.status === 'draft' && (
                        <button onClick={() => handleStartWorkflow(workflow.id)} className="btn btn-sm btn-primary" disabled={isExecuting}>
                          <Play className="w-4 h-4" /> Start
                        </button>
                      )}
                      {workflow.status === 'active' && (
                        <>
                          <button onClick={() => handlePauseWorkflow(workflow.id)} className="btn btn-sm btn-secondary">
                            <Pause className="w-4 h-4" /> Pause
                          </button>
                          <button onClick={() => handleStopWorkflow(workflow.id)} className="btn btn-sm btn-destructive">
                            <StopCircle className="w-4 h-4" /> Stop
                          </button>
                        </>
                      )}
                      {workflow.status === 'paused' && (
                        <>
                          <button onClick={() => handleStartWorkflow(workflow.id)} className="btn btn-sm btn-primary" disabled={isExecuting}>
                            <Play className="w-4 h-4" /> Resume
                          </button>
                          <button onClick={() => handleStopWorkflow(workflow.id)} className="btn btn-sm btn-destructive">
                            <StopCircle className="w-4 h-4" /> Stop
                          </button>
                        </>
                      )}
                      <button onClick={() => handleEditWorkflow(workflow)} className="btn btn-sm btn-outline">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button onClick={() => handleDeleteWorkflow(workflow.id)} className="btn btn-sm btn-destructive">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Workflow Details & Logs */}
        <div>
          <div className="card p-6 mb-6">
            <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
              <BarChart3 className="w-6 h-6 mr-2 text-blue-400" /> Workflow Details
            </h2>
            {selectedWorkflow ? (
              <div className="space-y-3">
                <div>
                  <p className="text-sm text-muted-foreground">Name</p>
                  <p className="font-medium text-foreground">{selectedWorkflow.name}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Description</p>
                  <p className="text-sm text-foreground">{selectedWorkflow.description}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Status</p>
                  <p className={`font-medium ${getStatusColor(selectedWorkflow.status)}`}>
                    {selectedWorkflow.status.charAt(0).toUpperCase() + selectedWorkflow.status.slice(1)}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Steps</p>
                  <p className="font-medium text-foreground">{selectedWorkflow.steps.length} configured</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Last Executed</p>
                  <p className="font-medium text-foreground">
                    {selectedWorkflow.lastExecuted ? new Date(selectedWorkflow.lastExecuted).toLocaleString() : 'Never'}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Success Rate</p>
                  <p className="font-medium text-foreground">{selectedWorkflow.successRate.toFixed(1)}%</p>
                </div>
              </div>
            ) : (
              <p className="text-muted-foreground">Select a workflow to view details.</p>
            )}
          </div>

          <div className="card p-6">
            <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
              <Clock className="w-6 h-6 mr-2 text-green-400" /> Execution Logs
            </h2>
            {workflowLogs.length === 0 ? (
              <p className="text-muted-foreground">No execution logs for selected workflow.</p>
            ) : (
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {workflowLogs.slice(0, 10).map((log) => (
                  <div key={log.id} className="bg-secondary p-3 rounded-lg border border-border">
                    <div className="flex justify-between items-center mb-1">
                      <span className={`text-sm font-medium ${log.status === 'success' ? 'text-green-500' : log.status === 'error' ? 'text-red-500' : 'text-yellow-500'}`}>
                        {log.status.charAt(0).toUpperCase() + log.status.slice(1)}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {log.duration ? `${log.duration.toFixed(1)}s` : 'Running...'}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {new Date(log.startTime).toLocaleString()}
                    </p>
                    {log.errorMessage && (
                      <p className="text-xs text-red-400 mt-1">{log.errorMessage}</p>
                    )}
                    <p className="text-xs text-muted-foreground mt-1">
                      Steps: {log.stepsExecuted.length}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default WorkflowOrchestrationEngine;
