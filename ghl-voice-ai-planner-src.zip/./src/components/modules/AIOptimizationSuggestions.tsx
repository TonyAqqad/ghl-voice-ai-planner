import React, { useState, useEffect } from 'react';
import { 
  Brain, 
  Lightbulb, 
  TrendingUp, 
  Target, 
  Zap, 
  CheckCircle, 
  AlertTriangle, 
  Clock, 
  BarChart3, 
  Settings,
  Play,
  Pause,
  RefreshCw,
  Download,
  Eye,
  Filter,
  Search,
  Star,
  ArrowRight,
  MessageSquare,
  Phone,
  Users,
  DollarSign,
  Activity
} from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';

interface OptimizationSuggestion {
  id: string;
  title: string;
  description: string;
  category: 'performance' | 'conversion' | 'efficiency' | 'cost' | 'quality';
  priority: 'low' | 'medium' | 'high' | 'critical';
  impact: {
    metric: string;
    currentValue: number;
    projectedValue: number;
    improvement: number;
  };
  effort: 'low' | 'medium' | 'high';
  status: 'pending' | 'in_progress' | 'completed' | 'dismissed';
  agentId: string;
  agentName: string;
  createdAt: string;
  estimatedSavings?: number;
  implementationSteps: string[];
  aiConfidence: number;
}

interface OptimizationMetrics {
  totalSuggestions: number;
  implementedSuggestions: number;
  averageImprovement: number;
  totalSavings: number;
  topPerformingCategory: string;
  aiAccuracy: number;
}

const AIOptimizationSuggestions: React.FC = () => {
  const { darkMode } = useStore();
  const [suggestions, setSuggestions] = useState<OptimizationSuggestion[]>([]);
  const [metrics, setMetrics] = useState<OptimizationMetrics>({
    totalSuggestions: 0,
    implementedSuggestions: 0,
    averageImprovement: 0,
    totalSavings: 0,
    topPerformingCategory: '',
    aiAccuracy: 0
  });
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedPriority, setSelectedPriority] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Sample data - in real app this would come from AI analysis
  useEffect(() => {
    const sampleSuggestions: OptimizationSuggestion[] = [
      {
        id: 'suggestion_1',
        title: 'Optimize F45 Trial Booking Script',
        description: 'The current greeting script has a 15% lower conversion rate compared to industry benchmarks. AI analysis suggests shortening the introduction and leading with the value proposition.',
        category: 'conversion',
        priority: 'high',
        impact: {
          metric: 'Conversion Rate',
          currentValue: 0.23,
          projectedValue: 0.31,
          improvement: 0.08
        },
        effort: 'low',
        status: 'pending',
        agentId: 'agent_1',
        agentName: 'F45 Fitness Agent',
        createdAt: '2024-01-15T10:30:00Z',
        estimatedSavings: 2400,
        implementationSteps: [
          'Update greeting script to lead with value proposition',
          'Reduce introduction length by 30%',
          'Add urgency element to trial offer',
          'Test A/B version for 1 week'
        ],
        aiConfidence: 0.87
      },
      {
        id: 'suggestion_2',
        title: 'Implement Smart Transfer Rules',
        description: 'Current transfer logic is causing 23% of high-value leads to be transferred unnecessarily. AI recommends implementing confidence-based transfer thresholds.',
        category: 'efficiency',
        priority: 'high',
        impact: {
          metric: 'Transfer Rate',
          currentValue: 0.45,
          projectedValue: 0.22,
          improvement: -0.23
        },
        effort: 'medium',
        status: 'pending',
        agentId: 'agent_2',
        agentName: 'Legal Consultation Agent',
        createdAt: '2024-01-15T09:15:00Z',
        estimatedSavings: 1800,
        implementationSteps: [
          'Analyze current transfer patterns',
          'Set confidence threshold to 0.85',
          'Implement dynamic transfer rules',
          'Monitor transfer quality metrics'
        ],
        aiConfidence: 0.92
      },
      {
        id: 'suggestion_3',
        title: 'Add Emergency Response Keywords',
        description: 'Plumbing emergency agent is missing 12% of urgent calls due to limited keyword recognition. AI suggests expanding emergency keyword list.',
        category: 'quality',
        priority: 'critical',
        impact: {
          metric: 'Emergency Detection Rate',
          currentValue: 0.88,
          projectedValue: 0.95,
          improvement: 0.07
        },
        effort: 'low',
        status: 'in_progress',
        agentId: 'agent_3',
        agentName: 'Plumbing Emergency Agent',
        createdAt: '2024-01-15T08:45:00Z',
        estimatedSavings: 3200,
        implementationSteps: [
          'Add 15 new emergency keywords',
          'Update intent recognition patterns',
          'Test with emergency scenarios',
          'Deploy to production'
        ],
        aiConfidence: 0.95
      },
      {
        id: 'suggestion_4',
        title: 'Optimize Call Duration',
        description: 'Martial arts agent calls are 40% longer than optimal. AI analysis shows opportunity to streamline qualification process.',
        category: 'efficiency',
        priority: 'medium',
        impact: {
          metric: 'Average Call Duration',
          currentValue: 189,
          projectedValue: 145,
          improvement: -44
        },
        effort: 'medium',
        status: 'completed',
        agentId: 'agent_4',
        agentName: 'Martial Arts Agent',
        createdAt: '2024-01-14T16:20:00Z',
        estimatedSavings: 1200,
        implementationSteps: [
          'Streamline qualification questions',
          'Implement skip logic for common responses',
          'Add quick qualification shortcuts',
          'Monitor call quality metrics'
        ],
        aiConfidence: 0.78
      },
      {
        id: 'suggestion_5',
        title: 'Implement Dynamic Pricing',
        description: 'Construction consultation agent could increase revenue by 18% with dynamic pricing based on project scope and urgency.',
        category: 'cost',
        priority: 'medium',
        impact: {
          metric: 'Revenue per Call',
          currentValue: 450,
          projectedValue: 531,
          improvement: 81
        },
        effort: 'high',
        status: 'pending',
        agentId: 'agent_5',
        agentName: 'Construction Agent',
        createdAt: '2024-01-15T11:10:00Z',
        estimatedSavings: 5600,
        implementationSteps: [
          'Develop pricing algorithm',
          'Integrate with project assessment',
          'Update consultation scripts',
          'Train staff on new pricing'
        ],
        aiConfidence: 0.83
      }
    ];

    setSuggestions(sampleSuggestions);
    
    // Calculate metrics
    const implemented = sampleSuggestions.filter(s => s.status === 'completed').length;
    const avgImprovement = sampleSuggestions.reduce((sum, s) => sum + s.impact.improvement, 0) / sampleSuggestions.length;
    const totalSavings = sampleSuggestions.reduce((sum, s) => sum + (s.estimatedSavings || 0), 0);
    const categoryCounts = sampleSuggestions.reduce((acc, s) => {
      acc[s.category] = (acc[s.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    const topCategory = Object.entries(categoryCounts).reduce((a, b) => a[1] > b[1] ? a : b)[0];
    
    setMetrics({
      totalSuggestions: sampleSuggestions.length,
      implementedSuggestions: implemented,
      averageImprovement: avgImprovement,
      totalSavings,
      topPerformingCategory: topCategory,
      aiAccuracy: 0.87
    });
  }, []);

  const categories = [
    { id: 'all', name: 'All Categories', icon: BarChart3 },
    { id: 'performance', name: 'Performance', icon: TrendingUp },
    { id: 'conversion', name: 'Conversion', icon: Target },
    { id: 'efficiency', name: 'Efficiency', icon: Zap },
    { id: 'cost', name: 'Cost Optimization', icon: DollarSign },
    { id: 'quality', name: 'Quality', icon: Star }
  ];

  const priorities = [
    { id: 'all', name: 'All Priorities', color: 'text-gray-400' },
    { id: 'critical', name: 'Critical', color: 'text-red-400' },
    { id: 'high', name: 'High', color: 'text-orange-400' },
    { id: 'medium', name: 'Medium', color: 'text-yellow-400' },
    { id: 'low', name: 'Low', color: 'text-green-400' }
  ];

  const filteredSuggestions = suggestions.filter(suggestion => {
    const matchesSearch = suggestion.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         suggestion.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || suggestion.category === selectedCategory;
    const matchesPriority = selectedPriority === 'all' || suggestion.priority === selectedPriority;
    return matchesSearch && matchesCategory && matchesPriority;
  });

  const handleImplementSuggestion = (suggestionId: string) => {
    setSuggestions(prev => 
      prev.map(s => 
        s.id === suggestionId 
          ? { ...s, status: 'in_progress' as const }
          : s
      )
    );
    toast.success('Suggestion implementation started');
  };

  const handleCompleteSuggestion = (suggestionId: string) => {
    setSuggestions(prev => 
      prev.map(s => 
        s.id === suggestionId 
          ? { ...s, status: 'completed' as const }
          : s
      )
    );
    toast.success('Suggestion implemented successfully');
  };

  const handleDismissSuggestion = (suggestionId: string) => {
    setSuggestions(prev => 
      prev.map(s => 
        s.id === suggestionId 
          ? { ...s, status: 'dismissed' as const }
          : s
      )
    );
    toast.success('Suggestion dismissed');
  };

  const handleRunAnalysis = () => {
    setIsAnalyzing(true);
    setTimeout(() => {
      setIsAnalyzing(false);
      toast.success('AI analysis completed - 3 new suggestions found');
    }, 3000);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'text-red-400 bg-red-100';
      case 'high': return 'text-orange-400 bg-orange-100';
      case 'medium': return 'text-yellow-400 bg-yellow-100';
      case 'low': return 'text-green-400 bg-green-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-400 bg-green-100';
      case 'in_progress': return 'text-blue-400 bg-blue-100';
      case 'pending': return 'text-yellow-400 bg-yellow-100';
      case 'dismissed': return 'text-gray-400 bg-gray-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const renderSuggestionCard = (suggestion: OptimizationSuggestion) => (
    <div key={suggestion.id} className="card p-6 hover:shadow-lg transition-all duration-200">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <h3 className="text-lg font-semibold text-foreground">{suggestion.title}</h3>
            <div className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(suggestion.priority)}`}>
              {suggestion.priority}
            </div>
            <div className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(suggestion.status)}`}>
              {suggestion.status}
            </div>
          </div>
          <p className="text-muted-foreground mb-3">{suggestion.description}</p>
          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
            <div className="flex items-center space-x-1">
              <MessageSquare className="w-4 h-4" />
              <span>{suggestion.agentName}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Brain className="w-4 h-4" />
              <span>{Math.round(suggestion.aiConfidence * 100)}% confidence</span>
            </div>
            <div className="flex items-center space-x-1">
              <Clock className="w-4 h-4" />
              <span>{suggestion.effort} effort</span>
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {/* Impact Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-secondary p-3 rounded">
            <p className="text-sm text-muted-foreground">Current {suggestion.impact.metric}</p>
            <p className="text-lg font-semibold text-foreground">
              {typeof suggestion.impact.currentValue === 'number' && suggestion.impact.currentValue < 1
                ? `${Math.round(suggestion.impact.currentValue * 100)}%`
                : suggestion.impact.currentValue}
            </p>
          </div>
          <div className="bg-secondary p-3 rounded">
            <p className="text-sm text-muted-foreground">Projected {suggestion.impact.metric}</p>
            <p className="text-lg font-semibold text-foreground">
              {typeof suggestion.impact.projectedValue === 'number' && suggestion.impact.projectedValue < 1
                ? `${Math.round(suggestion.impact.projectedValue * 100)}%`
                : suggestion.impact.projectedValue}
            </p>
          </div>
          <div className="bg-secondary p-3 rounded">
            <p className="text-sm text-muted-foreground">Improvement</p>
            <p className={`text-lg font-semibold ${
              suggestion.impact.improvement > 0 ? 'text-green-400' : 'text-red-400'
            }`}>
              {suggestion.impact.improvement > 0 ? '+' : ''}
              {typeof suggestion.impact.improvement === 'number' && Math.abs(suggestion.impact.improvement) < 1
                ? `${Math.round(suggestion.impact.improvement * 100)}%`
                : suggestion.impact.improvement}
            </p>
          </div>
        </div>

        {/* Implementation Steps */}
        <div>
          <h4 className="font-medium text-foreground mb-2">Implementation Steps:</h4>
          <ol className="space-y-1">
            {suggestion.implementationSteps.map((step, index) => (
              <li key={index} className="flex items-start space-x-2 text-sm text-muted-foreground">
                <span className="w-5 h-5 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xs font-medium mt-0.5">
                  {index + 1}
                </span>
                <span>{step}</span>
              </li>
            ))}
          </ol>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-between pt-4 border-t border-border">
          <div className="flex items-center space-x-2">
            {suggestion.estimatedSavings && (
              <span className="text-sm text-green-400 font-medium">
                Est. Savings: ${suggestion.estimatedSavings.toLocaleString()}
              </span>
            )}
          </div>
          <div className="flex items-center space-x-2">
            {suggestion.status === 'pending' && (
              <button
                onClick={() => handleImplementSuggestion(suggestion.id)}
                className="btn btn-primary btn-sm"
              >
                <Play className="w-4 h-4 mr-2" />
                Implement
              </button>
            )}
            {suggestion.status === 'in_progress' && (
              <button
                onClick={() => handleCompleteSuggestion(suggestion.id)}
                className="btn btn-primary btn-sm"
              >
                <CheckCircle className="w-4 h-4 mr-2" />
                Complete
              </button>
            )}
            <button
              onClick={() => handleDismissSuggestion(suggestion.id)}
              className="btn btn-outline btn-sm"
            >
              Dismiss
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="p-6 bg-background min-h-screen text-foreground">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">AI Optimization Suggestions</h1>
            <p className="text-muted-foreground">
              AI-powered recommendations to optimize your voice AI agents and improve performance
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <button
              onClick={handleRunAnalysis}
              disabled={isAnalyzing}
              className="btn btn-primary"
            >
              {isAnalyzing ? (
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Brain className="w-4 h-4 mr-2" />
              )}
              {isAnalyzing ? 'Analyzing...' : 'Run AI Analysis'}
            </button>
            <button className="btn btn-outline">
              <Download className="w-4 h-4 mr-2" />
              Export
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Suggestions</p>
              <p className="text-2xl font-bold text-foreground">{metrics.totalSuggestions}</p>
            </div>
            <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
              <Lightbulb className="w-6 h-6 text-primary" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Implemented</p>
              <p className="text-2xl font-bold text-foreground">{metrics.implementedSuggestions}</p>
              <p className="text-sm text-green-400">
                {Math.round((metrics.implementedSuggestions / metrics.totalSuggestions) * 100)}% adoption
              </p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Avg Improvement</p>
              <p className="text-2xl font-bold text-foreground">
                {metrics.averageImprovement > 0 ? '+' : ''}
                {Math.round(metrics.averageImprovement * 100)}%
              </p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Savings</p>
              <p className="text-2xl font-bold text-foreground">${metrics.totalSavings.toLocaleString()}</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="card p-6 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <input
                type="text"
                placeholder="Search suggestions..."
                className="w-full pl-10 input"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          <div className="flex space-x-2">
            <select
              className="input"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              {categories.map(category => (
                <option key={category.id} value={category.id}>{category.name}</option>
              ))}
            </select>
            <select
              className="input"
              value={selectedPriority}
              onChange={(e) => setSelectedPriority(e.target.value)}
            >
              {priorities.map(priority => (
                <option key={priority.id} value={priority.id}>{priority.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Suggestions Grid */}
      <div className="space-y-6">
        {filteredSuggestions.map(renderSuggestionCard)}
      </div>

      {filteredSuggestions.length === 0 && (
        <div className="text-center py-12">
          <Brain className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
          <h3 className="text-lg font-semibold text-foreground mb-2">No suggestions found</h3>
          <p className="text-muted-foreground mb-4">
            Try adjusting your filters or run a new AI analysis
          </p>
          <button
            onClick={handleRunAnalysis}
            className="btn btn-primary"
          >
            <Brain className="w-4 h-4 mr-2" />
            Run AI Analysis
          </button>
        </div>
      )}
    </div>
  );
};

export default AIOptimizationSuggestions;
