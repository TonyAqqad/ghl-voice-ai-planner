import React, { useState, useEffect } from 'react';
import {
  Shield,
  CheckCircle,
  XCircle,
  AlertTriangle,
  RefreshCw,
  Play,
  Pause,
  Settings,
  Download,
  Upload,
  Save,
  Edit,
  Trash2,
  Plus,
  Minus,
  ChevronDown,
  ChevronRight,
  Eye,
  EyeOff,
  Filter,
  Search,
  SortAsc,
  SortDesc,
  MoreHorizontal,
  Star,
  ThumbsUp,
  ThumbsDown,
  Heart,
  Smile,
  Frown,
  Meh,
  Award,
  Trophy,
  Medal,
  Crown,
  Flame,
  Zap as Lightning,
  Rocket,
  Lock,
  Unlock,
  Key,
  Wrench,
  Cog,
  Sliders,
  ToggleLeft,
  ToggleRight,
  ToggleLeft as Switch,
  Power,
  PowerOff,
  Battery,
  BatteryCharging,
  Wifi,
  WifiOff,
  Signal,
  MessageSquare,
  Mic,
  Headphones,
  Volume2,
  VolumeX,
  SkipForward,
  SkipBack,
  RotateCcw,
  BarChart3,
  LineChart,
  PieChart,
  Activity,
  Clock,
  Users,
  Phone,
  Bot,
  Brain,
  Target,
  TrendingUp,
  TrendingDown,
  Database,
  Server,
  Globe,
  FileText,
  FileCheck,
  FileX,
  FileWarning as FileAlert,
  FileLock,
  Shield as FileShield,
  FileSearch,
  FileCode,
  FileImage,
  FileVideo,
  FileAudio,
  FileArchive,
  FileSpreadsheet,
  Presentation as FilePresentation,
  FileText as FilePdf,
  FileText as FileWord,
  Table as FileExcel,
  Presentation as FilePowerpoint,
  FileZip,
  FileJson,
  FileXml,
  FileCsv,
  FileHtml,
  FileCss,
  FileJs,
  FileTs,
  FileJsx,
  FileTsx,
  FileVue,
  FileSvelte,
  FileAngular,
  FileReact,
  FileNode,
  FilePython,
  FileJava,
  FileC,
  FileCpp,
  FileCsharp,
  FilePhp,
  FileRuby,
  FileGo,
  FileRust,
  FileSwift,
  FileKotlin,
  FileDart,
  FileScala,
  FileClojure,
  FileHaskell,
  FileElixir,
  FileErlang,
  FileLua,
  FilePerl,
  FileR,
  FileMatlab,
  FileOctave,
  FileJulia,
  FileNim,
  FileCrystal,
  FileZig,
  FileOcaml,
  FileFsharp,
  FileD,
  FileNimrod,
  FilePascal,
  FileDelphi,
  FileFortran,
  FileCobol,
  FileAda,
  FileAssembly,
  FileBash,
  FilePowershell,
  FileBatch,
  FileDocker,
  FileKubernetes,
  FileTerraform,
  FileAnsible,
  FileChef,
  FilePuppet,
  FileVagrant,
  FileJenkins,
  FileTravis,
  FileCircleci,
  FileGitlab,
  FileGithub,
  FileBitbucket,
  FileGit,
  FileGitCommit,
  FileGitBranch,
  FileGitMerge,
  FileGitPullRequest,
  FileGitCompare,
  FileGitCherryPick,
  FileGitRebase,
  FileGitReset,
  FileGitRevert,
  FileGitStash,
  FileGitTag,
  FileGitLog,
  FileGitDiff,
  FileGitPatch,
  FileGitBlame,
  FileGitHistory,
  FileGitGraph,
  FileGitTree,
  FileGitSubmodule,
  FileGitLfs,
  FileGitHooks,
  FileGitAttributes,
  FileGitIgnore,
  FileGitConfig,
  FileGitModules,
  FileGitCredentials,
  FileGitSsh,
  FileGitHttps,
  FileGitProtocol,
  FileGitTransport,
  FileGitPack,
  FileGitIndex,
  FileGitObjects,
  FileGitRefs,
  FileGitHeads,
  FileGitTags,
  FileGitRemotes,
  FileGitOrigin,
  FileGitUpstream,
  FileGitFork,
  FileGitClone,
  FileGitFetch,
  FileGitPull,
  FileGitPush,
  FileGitRemote,
  FileGitAdd,
  FileGitCommitMessage,
  FileGitCommitAmend,
  FileGitCommitSquash,
  FileGitCommitFixup,
  FileGitCommitReword,
  FileGitCommitEdit,
  FileGitCommitDrop,
  FileGitCommitPick,
  FileGitCommitResolve,
  FileGitCommitContinue,
  FileGitCommitAbort,
  FileGitCommitSkip,
  FileGitCommitQuit,
  FileGitCommitBreak,
  FileGitCommitExec,
  FileGitCommitLabel,
  FileGitCommitReset,
  FileGitCommitMerge,
  FileGitCommitNoop,
  FileGitCommitStart,
  FileGitCommitEnd,
  FileGitCommitEmpty,
  FileGitCommitInitial,
  FileGitCommitRoot,
  FileGitCommitDetached,
  FileGitCommitOrphan,
  FileGitCommitUnborn,
  FileGitCommitHead,
  FileGitCommitMaster,
  FileGitCommitMain,
  FileGitCommitDevelop,
  FileGitCommitFeature,
  FileGitCommitBugfix,
  FileGitCommitHotfix,
  FileGitCommitRelease,
  FileGitCommitSupport,
  FileGitCommitVersion,
  FileGitCommitStable,
  FileGitCommitBeta,
  FileGitCommitAlpha,
  FileGitCommitDev,
  FileGitCommitTest,
  FileGitCommitStaging,
  FileGitCommitProduction,
  FileGitCommitLive,
  FileGitCommitProd
} from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';

interface ComplianceRule {
  id: string;
  name: string;
  description: string;
  category: 'TCPA' | 'GDPR' | 'CCPA' | 'HIPAA' | 'SOX' | 'PCI-DSS' | 'FERPA' | 'COPPA' | 'CAN-SPAM' | 'Custom';
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  status: 'Pass' | 'Fail' | 'Warning' | 'Pending';
  lastChecked: string;
  autoFix: boolean;
  requirements: string[];
  documentation: string;
}

interface ComplianceCheck {
  id: string;
  ruleId: string;
  timestamp: string;
  status: 'Pass' | 'Fail' | 'Warning' | 'Pending';
  details: string;
  recommendations: string[];
  autoFixed: boolean;
}

const ComplianceChecker: React.FC = () => {
  const { } = useStore();
  const [rules, setRules] = useState<ComplianceRule[]>([]);
  const [checks, setChecks] = useState<ComplianceCheck[]>([]);
  const [selectedRule, setSelectedRule] = useState<ComplianceRule | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [filter, setFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Sample data
  useEffect(() => {
    const sampleRules: ComplianceRule[] = [
      {
        id: '1',
        name: 'TCPA Consent Verification',
        description: 'Ensures proper consent is obtained before making automated calls',
        category: 'TCPA',
        severity: 'Critical',
        status: 'Pass',
        lastChecked: '2024-01-15T10:30:00Z',
        autoFix: true,
        requirements: [
          'Express written consent required',
          'Clear identification of caller',
          'Opt-out mechanism provided',
          'Time restrictions respected'
        ],
        documentation: 'https://www.fcc.gov/consumers/guides/robocalls'
      },
      {
        id: '2',
        name: 'GDPR Data Processing',
        description: 'Validates compliance with GDPR data processing requirements',
        category: 'GDPR',
        severity: 'High',
        status: 'Warning',
        lastChecked: '2024-01-15T09:45:00Z',
        autoFix: false,
        requirements: [
          'Lawful basis for processing',
          'Data subject rights respected',
          'Privacy notice provided',
          'Data retention limits enforced'
        ],
        documentation: 'https://gdpr.eu/what-is-gdpr/'
      },
      {
        id: '3',
        name: 'CCPA Consumer Rights',
        description: 'Ensures California Consumer Privacy Act compliance',
        category: 'CCPA',
        severity: 'High',
        status: 'Pass',
        lastChecked: '2024-01-15T11:15:00Z',
        autoFix: true,
        requirements: [
          'Right to know about data collection',
          'Right to delete personal information',
          'Right to opt-out of sale',
          'Non-discrimination policy'
        ],
        documentation: 'https://oag.ca.gov/privacy/ccpa'
      }
    ];

    const sampleChecks: ComplianceCheck[] = [
      {
        id: '1',
        ruleId: '1',
        timestamp: '2024-01-15T10:30:00Z',
        status: 'Pass',
        details: 'All TCPA requirements verified successfully',
        recommendations: ['Continue monitoring consent rates'],
        autoFixed: false
      },
      {
        id: '2',
        ruleId: '2',
        timestamp: '2024-01-15T09:45:00Z',
        status: 'Warning',
        details: 'Data retention policy needs review',
        recommendations: ['Update retention schedule', 'Review data categories'],
        autoFixed: false
      }
    ];

    setRules(sampleRules);
    setChecks(sampleChecks);
  }, []);

  const filteredRules = rules.filter(rule => {
    const matchesFilter = filter === 'all' || rule.category === filter || rule.severity === filter;
    const matchesSearch = rule.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         rule.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const runComplianceCheck = async () => {
    setIsRunning(true);
    toast.loading('Running compliance checks...', { id: 'compliance-check' });

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Update rule statuses
    const updatedRules = rules.map(rule => ({
      ...rule,
      status: Math.random() > 0.3 ? 'Pass' : Math.random() > 0.5 ? 'Warning' : 'Fail',
      lastChecked: new Date().toISOString()
    }));

    setRules(updatedRules);

    // Add new check
    const newCheck: ComplianceCheck = {
      id: Date.now().toString(),
      ruleId: '1',
      timestamp: new Date().toISOString(),
      status: 'Pass',
      details: 'Compliance check completed successfully',
      recommendations: ['Continue regular monitoring'],
      autoFixed: false
    };

    setChecks(prev => [newCheck, ...prev]);

    toast.success('Compliance check completed!', { id: 'compliance-check' });
    setIsRunning(false);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Pass': return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'Fail': return <XCircle className="w-5 h-5 text-red-500" />;
      case 'Warning': return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
      case 'Pending': return <Clock className="w-5 h-5 text-blue-500" />;
      default: return <AlertTriangle className="w-5 h-5 text-gray-500" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'Critical': return 'text-red-500 bg-red-50';
      case 'High': return 'text-orange-500 bg-orange-50';
      case 'Medium': return 'text-yellow-500 bg-yellow-50';
      case 'Low': return 'text-green-500 bg-green-50';
      default: return 'text-gray-500 bg-gray-50';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <Shield className="w-8 h-8 text-blue-600" />
                Compliance & Safety Checker
              </h1>
              <p className="text-gray-600 mt-2">
                Automated compliance monitoring and risk assessment for voice AI agents
              </p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={runComplianceCheck}
                disabled={isRunning}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isRunning ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Play className="w-4 h-4" />
                )}
                {isRunning ? 'Running...' : 'Run Check'}
              </button>
              <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50">
                <Settings className="w-4 h-4" />
                Settings
              </button>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Rules</p>
                <p className="text-2xl font-bold text-gray-900">{rules.length}</p>
              </div>
              <Shield className="w-8 h-8 text-blue-600" />
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Passing</p>
                <p className="text-2xl font-bold text-green-600">
                  {rules.filter(r => r.status === 'Pass').length}
                </p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Warnings</p>
                <p className="text-2xl font-bold text-yellow-600">
                  {rules.filter(r => r.status === 'Warning').length}
                </p>
              </div>
              <AlertTriangle className="w-8 h-8 text-yellow-600" />
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Failing</p>
                <p className="text-2xl font-bold text-red-600">
                  {rules.filter(r => r.status === 'Fail').length}
                </p>
              </div>
              <XCircle className="w-8 h-8 text-red-600" />
            </div>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="bg-white p-6 rounded-lg shadow-sm border mb-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  placeholder="Search compliance rules..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <select
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">All Categories</option>
                <option value="TCPA">TCPA</option>
                <option value="GDPR">GDPR</option>
                <option value="CCPA">CCPA</option>
                <option value="HIPAA">HIPAA</option>
                <option value="SOX">SOX</option>
                <option value="PCI-DSS">PCI-DSS</option>
                <option value="Critical">Critical</option>
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>
          </div>
        </div>

        {/* Rules List */}
        <div className="bg-white rounded-lg shadow-sm border">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Compliance Rules</h2>
          </div>
          <div className="divide-y divide-gray-200">
            {filteredRules.map((rule) => (
              <div
                key={rule.id}
                className="p-6 hover:bg-gray-50 cursor-pointer"
                onClick={() => setSelectedRule(rule)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      {getStatusIcon(rule.status)}
                      <h3 className="text-lg font-medium text-gray-900">{rule.name}</h3>
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${getSeverityColor(rule.severity)}`}>
                        {rule.severity}
                      </span>
                      <span className="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">
                        {rule.category}
                      </span>
                    </div>
                    <p className="text-gray-600 mb-3">{rule.description}</p>
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <span>Last checked: {new Date(rule.lastChecked).toLocaleString()}</span>
                      {rule.autoFix && (
                        <span className="flex items-center gap-1">
                          <Settings className="w-3 h-3" />
                          Auto-fix enabled
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="p-2 text-gray-400 hover:text-gray-600">
                      <Eye className="w-4 h-4" />
                    </button>
                    <button className="p-2 text-gray-400 hover:text-gray-600">
                      <Edit className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Checks */}
        <div className="mt-8 bg-white rounded-lg shadow-sm border">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Recent Compliance Checks</h2>
          </div>
          <div className="divide-y divide-gray-200">
            {checks.slice(0, 5).map((check) => (
              <div key={check.id} className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(check.status)}
                    <span className="font-medium text-gray-900">
                      {rules.find(r => r.id === check.ruleId)?.name || 'Unknown Rule'}
                    </span>
                  </div>
                  <span className="text-sm text-gray-500">
                    {new Date(check.timestamp).toLocaleString()}
                  </span>
                </div>
                <p className="text-gray-600 mb-2">{check.details}</p>
                {check.recommendations.length > 0 && (
                  <div className="mt-2">
                    <p className="text-sm font-medium text-gray-700 mb-1">Recommendations:</p>
                    <ul className="text-sm text-gray-600 list-disc list-inside">
                      {check.recommendations.map((rec, index) => (
                        <li key={index}>{rec}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ComplianceChecker;