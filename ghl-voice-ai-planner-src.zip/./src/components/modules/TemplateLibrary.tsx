import React from 'react';
import { BookOpen, Download } from 'lucide-react';

const TemplateLibrary: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Template Library</h1>
          <p className="text-muted-foreground mt-2">
            Pre-built voice agent templates for different industries
          </p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="card">
          <div className="card-content">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Real Estate</h3>
                <p className="text-sm text-muted-foreground">Lead qualification & appointment setting</p>
              </div>
            </div>
            <button className="btn btn-sm btn-outline w-full flex items-center justify-center space-x-2">
              <Download className="w-3 h-3" />
              <span>Use Template</span>
            </button>
          </div>
        </div>
        
        <div className="card">
          <div className="card-content">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Healthcare</h3>
                <p className="text-sm text-muted-foreground">Appointment scheduling & reminders</p>
              </div>
            </div>
            <button className="btn btn-sm btn-outline w-full flex items-center justify-center space-x-2">
              <Download className="w-3 h-3" />
              <span>Use Template</span>
            </button>
          </div>
        </div>
        
        <div className="card">
          <div className="card-content">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">E-commerce</h3>
                <p className="text-sm text-muted-foreground">Order support & customer service</p>
              </div>
            </div>
            <button className="btn btn-sm btn-outline w-full flex items-center justify-center space-x-2">
              <Download className="w-3 h-3" />
              <span>Use Template</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TemplateLibrary;
