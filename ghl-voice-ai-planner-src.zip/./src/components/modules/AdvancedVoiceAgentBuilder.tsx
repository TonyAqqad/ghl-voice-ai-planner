import React, { useState, useEffect } from 'react';
import { 
  Bot, 
  Play, 
  Save, 
  Settings, 
  Zap, 
  CheckCircle, 
  AlertTriangle, 
  Clock, 
  Users, 
  Target, 
  MessageSquare, 
  Phone, 
  Mail, 
  Calendar,
  Star,
  TrendingUp,
  BarChart3,
  Download,
  Upload,
  RefreshCw,
  Eye,
  Edit,
  Trash2,
  Plus,
  Filter,
  Search
} from 'lucide-react';
import { useStore } from '../../store/useStore';
import { voiceAgentTemplates, getTemplatesByIndustry, VoiceAgentTemplate } from '../../data/voiceAgentTemplates';
import { toast } from 'react-hot-toast';

interface AgentConfiguration {
  id: string;
  name: string;
  description: string;
  industry: string;
  useCase: string;
  template: VoiceAgentTemplate | null;
  customizations: {
    scripts: Record<string, string>;
    intents: Array<{
      name: string;
      keywords: string[];
      confidence: number;
      response: string;
      actions: string[];
    }>;
    transferRules: Array<{
      condition: string;
      target: string;
      priority: number;
    }>;
    ghlIntegration: {
      customFields: Array<{
        key: string;
        label: string;
        type: string;
        required: boolean;
        options?: string[];
      }>;
      mergeTags: string[];
      workflows: string[];
    };
  };
  status: 'draft' | 'testing' | 'live' | 'paused';
  performance: {
    callsHandled: number;
    successRate: number;
    averageCallDuration: number;
    conversionRate: number;
  };
  createdAt: string;
  updatedAt: string;
}

const AdvancedVoiceAgentBuilder: React.FC = () => {
  const { darkMode } = useStore();
  const [selectedTemplate, setSelectedTemplate] = useState<VoiceAgentTemplate | null>(null);
  const [agentConfig, setAgentConfig] = useState<AgentConfiguration | null>(null);
  const [activeTab, setActiveTab] = useState<'templates' | 'configure' | 'test' | 'deploy'>('templates');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedIndustry, setSelectedIndustry] = useState<string>('all');
  const [isConfiguring, setIsConfiguring] = useState(false);

  const industries = ['all', 'fitness', 'martial_arts', 'legal', 'plumbing', 'towing', 'construction'];

  const filteredTemplates = voiceAgentTemplates.filter(template => {
    const matchesSearch = template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesIndustry = selectedIndustry === 'all' || template.industry === selectedIndustry;
    return matchesSearch && matchesIndustry;
  });

  const handleTemplateSelect = (template: VoiceAgentTemplate) => {
    setSelectedTemplate(template);
    setActiveTab('configure');
    setIsConfiguring(true);
    
    // Initialize agent configuration from template
    const newAgentConfig: AgentConfiguration = {
      id: `agent_${Date.now()}`,
      name: `${template.name} - Custom`,
      description: template.description,
      industry: template.industry,
      useCase: template.useCase,
      template: template,
      customizations: {
        scripts: { ...template.scripts },
        intents: template.intents.map(intent => ({
          name: intent.name,
          keywords: [...intent.keywords],
          confidence: intent.confidence,
          response: intent.response,
          actions: [...intent.actions]
        })),
        transferRules: template.transferRules.map(rule => ({
          condition: rule.condition,
          target: rule.target,
          priority: rule.priority
        })),
        ghlIntegration: {
          customFields: template.ghlIntegration.customFields.map(field => ({ ...field })),
          mergeTags: [...template.ghlIntegration.mergeTags],
          workflows: [...template.ghlIntegration.workflows]
        }
      },
      status: 'draft',
      performance: {
        callsHandled: 0,
        successRate: 0,
        averageCallDuration: 0,
        conversionRate: 0
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    setAgentConfig(newAgentConfig);
    toast.success(`Selected ${template.name} template`);
  };

  const handleSaveAgent = () => {
    if (!agentConfig) return;
    
    // Here you would save to your store/API
    console.log('Saving agent configuration:', agentConfig);
    toast.success('Agent configuration saved!');
  };

  const handleDeployAgent = () => {
    if (!agentConfig) return;
    
    // Here you would deploy the agent
    console.log('Deploying agent:', agentConfig);
    toast.success('Agent deployed successfully!');
    setAgentConfig({ ...agentConfig, status: 'live' });
  };

  const renderTemplateCard = (template: VoiceAgentTemplate) => (
    <div
      key={template.id}
      className="card p-6 hover:shadow-xl transition-all duration-300 cursor-pointer group"
      onClick={() => handleTemplateSelect(template)}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-blue-500/20 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
            <Bot className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors duration-200">
              {template.name}
            </h3>
            <p className="text-sm text-muted-foreground capitalize">
              {template.industry.replace('_', ' ')} • {template.useCase.replace('_', ' ')}
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
            template.automationLevel === 'enterprise' ? 'bg-green-100 text-green-800' :
            template.automationLevel === 'advanced' ? 'bg-blue-100 text-blue-800' :
            template.automationLevel === 'intermediate' ? 'bg-yellow-100 text-yellow-800' :
            'bg-gray-100 text-gray-800'
          }`}>
            {template.automationLevel}
          </span>
          <Clock className="w-4 h-4 text-muted-foreground" />
          <span className="text-sm text-muted-foreground">{template.estimatedSetupTime}</span>
        </div>
      </div>
      
      <p className="text-muted-foreground mb-4 line-clamp-2">
        {template.description}
      </p>
      
      <div className="space-y-3">
        <div>
          <h4 className="text-sm font-medium text-foreground mb-2">Key Features:</h4>
          <div className="flex flex-wrap gap-2">
            {template.features.slice(0, 3).map((feature, index) => (
              <span
                key={index}
                className="px-2 py-1 bg-secondary text-secondary-foreground rounded-md text-xs"
              >
                {feature}
              </span>
            ))}
            {template.features.length > 3 && (
              <span className="px-2 py-1 bg-muted text-muted-foreground rounded-md text-xs">
                +{template.features.length - 3} more
              </span>
            )}
          </div>
        </div>
        
        <div className="flex items-center justify-between pt-2">
          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
            <div className="flex items-center space-x-1">
              <MessageSquare className="w-4 h-4" />
              <span>{template.intents.length} intents</span>
            </div>
            <div className="flex items-center space-x-1">
              <Settings className="w-4 h-4" />
              <span>{template.ghlIntegration.customFields.length} fields</span>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Eye className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors duration-200" />
            <span className="text-sm text-primary group-hover:text-primary-foreground transition-colors duration-200">
              Use Template
            </span>
          </div>
        </div>
      </div>
    </div>
  );

  const renderConfigurationTab = () => {
    if (!agentConfig || !selectedTemplate) return null;

    return (
      <div className="space-y-6">
        {/* Agent Overview */}
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Agent Configuration</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-muted-foreground mb-2">
                Agent Name
              </label>
              <input
                type="text"
                className="w-full input"
                value={agentConfig.name}
                onChange={(e) => setAgentConfig({
                  ...agentConfig,
                  name: e.target.value,
                  updatedAt: new Date().toISOString()
                })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-muted-foreground mb-2">
                Industry
              </label>
              <select
                className="w-full input"
                value={agentConfig.industry}
                onChange={(e) => setAgentConfig({
                  ...agentConfig,
                  industry: e.target.value,
                  updatedAt: new Date().toISOString()
                })}
              >
                {industries.filter(i => i !== 'all').map(industry => (
                  <option key={industry} value={industry}>
                    {industry.replace('_', ' ').toUpperCase()}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Scripts Configuration */}
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Scripts</h2>
          <div className="space-y-4">
            {Object.entries(agentConfig.customizations.scripts).map(([key, script]) => (
              <div key={key}>
                <label className="block text-sm font-medium text-muted-foreground mb-2 capitalize">
                  {key.replace('_', ' ')} Script
                </label>
                <textarea
                  className="w-full input"
                  rows={4}
                  value={script}
                  onChange={(e) => setAgentConfig({
                    ...agentConfig,
                    customizations: {
                      ...agentConfig.customizations,
                      scripts: {
                        ...agentConfig.customizations.scripts,
                        [key]: e.target.value
                      }
                    },
                    updatedAt: new Date().toISOString()
                  })}
                />
              </div>
            ))}
          </div>
        </div>

        {/* Intents Configuration */}
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Intents & Responses</h2>
          <div className="space-y-4">
            {agentConfig.customizations.intents.map((intent, index) => (
              <div key={index} className="border border-border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-medium text-foreground">{intent.name}</h3>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-muted-foreground">
                      Confidence: {Math.round(intent.confidence * 100)}%
                    </span>
                    <button className="text-destructive hover:text-red-400">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-1">
                      Keywords
                    </label>
                    <input
                      type="text"
                      className="w-full input"
                      value={intent.keywords.join(', ')}
                      onChange={(e) => {
                        const newIntents = [...agentConfig.customizations.intents];
                        newIntents[index].keywords = e.target.value.split(',').map(k => k.trim());
                        setAgentConfig({
                          ...agentConfig,
                          customizations: {
                            ...agentConfig.customizations,
                            intents: newIntents
                          },
                          updatedAt: new Date().toISOString()
                        });
                      }}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-1">
                      Response
                    </label>
                    <textarea
                      className="w-full input"
                      rows={2}
                      value={intent.response}
                      onChange={(e) => {
                        const newIntents = [...agentConfig.customizations.intents];
                        newIntents[index].response = e.target.value;
                        setAgentConfig({
                          ...agentConfig,
                          customizations: {
                            ...agentConfig.customizations,
                            intents: newIntents
                          },
                          updatedAt: new Date().toISOString()
                        });
                      }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* GHL Integration */}
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">GoHighLevel Integration</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-medium text-foreground mb-2">Custom Fields</h3>
              <div className="space-y-2">
                {agentConfig.customizations.ghlIntegration.customFields.map((field, index) => (
                  <div key={index} className="flex items-center space-x-2 p-2 bg-secondary rounded">
                    <span className="text-sm font-medium text-foreground">{field.label}</span>
                    <span className="text-xs text-muted-foreground">({field.type})</span>
                    {field.required && (
                      <span className="text-xs bg-red-100 text-red-800 px-1 rounded">Required</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="font-medium text-foreground mb-2">Merge Tags</h3>
              <div className="flex flex-wrap gap-2">
                {agentConfig.customizations.ghlIntegration.mergeTags.map((tag, index) => (
                  <span
                    key={index}
                    className="px-2 py-1 bg-primary/20 text-primary rounded text-sm"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end space-x-4">
          <button
            onClick={() => setActiveTab('templates')}
            className="btn btn-outline"
          >
            Back to Templates
          </button>
          <button
            onClick={handleSaveAgent}
            className="btn btn-secondary"
          >
            <Save className="w-4 h-4 mr-2" />
            Save Configuration
          </button>
          <button
            onClick={() => setActiveTab('test')}
            className="btn btn-primary"
          >
            <Play className="w-4 h-4 mr-2" />
            Test Agent
          </button>
        </div>
      </div>
    );
  };

  const renderTestTab = () => {
    if (!agentConfig) return null;

    return (
      <div className="space-y-6">
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Agent Testing</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <h3 className="font-medium text-foreground mb-3">Test Scenarios</h3>
              <div className="space-y-2">
                {selectedTemplate?.deployment.testingScenarios.map((scenario, index) => (
                  <div key={index} className="flex items-center space-x-2 p-3 bg-secondary rounded">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    <span className="text-sm text-foreground">{scenario}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="font-medium text-foreground mb-3">Performance Metrics</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Calls Handled</span>
                  <span className="font-medium text-foreground">{agentConfig.performance.callsHandled}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Success Rate</span>
                  <span className="font-medium text-foreground">{agentConfig.performance.successRate}%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Avg Call Duration</span>
                  <span className="font-medium text-foreground">{agentConfig.performance.averageCallDuration}s</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Conversion Rate</span>
                  <span className="font-medium text-foreground">{agentConfig.performance.conversionRate}%</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end space-x-4">
          <button
            onClick={() => setActiveTab('configure')}
            className="btn btn-outline"
          >
            Back to Configuration
          </button>
          <button
            onClick={() => setActiveTab('deploy')}
            className="btn btn-primary"
          >
            <Zap className="w-4 h-4 mr-2" />
            Deploy Agent
          </button>
        </div>
      </div>
    );
  };

  const renderDeployTab = () => {
    if (!agentConfig || !selectedTemplate) return null;

    return (
      <div className="space-y-6">
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Deployment Readiness</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-medium text-foreground mb-3">Pre-deployment Checks</h3>
              <div className="space-y-2">
                {selectedTemplate.deployment.readinessChecks.map((check, index) => (
                  <div key={index} className="flex items-center space-x-2 p-3 bg-secondary rounded">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    <span className="text-sm text-foreground">{check}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Deployment Steps</h2>
          <div className="space-y-3">
            {selectedTemplate.deployment.goLiveSteps.map((step, index) => (
              <div key={index} className="flex items-start space-x-3">
                <div className="w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium">
                  {index + 1}
                </div>
                <span className="text-sm text-foreground pt-1">{step}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-end space-x-4">
          <button
            onClick={() => setActiveTab('test')}
            className="btn btn-outline"
          >
            Back to Testing
          </button>
          <button
            onClick={handleDeployAgent}
            className="btn btn-primary btn-lg"
          >
            <Zap className="w-5 h-5 mr-2" />
            Deploy Agent Now
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="p-6 bg-background min-h-screen text-foreground">
      <div className="mb-8">
        <h1 className="text-3xl font-bold gradient-text mb-2">Advanced Voice AI Agent Builder</h1>
        <p className="text-muted-foreground">
          Build intelligent voice AI agents with industry-specific templates and full automation
        </p>
      </div>

      {/* Tab Navigation */}
      <div className="mb-6">
        <div className="flex space-x-1 bg-secondary p-1 rounded-lg w-fit">
          {[
            { id: 'templates', label: 'Templates', icon: Bot },
            { id: 'configure', label: 'Configure', icon: Settings },
            { id: 'test', label: 'Test', icon: Play },
            { id: 'deploy', label: 'Deploy', icon: Zap }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-primary text-primary-foreground shadow-lg'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      {activeTab === 'templates' && (
        <div className="space-y-6">
          {/* Search and Filters */}
          <div className="card p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <input
                    type="text"
                    placeholder="Search templates..."
                    className="w-full pl-10 input"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
              <div className="flex space-x-2">
                <select
                  className="input"
                  value={selectedIndustry}
                  onChange={(e) => setSelectedIndustry(e.target.value)}
                >
                  <option value="all">All Industries</option>
                  {industries.filter(i => i !== 'all').map(industry => (
                    <option key={industry} value={industry}>
                      {industry.replace('_', ' ').toUpperCase()}
                    </option>
                  ))}
                </select>
                <button className="btn btn-outline">
                  <Filter className="w-4 h-4 mr-2" />
                  Filter
                </button>
              </div>
            </div>
          </div>

          {/* Templates Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTemplates.map(renderTemplateCard)}
          </div>
        </div>
      )}

      {activeTab === 'configure' && renderConfigurationTab()}
      {activeTab === 'test' && renderTestTab()}
      {activeTab === 'deploy' && renderDeployTab()}
    </div>
  );
};

export default AdvancedVoiceAgentBuilder;
