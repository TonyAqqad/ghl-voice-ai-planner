import React, { useState, useEffect } from 'react';
import { 
  Download, 
  Upload, 
  Plus, 
  Trash2, 
  Eye, 
  FileText,
  Package,
  Bot,
  Workflow,
  Database,
  TestTube,
  BarChart3,
  Settings,
  CheckCircle,
  Clock,
  AlertTriangle,
  XCircle
} from 'lucide-react';

interface ExportBundle {
  id: string;
  name: string;
  description: string;
  status: 'ready' | 'processing' | 'error' | 'pending';
  createdAt: Date;
  size: string;
  items: string[];
  type: 'complete' | 'agent' | 'workflow' | 'documentation' | 'test' | 'custom';
}

interface ExportItem {
  id: string;
  name: string;
  type: 'agent' | 'workflow' | 'field' | 'test' | 'report' | 'documentation';
  status: 'ready' | 'processing' | 'error';
  size?: string;
  description?: string;
}

const ExportCenter: React.FC = () => {
  const [bundles, setBundles] = useState<ExportBundle[]>([]);
  const [activeTab, setActiveTab] = useState<'bundles' | 'configurations' | 'reports' | 'templates'>('bundles');
  const [logs, setLogs] = useState<Array<{ type: string; message: string; timestamp: string }>>([
    { type: 'info', message: 'Export Center initialized. Ready for bundle creation.', timestamp: new Date().toLocaleTimeString() }
  ]);

  const defaultBundles: ExportBundle[] = [
    {
      id: '1',
      name: 'Complete Voice AI Bundle',
      description: 'Full configuration including agents, workflows, and documentation',
      status: 'ready',
      createdAt: new Date(),
      size: '2.4 MB',
      items: ['Voice Agents', 'Workflows', 'Custom Fields', 'Test Cases', 'Documentation'],
      type: 'complete'
    },
    {
      id: '2',
      name: 'Sales Agent Bundle',
      description: 'Lead qualification and sales automation configuration',
      status: 'ready',
      createdAt: new Date(),
      size: '1.2 MB',
      items: ['Sales Agent', 'Lead Qualification Workflow', 'Custom Fields'],
      type: 'agent'
    },
    {
      id: '3',
      name: 'Support Agent Bundle',
      description: 'Customer support and ticket management configuration',
      status: 'processing',
      createdAt: new Date(),
      size: '0.8 MB',
      items: ['Support Agent', 'Ticket Workflow', 'Knowledge Base'],
      type: 'agent'
    }
  ];

  const voiceAgents: ExportItem[] = [
    { id: '1', name: 'Sales Assistant', type: 'agent', status: 'ready', size: '512 KB', description: 'Lead qualification agent' },
    { id: '2', name: 'Support Agent', type: 'agent', status: 'ready', size: '384 KB', description: 'Customer support agent' },
    { id: '3', name: 'Booking Agent', type: 'agent', status: 'processing', size: '256 KB', description: 'Appointment scheduling agent' }
  ];

  const workflows: ExportItem[] = [
    { id: '1', name: 'Lead Qualification Flow', type: 'workflow', status: 'ready', size: '128 KB', description: 'Automated lead processing' },
    { id: '2', name: 'Follow-up Sequence', type: 'workflow', status: 'ready', size: '96 KB', description: 'Automated follow-up workflow' }
  ];

  const reports: ExportItem[] = [
    { id: '1', name: 'QA Test Report - 2024-01-15', type: 'report', status: 'ready', size: '1.2 MB', description: 'Comprehensive test results and analytics' },
    { id: '2', name: 'Performance Analytics', type: 'report', status: 'ready', size: '856 KB', description: 'Agent performance metrics and insights' },
    { id: '3', name: 'Deployment Guide', type: 'documentation', status: 'ready', size: '2.1 MB', description: 'Step-by-step deployment instructions' },
    { id: '4', name: 'Configuration Reference', type: 'documentation', status: 'ready', size: '1.8 MB', description: 'Complete configuration documentation' }
  ];

  const templates = [
    { name: 'Complete Bundle Template', description: 'Export everything: agents, workflows, configurations, and documentation', type: 'complete' },
    { name: 'Agent Only Template', description: 'Export only voice AI agent configurations', type: 'agent' },
    { name: 'Workflow Only Template', description: 'Export only workflow configurations and logic', type: 'workflow' },
    { name: 'Documentation Template', description: 'Export implementation guides and documentation', type: 'documentation' },
    { name: 'Test Suite Template', description: 'Export test cases and QA configurations', type: 'test' },
    { name: 'Custom Template', description: 'Create your own export template', type: 'custom' }
  ];

  useEffect(() => {
    loadBundles();
  }, []);

  const loadBundles = () => {
    const saved = localStorage.getItem('ghl-export-bundles');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setBundles(parsed.map((b: any) => ({
          ...b,
          createdAt: new Date(b.createdAt)
        })));
      } catch (error) {
        console.error('Failed to load bundles:', error);
        setBundles(defaultBundles);
      }
    } else {
      setBundles(defaultBundles);
    }
  };

  const saveBundles = (newBundles: ExportBundle[]) => {
    localStorage.setItem('ghl-export-bundles', JSON.stringify(newBundles));
    setBundles(newBundles);
  };

  const addLog = (type: string, message: string) => {
    const newLog = {
      type,
      message,
      timestamp: new Date().toLocaleTimeString()
    };
    setLogs(prev => [...prev, newLog]);
  };

  const createBundle = () => {
    const name = prompt('Enter bundle name:');
    if (name) {
      const bundle: ExportBundle = {
        id: Date.now().toString(),
        name,
        description: 'Custom export bundle',
        status: 'processing',
        createdAt: new Date(),
        size: '0 MB',
        items: [],
        type: 'custom'
      };
      
      const newBundles = [bundle, ...bundles];
      saveBundles(newBundles);
      addLog('info', `Created bundle: ${name}`);
      
      // Simulate processing
      setTimeout(() => {
        bundle.status = 'ready';
        bundle.size = '1.5 MB';
        bundle.items = ['Voice Agent', 'Workflow', 'Custom Fields'];
        saveBundles([...newBundles]);
        addLog('success', `Bundle ready: ${name}`);
      }, 3000);
    }
  };

  const downloadBundle = (bundleId: string) => {
    const bundle = bundles.find(b => b.id === bundleId);
    if (bundle) {
      const exportData = {
        bundle,
        timestamp: new Date().toISOString(),
        version: '1.0.0',
        contents: generateBundleContents(bundle)
      };
      
      const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${bundle.name.replace(/\s+/g, '_')}_bundle.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      addLog('success', `Downloaded bundle: ${bundle.name}`);
    }
  };

  const previewBundle = (bundleId: string) => {
    const bundle = bundles.find(b => b.id === bundleId);
    if (bundle) {
      const contents = generateBundleContents(bundle);
      const preview = JSON.stringify(contents, null, 2);
      
      // Create a modal for preview
      const modal = document.createElement('div');
      modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
      modal.innerHTML = `
        <div class="bg-card p-6 rounded-lg max-w-4xl max-h-96 overflow-y-auto">
          <h3 class="text-xl font-semibold text-foreground mb-4">Bundle Preview: ${bundle.name}</h3>
          <p class="text-sm text-muted-foreground mb-4">${bundle.description}</p>
          <div class="mb-4">
            <h4 class="font-medium text-foreground mb-2">Bundle Contents:</h4>
            <div class="space-y-1">
              ${bundle.items.map(item => `<div class="text-sm text-muted-foreground">• ${item}</div>`).join('')}
            </div>
          </div>
          <div class="mb-4">
            <h4 class="font-medium text-foreground mb-2">JSON Preview:</h4>
            <pre class="bg-muted p-4 rounded text-xs overflow-x-auto">${preview}</pre>
          </div>
          <div class="flex justify-end">
            <button class="btn btn-outline" onclick="this.closest('.fixed').remove()">Close</button>
          </div>
        </div>
      `;
      document.body.appendChild(modal);
    }
  };

  const deleteBundle = (bundleId: string) => {
    if (confirm('Are you sure you want to delete this bundle?')) {
      const newBundles = bundles.filter(b => b.id !== bundleId);
      saveBundles(newBundles);
      addLog('warning', 'Bundle deleted');
    }
  };

  const generateBundleContents = (bundle: ExportBundle) => {
    return {
      metadata: {
        name: bundle.name,
        description: bundle.description,
        version: '1.0.0',
        createdAt: bundle.createdAt.toISOString(),
        size: bundle.size,
        type: bundle.type
      },
      voiceAgents: [
        {
          id: 'agent-1',
          name: 'Sales Assistant',
          description: 'Lead qualification and sales automation',
          voiceProvider: 'elevenlabs',
          llmProvider: 'openai',
          phoneNumber: '+1234567890',
          status: 'active'
        }
      ],
      workflows: [
        {
          id: 'workflow-1',
          name: 'Lead Qualification',
          description: 'Automated lead processing workflow',
          triggers: ['voice_call_received'],
          actions: ['update_contact', 'create_task', 'send_email'],
          status: 'active'
        }
      ],
      customFields: [
        {
          id: 'field-1',
          name: 'Lead Score',
          type: 'number',
          object: 'contact',
          required: false
        }
      ],
      testCases: [
        {
          id: 'test-1',
          name: 'Basic Greeting',
          description: 'Test agent responds to basic greeting',
          status: 'pass'
        }
      ],
      documentation: {
        deploymentGuide: 'Step-by-step deployment instructions...',
        configurationReference: 'Complete configuration documentation...',
        troubleshootingGuide: 'Common issues and solutions...'
      }
    };
  };

  const exportAll = () => {
    addLog('info', 'Starting export of all configurations...');
    
    const allData = {
      timestamp: new Date().toISOString(),
      version: '1.0.0',
      bundles,
      voiceAgents,
      workflows,
      reports
    };
    
    const blob = new Blob([JSON.stringify(allData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ghl_voice_ai_complete_export_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    addLog('success', 'Complete export downloaded');
  };

  const importBundle = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          try {
            const data = JSON.parse(e.target?.result as string);
            addLog('success', `Imported bundle: ${data.bundle?.name || 'Unknown'}`);
          } catch (error) {
            addLog('error', 'Failed to import bundle: Invalid file format');
          }
        };
        reader.readAsText(file);
      }
    };
    input.click();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ready': return 'text-green-400';
      case 'processing': return 'text-blue-400';
      case 'error': return 'text-red-400';
      case 'pending': return 'text-yellow-400';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'ready': return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'processing': return <Clock className="w-4 h-4 text-blue-400 animate-pulse" />;
      case 'error': return <XCircle className="w-4 h-4 text-red-400" />;
      case 'pending': return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
      default: return <Clock className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const getLogColor = (type: string) => {
    switch (type) {
      case 'error': return 'text-red-400';
      case 'warning': return 'text-yellow-400';
      case 'success': return 'text-green-400';
      case 'info': return 'text-blue-400';
      default: return 'text-muted-foreground';
    }
  };

  const getItemIcon = (type: string) => {
    switch (type) {
      case 'agent': return '🤖';
      case 'workflow': return '⚡';
      case 'field': return '📊';
      case 'test': return '🧪';
      case 'report': return '📈';
      case 'documentation': return '📋';
      default: return '📄';
    }
  };

  const clearLogs = () => {
    setLogs([{ type: 'info', message: 'Logs cleared.', timestamp: new Date().toLocaleTimeString() }]);
  };

  const stats = {
    total: bundles.length,
    ready: bundles.filter(b => b.status === 'ready').length,
    processing: bundles.filter(b => b.status === 'processing').length,
    error: bundles.filter(b => b.status === 'error').length
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground gradient-text">Export Center</h1>
          <p className="text-muted-foreground mt-2">Export configurations, reports, and implementation guides for your voice AI agents</p>
        </div>
        <div className="flex gap-2">
          <button onClick={createBundle} className="btn btn-primary flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Create Bundle
          </button>
          <button onClick={exportAll} className="btn btn-outline flex items-center gap-2">
            <Download className="w-4 h-4" />
            Export All
          </button>
          <button onClick={importBundle} className="btn btn-outline flex items-center gap-2">
            <Upload className="w-4 h-4" />
            Import Bundle
          </button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="card p-6 text-center">
          <div className="text-3xl font-bold gradient-text mb-2">{stats.total}</div>
          <div className="text-sm text-muted-foreground">Total Exports</div>
        </div>
        <div className="card p-6 text-center">
          <div className="text-3xl font-bold text-green-400 mb-2">{stats.ready}</div>
          <div className="text-sm text-muted-foreground">Ready</div>
        </div>
        <div className="card p-6 text-center">
          <div className="text-3xl font-bold text-blue-400 mb-2">{stats.processing}</div>
          <div className="text-sm text-muted-foreground">Processing</div>
        </div>
        <div className="card p-6 text-center">
          <div className="text-3xl font-bold text-red-400 mb-2">{stats.error}</div>
          <div className="text-sm text-muted-foreground">Errors</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-border">
        {[
          { id: 'bundles', label: 'Export Bundles', icon: Package },
          { id: 'configurations', label: 'Configurations', icon: Settings },
          { id: 'reports', label: 'Reports', icon: BarChart3 },
          { id: 'templates', label: 'Templates', icon: FileText }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-2 px-4 py-2 border-b-2 transition-colors ${
              activeTab === tab.id
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'bundles' && (
        <div className="space-y-4">
          <div className="card p-6">
            <h3 className="text-xl font-semibold text-foreground mb-4">Export Bundles</h3>
            <div className="space-y-4">
              {bundles.map((bundle) => (
                <div key={bundle.id} className={`export-item p-4 rounded-lg border ${
                  bundle.status === 'ready' ? 'border-green-400 bg-green-400/10' :
                  bundle.status === 'processing' ? 'border-blue-400 bg-blue-400/10' :
                  bundle.status === 'error' ? 'border-red-400 bg-red-400/10' :
                  'border-border'
                }`}>
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        {getStatusIcon(bundle.status)}
                        <h4 className="font-medium text-foreground">{bundle.name}</h4>
                        <span className={`text-sm font-medium ${getStatusColor(bundle.status)}`}>
                          {bundle.status.toUpperCase()}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">{bundle.description}</p>
                      <div className="flex items-center gap-4 text-xs">
                        <span className="px-2 py-1 rounded bg-muted">{bundle.size}</span>
                        <span className="text-muted-foreground">{bundle.items.length} items</span>
                        <span className="text-muted-foreground">{bundle.type}</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => downloadBundle(bundle.id)}
                        className="btn btn-primary btn-sm flex items-center gap-1"
                      >
                        <Download className="w-3 h-3" />
                        Download
                      </button>
                      <button 
                        onClick={() => previewBundle(bundle.id)}
                        className="btn btn-outline btn-sm flex items-center gap-1"
                      >
                        <Eye className="w-3 h-3" />
                        Preview
                      </button>
                      <button 
                        onClick={() => deleteBundle(bundle.id)}
                        className="btn btn-destructive btn-sm flex items-center gap-1"
                      >
                        <Trash2 className="w-3 h-3" />
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'configurations' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="card p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Voice AI Agents</h3>
            <div className="space-y-3">
              {voiceAgents.map((agent) => (
                <div key={agent.id} className={`export-item p-3 rounded-lg border ${
                  agent.status === 'ready' ? 'border-green-400 bg-green-400/10' :
                  agent.status === 'processing' ? 'border-blue-400 bg-blue-400/10' :
                  'border-border'
                }`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <span className="text-lg mr-2">{getItemIcon(agent.type)}</span>
                      <div>
                        <h4 className="font-medium text-foreground">{agent.name}</h4>
                        <p className="text-sm text-muted-foreground">{agent.description}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button className="btn btn-outline btn-sm">Export JSON</button>
                      <button className="btn btn-outline btn-sm">Export YAML</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="card p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Workflows</h3>
            <div className="space-y-3">
              {workflows.map((workflow) => (
                <div key={workflow.id} className={`export-item p-3 rounded-lg border ${
                  workflow.status === 'ready' ? 'border-green-400 bg-green-400/10' :
                  'border-border'
                }`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <span className="text-lg mr-2">{getItemIcon(workflow.type)}</span>
                      <div>
                        <h4 className="font-medium text-foreground">{workflow.name}</h4>
                        <p className="text-sm text-muted-foreground">{workflow.description}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button className="btn btn-outline btn-sm">Export JSON</button>
                      <button className="btn btn-outline btn-sm">Export CSV</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'reports' && (
        <div className="space-y-6">
          <div className="card p-6">
            <h3 className="text-xl font-semibold text-foreground mb-4">Test Reports</h3>
            <div className="space-y-3">
              {reports.map((report) => (
                <div key={report.id} className={`export-item p-3 rounded-lg border ${
                  report.status === 'ready' ? 'border-green-400 bg-green-400/10' :
                  'border-border'
                }`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <span className="text-lg mr-2">{getItemIcon(report.type)}</span>
                      <div>
                        <h4 className="font-medium text-foreground">{report.name}</h4>
                        <p className="text-sm text-muted-foreground">{report.description}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button className="btn btn-outline btn-sm">Export PDF</button>
                      <button className="btn btn-outline btn-sm">Export Excel</button>
                      <button className="btn btn-outline btn-sm">Export JSON</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'templates' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {templates.map((template, index) => (
            <div key={index} className="card p-6">
              <h3 className="text-lg font-semibold text-foreground mb-2">{template.name}</h3>
              <p className="text-sm text-muted-foreground mb-4">{template.description}</p>
              <div className="flex gap-2">
                <button className="btn btn-primary btn-sm">Use Template</button>
                <button className="btn btn-outline btn-sm">Preview</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Export Logs */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold text-foreground">Export Logs</h3>
          <button onClick={clearLogs} className="btn btn-outline flex items-center gap-2">
            <Trash2 className="w-4 h-4" />
            Clear Logs
          </button>
        </div>
        <div className="bg-muted p-4 rounded-md h-64 overflow-y-auto font-mono text-sm">
          {logs.map((log, index) => (
            <div key={index} className={`py-1 ${getLogColor(log.type)}`}>
              [{log.timestamp}] {log.message}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ExportCenter;