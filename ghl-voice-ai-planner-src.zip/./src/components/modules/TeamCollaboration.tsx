import React, { useState, useEffect } from 'react';
import {
  Users,
  UserPlus,
  Settings,
  MessageSquare,
  Bell,
  Search,
  Filter,
  MoreHorizontal,
  Edit,
  Trash2,
  Save,
  Plus,
  Minus,
  ChevronDown,
  ChevronRight,
  Eye,
  EyeOff,
  Star,
  ThumbsUp,
  ThumbsDown,
  Heart,
  Smile,
  Frown,
  Meh,
  Award,
  Trophy,
  Medal,
  Crown,
  Flame,
  Lightning,
  Rocket,
  Shield,
  Lock,
  Unlock,
  Key,
  Wrench,
  Cog,
  Sliders,
  ToggleLeft,
  ToggleRight,
  Switch,
  Power,
  PowerOff,
  Battery,
  BatteryCharging,
  Wifi,
  WifiOff,
  Signal,
  Mic,
  Headphones,
  Volume2,
  VolumeX,
  SkipForward,
  SkipBack,
  RotateCcw,
  BarChart3,
  LineChart,
  PieChart,
  Activity,
  Clock,
  Phone,
  Bot,
  Brain,
  Target,
  TrendingUp,
  TrendingDown,
  Database,
  Server,
  Globe,
  FileText,
  FileCheck,
  FileX,
  FileAlert,
  FileLock,
  FileShield,
  FileSearch,
  FileCode,
  FileImage,
  FileVideo,
  FileAudio,
  FileArchive,
  FileSpreadsheet,
  FilePresentation,
  FilePdf,
  FileWord,
  FileExcel,
  FilePowerpoint,
  FileZip,
  FileJson,
  FileXml,
  FileCsv,
  FileHtml,
  FileCss,
  FileJs,
  FileTs,
  FileJsx,
  FileTsx,
  FileVue,
  FileSvelte,
  FileAngular,
  FileReact,
  FileNode,
  FilePython,
  FileJava,
  FileC,
  FileCpp,
  FileCsharp,
  FilePhp,
  FileRuby,
  FileGo,
  FileRust,
  FileSwift,
  FileKotlin,
  FileDart,
  FileScala,
  FileClojure,
  FileHaskell,
  FileElixir,
  FileErlang,
  FileLua,
  FilePerl,
  FileR,
  FileMatlab,
  FileOctave,
  FileJulia,
  FileNim,
  FileCrystal,
  FileZig,
  FileOcaml,
  FileFsharp,
  FileD,
  FileNimrod,
  FilePascal,
  FileDelphi,
  FileFortran,
  FileCobol,
  FileAda,
  FileAssembly,
  FileBash,
  FilePowershell,
  FileBatch,
  FileDocker,
  FileKubernetes,
  FileTerraform,
  FileAnsible,
  FileChef,
  FilePuppet,
  FileVagrant,
  FileJenkins,
  FileTravis,
  FileCircleci,
  FileGitlab,
  FileGithub,
  FileBitbucket,
  FileGit,
  FileGitCommit,
  FileGitBranch,
  FileGitMerge,
  FileGitPullRequest,
  FileGitCompare,
  FileGitCherryPick,
  FileGitRebase,
  FileGitReset,
  FileGitRevert,
  FileGitStash,
  FileGitTag,
  FileGitLog,
  FileGitDiff,
  FileGitPatch,
  FileGitBlame,
  FileGitHistory,
  FileGitGraph,
  FileGitTree,
  FileGitSubmodule,
  FileGitLfs,
  FileGitHooks,
  FileGitAttributes,
  FileGitIgnore,
  FileGitConfig,
  FileGitModules,
  FileGitCredentials,
  FileGitSsh,
  FileGitHttps,
  FileGitProtocol,
  FileGitTransport,
  FileGitPack,
  FileGitIndex,
  FileGitObjects,
  FileGitRefs,
  FileGitHeads,
  FileGitTags,
  FileGitRemotes,
  FileGitOrigin,
  FileGitUpstream,
  FileGitFork,
  FileGitClone,
  FileGitFetch,
  FileGitPull,
  FileGitPush,
  FileGitRemote,
  FileGitAdd,
  FileGitCommitMessage,
  FileGitCommitAmend,
  FileGitCommitSquash,
  FileGitCommitFixup,
  FileGitCommitReword,
  FileGitCommitEdit,
  FileGitCommitDrop,
  FileGitCommitPick,
  FileGitCommitResolve,
  FileGitCommitContinue,
  FileGitCommitAbort,
  FileGitCommitSkip,
  FileGitCommitQuit,
  FileGitCommitBreak,
  FileGitCommitExec,
  FileGitCommitLabel,
  FileGitCommitReset,
  FileGitCommitMerge,
  FileGitCommitNoop,
  FileGitCommitStart,
  FileGitCommitEnd,
  FileGitCommitEmpty,
  FileGitCommitInitial,
  FileGitCommitRoot,
  FileGitCommitDetached,
  FileGitCommitOrphan,
  FileGitCommitUnborn,
  FileGitCommitHead,
  FileGitCommitMaster,
  FileGitCommitMain,
  FileGitCommitDevelop,
  FileGitCommitFeature,
  FileGitCommitBugfix,
  FileGitCommitHotfix,
  FileGitCommitRelease,
  FileGitCommitSupport,
  FileGitCommitVersion,
  FileGitCommitStable,
  FileGitCommitBeta,
  FileGitCommitAlpha,
  FileGitCommitDev,
  FileGitCommitTest,
  FileGitCommitStaging,
  FileGitCommitProduction,
  FileGitCommitLive,
  FileGitCommitProd
} from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';

interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: string;
  avatar?: string;
  status: 'online' | 'offline' | 'away' | 'busy';
  lastActive: string;
  permissions: string[];
}

interface Project {
  id: string;
  name: string;
  description: string;
  status: 'active' | 'completed' | 'paused' | 'archived';
  members: string[];
  createdAt: string;
  updatedAt: string;
}

interface Message {
  id: string;
  senderId: string;
  content: string;
  timestamp: string;
  type: 'text' | 'file' | 'image' | 'voice';
  projectId?: string;
}

const TeamCollaboration: React.FC = () => {
  const { } = useStore();
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [selectedProject, setSelectedProject] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<string>('all');

  // Sample data
  useEffect(() => {
    const sampleMembers: TeamMember[] = [
      {
        id: '1',
        name: 'John Smith',
        email: 'john@company.com',
        role: 'Lead Developer',
        status: 'online',
        lastActive: '2024-01-15T10:30:00Z',
        permissions: ['admin', 'edit', 'view']
      },
      {
        id: '2',
        name: 'Sarah Johnson',
        email: 'sarah@company.com',
        role: 'Voice AI Specialist',
        status: 'away',
        lastActive: '2024-01-15T09:45:00Z',
        permissions: ['edit', 'view']
      },
      {
        id: '3',
        name: 'Mike Chen',
        email: 'mike@company.com',
        role: 'Compliance Officer',
        status: 'busy',
        lastActive: '2024-01-15T11:15:00Z',
        permissions: ['view']
      }
    ];

    const sampleProjects: Project[] = [
      {
        id: '1',
        name: 'Solar Appointment Agent',
        description: 'Voice AI agent for solar lead appointment booking',
        status: 'active',
        members: ['1', '2'],
        createdAt: '2024-01-10T08:00:00Z',
        updatedAt: '2024-01-15T10:30:00Z'
      },
      {
        id: '2',
        name: 'Fitness Studio Automation',
        description: 'Automated booking system for F45 Training',
        status: 'active',
        members: ['1', '2', '3'],
        createdAt: '2024-01-12T14:00:00Z',
        updatedAt: '2024-01-15T09:45:00Z'
      }
    ];

    const sampleMessages: Message[] = [
      {
        id: '1',
        senderId: '1',
        content: 'The solar appointment agent is ready for testing',
        timestamp: '2024-01-15T10:30:00Z',
        type: 'text',
        projectId: '1'
      },
      {
        id: '2',
        senderId: '2',
        content: 'Great! I\'ll run the compliance checks now',
        timestamp: '2024-01-15T10:32:00Z',
        type: 'text',
        projectId: '1'
      }
    ];

    setMembers(sampleMembers);
    setProjects(sampleProjects);
    setMessages(sampleMessages);
  }, []);

  const filteredMembers = members.filter(member => {
    const matchesSearch = member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         member.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filter === 'all' || member.status === filter;
    return matchesSearch && matchesFilter;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'away': return 'bg-yellow-500';
      case 'busy': return 'bg-red-500';
      case 'offline': return 'bg-gray-400';
      default: return 'bg-gray-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'online': return <div className="w-2 h-2 bg-green-500 rounded-full"></div>;
      case 'away': return <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>;
      case 'busy': return <div className="w-2 h-2 bg-red-500 rounded-full"></div>;
      case 'offline': return <div className="w-2 h-2 bg-gray-400 rounded-full"></div>;
      default: return <div className="w-2 h-2 bg-gray-400 rounded-full"></div>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <Users className="w-8 h-8 text-blue-600" />
                Team Collaboration
              </h1>
              <p className="text-gray-600 mt-2">
                Real-time collaboration and project management for voice AI development
              </p>
            </div>
            <div className="flex gap-3">
              <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <UserPlus className="w-4 h-4" />
                Invite Member
              </button>
              <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50">
                <Settings className="w-4 h-4" />
                Settings
              </button>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Team Members</p>
                <p className="text-2xl font-bold text-gray-900">{members.length}</p>
              </div>
              <Users className="w-8 h-8 text-blue-600" />
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Projects</p>
                <p className="text-2xl font-bold text-green-600">
                  {projects.filter(p => p.status === 'active').length}
                </p>
              </div>
              <Rocket className="w-8 h-8 text-green-600" />
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Online Now</p>
                <p className="text-2xl font-bold text-blue-600">
                  {members.filter(m => m.status === 'online').length}
                </p>
              </div>
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Messages Today</p>
                <p className="text-2xl font-bold text-purple-600">{messages.length}</p>
              </div>
              <MessageSquare className="w-8 h-8 text-purple-600" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Team Members */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm border">
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-semibold text-gray-900">Team Members</h2>
                  <div className="flex gap-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <input
                        type="text"
                        placeholder="Search members..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <select
                      value={filter}
                      onChange={(e) => setFilter(e.target.value)}
                      className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="all">All Status</option>
                      <option value="online">Online</option>
                      <option value="away">Away</option>
                      <option value="busy">Busy</option>
                      <option value="offline">Offline</option>
                    </select>
                  </div>
                </div>
              </div>
              <div className="divide-y divide-gray-200">
                {filteredMembers.map((member) => (
                  <div key={member.id} className="p-6 hover:bg-gray-50">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="relative">
                          <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
                            <span className="text-lg font-medium text-gray-600">
                              {member.name.split(' ').map(n => n[0]).join('')}
                            </span>
                          </div>
                          <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${getStatusColor(member.status)}`}></div>
                        </div>
                        <div>
                          <h3 className="text-lg font-medium text-gray-900">{member.name}</h3>
                          <p className="text-gray-600">{member.email}</p>
                          <p className="text-sm text-gray-500">{member.role}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-gray-500">
                          Last active: {new Date(member.lastActive).toLocaleString()}
                        </span>
                        <button className="p-2 text-gray-400 hover:text-gray-600">
                          <MoreHorizontal className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Projects */}
          <div>
            <div className="bg-white rounded-lg shadow-sm border">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-900">Active Projects</h2>
              </div>
              <div className="divide-y divide-gray-200">
                {projects.filter(p => p.status === 'active').map((project) => (
                  <div key={project.id} className="p-6 hover:bg-gray-50 cursor-pointer">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="text-lg font-medium text-gray-900">{project.name}</h3>
                        <p className="text-gray-600 text-sm mt-1">{project.description}</p>
                        <div className="flex items-center gap-4 mt-3 text-sm text-gray-500">
                          <span>{project.members.length} members</span>
                          <span>Updated {new Date(project.updatedAt).toLocaleDateString()}</span>
                        </div>
                      </div>
                      <button className="p-2 text-gray-400 hover:text-gray-600">
                        <MoreHorizontal className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Recent Messages */}
        <div className="mt-8 bg-white rounded-lg shadow-sm border">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Recent Messages</h2>
          </div>
          <div className="divide-y divide-gray-200">
            {messages.map((message) => {
              const sender = members.find(m => m.id === message.senderId);
              return (
                <div key={message.id} className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                      <span className="text-sm font-medium text-gray-600">
                        {sender?.name.split(' ').map(n => n[0]).join('') || 'U'}
                      </span>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-gray-900">{sender?.name || 'Unknown'}</span>
                        <span className="text-sm text-gray-500">
                          {new Date(message.timestamp).toLocaleString()}
                        </span>
                      </div>
                      <p className="text-gray-700">{message.content}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TeamCollaboration;