import React, { useState, useEffect } from 'react';
import {
  Webhook,
  Settings,
  Plus,
  Edit,
  Trash2,
  Play,
  Pause,
  RefreshCw,
  Download,
  Upload,
  Save,
  Eye,
  EyeOff,
  Filter,
  Search,
  SortAsc,
  SortDesc,
  MoreHorizontal,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Clock,
  Activity,
  BarChart3,
  Database,
  Server,
  Globe,
  Shield,
  Lock,
  Unlock,
  Key,
  Wrench,
  Cog,
  Sliders,
  ToggleLeft,
  ToggleRight,
  Switch,
  Power,
  PowerOff,
  Battery,
  BatteryCharging,
  Wifi,
  WifiOff,
  Signal,
  MessageSquare,
  Mic,
  Headphones,
  Volume2,
  VolumeX,
  SkipForward,
  SkipBack,
  RotateCcw,
  LineChart,
  PieChart,
  Users,
  Phone,
  Bot,
  Brain,
  Target,
  TrendingUp,
  TrendingDown,
  FileText,
  FileCheck,
  FileX,
  FileAlert,
  FileLock,
  FileShield,
  FileSearch,
  FileCode,
  FileImage,
  FileVideo,
  FileAudio,
  FileArchive,
  FileSpreadsheet,
  FilePresentation,
  FilePdf,
  FileWord,
  FileExcel,
  FilePowerpoint,
  FileZip,
  FileJson,
  FileXml,
  FileCsv,
  FileHtml,
  FileCss,
  FileJs,
  FileTs,
  FileJsx,
  FileTsx,
  FileVue,
  FileSvelte,
  FileAngular,
  FileReact,
  FileNode,
  FilePython,
  FileJava,
  FileC,
  FileCpp,
  FileCsharp,
  FilePhp,
  FileRuby,
  FileGo,
  FileRust,
  FileSwift,
  FileKotlin,
  FileDart,
  FileScala,
  FileClojure,
  FileHaskell,
  FileElixir,
  FileErlang,
  FileLua,
  FilePerl,
  FileR,
  FileMatlab,
  FileOctave,
  FileJulia,
  FileNim,
  FileCrystal,
  FileZig,
  FileOcaml,
  FileFsharp,
  FileD,
  FileNimrod,
  FilePascal,
  FileDelphi,
  FileFortran,
  FileCobol,
  FileAda,
  FileAssembly,
  FileBash,
  FilePowershell,
  FileBatch,
  FileDocker,
  FileKubernetes,
  FileTerraform,
  FileAnsible,
  FileChef,
  FilePuppet,
  FileVagrant,
  FileJenkins,
  FileTravis,
  FileCircleci,
  FileGitlab,
  FileGithub,
  FileBitbucket,
  FileGit,
  FileGitCommit,
  FileGitBranch,
  FileGitMerge,
  FileGitPullRequest,
  FileGitCompare,
  FileGitCherryPick,
  FileGitRebase,
  FileGitReset,
  FileGitRevert,
  FileGitStash,
  FileGitTag,
  FileGitLog,
  FileGitDiff,
  FileGitPatch,
  FileGitBlame,
  FileGitHistory,
  FileGitGraph,
  FileGitTree,
  FileGitSubmodule,
  FileGitLfs,
  FileGitHooks,
  FileGitAttributes,
  FileGitIgnore,
  FileGitConfig,
  FileGitModules,
  FileGitCredentials,
  FileGitSsh,
  FileGitHttps,
  FileGitProtocol,
  FileGitTransport,
  FileGitPack,
  FileGitIndex,
  FileGitObjects,
  FileGitRefs,
  FileGitHeads,
  FileGitTags,
  FileGitRemotes,
  FileGitOrigin,
  FileGitUpstream,
  FileGitFork,
  FileGitClone,
  FileGitFetch,
  FileGitPull,
  FileGitPush,
  FileGitRemote,
  FileGitAdd,
  FileGitCommitMessage,
  FileGitCommitAmend,
  FileGitCommitSquash,
  FileGitCommitFixup,
  FileGitCommitReword,
  FileGitCommitEdit,
  FileGitCommitDrop,
  FileGitCommitPick,
  FileGitCommitResolve,
  FileGitCommitContinue,
  FileGitCommitAbort,
  FileGitCommitSkip,
  FileGitCommitQuit,
  FileGitCommitBreak,
  FileGitCommitExec,
  FileGitCommitLabel,
  FileGitCommitReset,
  FileGitCommitMerge,
  FileGitCommitNoop,
  FileGitCommitStart,
  FileGitCommitEnd,
  FileGitCommitEmpty,
  FileGitCommitInitial,
  FileGitCommitRoot,
  FileGitCommitDetached,
  FileGitCommitOrphan,
  FileGitCommitUnborn,
  FileGitCommitHead,
  FileGitCommitMaster,
  FileGitCommitMain,
  FileGitCommitDevelop,
  FileGitCommitFeature,
  FileGitCommitBugfix,
  FileGitCommitHotfix,
  FileGitCommitRelease,
  FileGitCommitSupport,
  FileGitCommitVersion,
  FileGitCommitStable,
  FileGitCommitBeta,
  FileGitCommitAlpha,
  FileGitCommitDev,
  FileGitCommitTest,
  FileGitCommitStaging,
  FileGitCommitProduction,
  FileGitCommitLive,
  FileGitCommitProd
} from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';

interface WebhookEndpoint {
  id: string;
  name: string;
  url: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  headers: Record<string, string>;
  payload: any;
  status: 'active' | 'inactive' | 'error';
  lastTriggered: string;
  successCount: number;
  errorCount: number;
  responseTime: number;
}

interface APIKey {
  id: string;
  name: string;
  key: string;
  permissions: string[];
  createdAt: string;
  lastUsed: string;
  status: 'active' | 'revoked';
}

const WebhookAPIManager: React.FC = () => {
  const { } = useStore();
  const [webhooks, setWebhooks] = useState<WebhookEndpoint[]>([]);
  const [apiKeys, setApiKeys] = useState<APIKey[]>([]);
  const [selectedWebhook, setSelectedWebhook] = useState<WebhookEndpoint | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [filter, setFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Sample data
  useEffect(() => {
    const sampleWebhooks: WebhookEndpoint[] = [
      {
        id: '1',
        name: 'GHL Contact Update',
        url: 'https://api.gohighlevel.com/v1/contacts/update',
        method: 'POST',
        headers: {
          'Authorization': 'Bearer YOUR_API_KEY',
          'Content-Type': 'application/json'
        },
        payload: {
          contactId: '{{contact.id}}',
          customFields: {
            'solar_lead_score': '{{lead_score}}',
            'appointment_scheduled': '{{appointment_date}}'
          }
        },
        status: 'active',
        lastTriggered: '2024-01-15T10:30:00Z',
        successCount: 145,
        errorCount: 3,
        responseTime: 250
      },
      {
        id: '2',
        name: 'VAPI Call End',
        url: 'https://your-app.com/webhooks/vapi-call-end',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Webhook-Secret': 'your-secret-key'
        },
        payload: {
          callId: '{{call.id}}',
          duration: '{{call.duration}}',
          outcome: '{{call.outcome}}',
          transcript: '{{call.transcript}}'
        },
        status: 'active',
        lastTriggered: '2024-01-15T09:45:00Z',
        successCount: 89,
        errorCount: 1,
        responseTime: 180
      }
    ];

    const sampleApiKeys: APIKey[] = [
      {
        id: '1',
        name: 'GHL Production API',
        key: 'ghl_****_****_****_****',
        permissions: ['contacts:read', 'contacts:write', 'workflows:read'],
        createdAt: '2024-01-10T08:00:00Z',
        lastUsed: '2024-01-15T10:30:00Z',
        status: 'active'
      },
      {
        id: '2',
        name: 'VAPI Development',
        key: 'vapi_****_****_****_****',
        permissions: ['calls:read', 'calls:write', 'agents:read'],
        createdAt: '2024-01-12T14:00:00Z',
        lastUsed: '2024-01-15T09:45:00Z',
        status: 'active'
      }
    ];

    setWebhooks(sampleWebhooks);
    setApiKeys(sampleApiKeys);
  }, []);

  const filteredWebhooks = webhooks.filter(webhook => {
    const matchesFilter = filter === 'all' || webhook.status === filter;
    const matchesSearch = webhook.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         webhook.url.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const testWebhook = async (webhook: WebhookEndpoint) => {
    setIsRunning(true);
    toast.loading(`Testing webhook: ${webhook.name}`, { id: 'webhook-test' });

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Update webhook stats
    setWebhooks(prev => prev.map(w => 
      w.id === webhook.id 
        ? { 
            ...w, 
            lastTriggered: new Date().toISOString(),
            successCount: w.successCount + 1,
            responseTime: Math.floor(Math.random() * 500) + 100
          }
        : w
    ));

    toast.success(`Webhook test successful! Response time: ${Math.floor(Math.random() * 500) + 100}ms`, { id: 'webhook-test' });
    setIsRunning(false);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'inactive': return <XCircle className="w-5 h-5 text-gray-500" />;
      case 'error': return <AlertTriangle className="w-5 h-5 text-red-500" />;
      default: return <AlertTriangle className="w-5 h-5 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-500 bg-green-50';
      case 'inactive': return 'text-gray-500 bg-gray-50';
      case 'error': return 'text-red-500 bg-red-50';
      default: return 'text-gray-500 bg-gray-50';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <Webhook className="w-8 h-8 text-blue-600" />
                Webhook & API Manager
              </h1>
              <p className="text-gray-600 mt-2">
                Advanced webhook and API management for voice AI integrations
              </p>
            </div>
            <div className="flex gap-3">
              <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <Plus className="w-4 h-4" />
                New Webhook
              </button>
              <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50">
                <Settings className="w-4 h-4" />
                Settings
              </button>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Webhooks</p>
                <p className="text-2xl font-bold text-gray-900">{webhooks.length}</p>
              </div>
              <Webhook className="w-8 h-8 text-blue-600" />
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active</p>
                <p className="text-2xl font-bold text-green-600">
                  {webhooks.filter(w => w.status === 'active').length}
                </p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">API Keys</p>
                <p className="text-2xl font-bold text-purple-600">{apiKeys.length}</p>
              </div>
              <Key className="w-8 h-8 text-purple-600" />
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Success Rate</p>
                <p className="text-2xl font-bold text-blue-600">
                  {webhooks.length > 0 ? Math.round(
                    (webhooks.reduce((acc, w) => acc + w.successCount, 0) / 
                     (webhooks.reduce((acc, w) => acc + w.successCount + w.errorCount, 0))) * 100
                  ) : 0}%
                </p>
              </div>
              <BarChart3 className="w-8 h-8 text-blue-600" />
            </div>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="bg-white p-6 rounded-lg shadow-sm border mb-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  placeholder="Search webhooks..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <select
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">All Status</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="error">Error</option>
              </select>
            </div>
          </div>
        </div>

        {/* Webhooks List */}
        <div className="bg-white rounded-lg shadow-sm border">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Webhook Endpoints</h2>
          </div>
          <div className="divide-y divide-gray-200">
            {filteredWebhooks.map((webhook) => (
              <div
                key={webhook.id}
                className="p-6 hover:bg-gray-50 cursor-pointer"
                onClick={() => setSelectedWebhook(webhook)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      {getStatusIcon(webhook.status)}
                      <h3 className="text-lg font-medium text-gray-900">{webhook.name}</h3>
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(webhook.status)}`}>
                        {webhook.status}
                      </span>
                      <span className="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">
                        {webhook.method}
                      </span>
                    </div>
                    <p className="text-gray-600 mb-3 font-mono text-sm">{webhook.url}</p>
                    <div className="flex items-center gap-6 text-sm text-gray-500">
                      <span>Success: {webhook.successCount}</span>
                      <span>Errors: {webhook.errorCount}</span>
                      <span>Avg Response: {webhook.responseTime}ms</span>
                      <span>Last triggered: {new Date(webhook.lastTriggered).toLocaleString()}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        testWebhook(webhook);
                      }}
                      disabled={isRunning}
                      className="p-2 text-blue-600 hover:text-blue-700 disabled:opacity-50"
                    >
                      <Play className="w-4 h-4" />
                    </button>
                    <button className="p-2 text-gray-400 hover:text-gray-600">
                      <Eye className="w-4 h-4" />
                    </button>
                    <button className="p-2 text-gray-400 hover:text-gray-600">
                      <Edit className="w-4 h-4" />
                    </button>
                    <button className="p-2 text-red-400 hover:text-red-600">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* API Keys */}
        <div className="mt-8 bg-white rounded-lg shadow-sm border">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">API Keys</h2>
              <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <Plus className="w-4 h-4" />
                New API Key
              </button>
            </div>
          </div>
          <div className="divide-y divide-gray-200">
            {apiKeys.map((key) => (
              <div key={key.id} className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-medium text-gray-900">{key.name}</h3>
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        key.status === 'active' ? 'text-green-500 bg-green-50' : 'text-red-500 bg-red-50'
                      }`}>
                        {key.status}
                      </span>
                    </div>
                    <p className="text-gray-600 font-mono text-sm mb-2">{key.key}</p>
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <span>Permissions: {key.permissions.join(', ')}</span>
                      <span>Created: {new Date(key.createdAt).toLocaleDateString()}</span>
                      <span>Last used: {new Date(key.lastUsed).toLocaleString()}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="p-2 text-gray-400 hover:text-gray-600">
                      <Eye className="w-4 h-4" />
                    </button>
                    <button className="p-2 text-gray-400 hover:text-gray-600">
                      <Edit className="w-4 h-4" />
                    </button>
                    <button className="p-2 text-red-400 hover:text-red-600">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default WebhookAPIManager;