import React, { useState } from 'react';
import { Plus, Bot, Settings, Play, Save, Trash2, Edit, Copy, Download, Upload, Zap, Brain, Mic, Volume2, MessageSquare, Target, Shield, BarChart3 } from 'lucide-react';
import { useStore } from '../../store/useStore';
import { VoiceAgent, VoiceAgentForm, Intent, TransferRule } from '../../types';
import { toast } from 'react-hot-toast';

const VoiceAgentBuilder: React.FC = () => {
  const { voiceAgents, addVoiceAgent, updateVoiceAgent, deleteVoiceAgent } = useStore();
  const [isCreating, setIsCreating] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'basic' | 'advanced' | 'intents' | 'transfers' | 'testing'>('basic');
  const [formData, setFormData] = useState<VoiceAgentForm>({
    name: '',
    persona: {
      tone: 'professional',
      style: 'conversational',
      language: 'en-US'
    },
    voiceProvider: 'elevenlabs',
    llmProvider: 'openai',
    defaultLanguage: 'en-US',
    scripts: {
      greeting: '',
      main: '',
      fallback: '',
      transfer: '',
      goodbye: ''
    }
  });
  const [intents, setIntents] = useState<Intent[]>([]);
  const [transferRules, setTransferRules] = useState<TransferRule[]>([]);
  const [advancedConfig, setAdvancedConfig] = useState({
    maxConversationTurns: 10,
    responseTimeout: 30,
    confidenceThreshold: 0.7,
    enableSentimentAnalysis: true,
    enableEmotionDetection: false,
    enableInterruptionHandling: true,
    maxInterruptions: 3,
    silenceTimeout: 5,
    bargeInEnabled: true,
    customInstructions: '',
    systemPrompt: '',
    temperature: 0.7,
    maxTokens: 150,
    topP: 0.9,
    frequencyPenalty: 0.0,
    presencePenalty: 0.0
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      toast.error('Agent name is required');
      return;
    }

    const agent: VoiceAgent = {
      id: editingId || Date.now().toString(),
      ...formData,
      intents: [],
      transferRules: [],
      createdAt: editingId ? voiceAgents.find(a => a.id === editingId)?.createdAt || new Date().toISOString() : new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    if (editingId) {
      updateVoiceAgent(editingId, agent);
      toast.success('Voice agent updated successfully');
    } else {
      addVoiceAgent(agent);
      toast.success('Voice agent created successfully');
    }

    resetForm();
  };

  const resetForm = () => {
    setFormData({
      name: '',
      persona: {
        tone: 'professional',
        style: 'conversational',
        language: 'en-US'
      },
      voiceProvider: 'elevenlabs',
      llmProvider: 'openai',
      defaultLanguage: 'en-US',
      scripts: {
        greeting: '',
        main: '',
        fallback: '',
        transfer: '',
        goodbye: ''
      }
    });
    setIsCreating(false);
    setEditingId(null);
  };

  const handleEdit = (agent: VoiceAgent) => {
    setFormData({
      name: agent.name,
      persona: agent.persona,
      voiceProvider: agent.voiceProvider,
      llmProvider: agent.llmProvider,
      defaultLanguage: agent.defaultLanguage,
      scripts: agent.scripts
    });
    setEditingId(agent.id);
    setIsCreating(true);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this voice agent?')) {
      deleteVoiceAgent(id);
      toast.success('Voice agent deleted');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Advanced Voice AI Agent Builder</h1>
          <p className="text-muted-foreground mt-2">
            Build powerful, self-reliant AI agents with advanced configuration, intent recognition, and GHL integration
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <button className="btn btn-outline flex items-center space-x-2">
            <Upload className="w-4 h-4" />
            <span>Import Agent</span>
          </button>
          <button className="btn btn-outline flex items-center space-x-2">
            <Download className="w-4 h-4" />
            <span>Export All</span>
          </button>
          <button
            onClick={() => setIsCreating(true)}
            className="btn btn-primary flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>New Agent</span>
          </button>
        </div>
      </div>

      {/* Agent List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {voiceAgents.map((agent) => (
          <div key={agent.id} className="card hover:shadow-lg transition-all duration-300">
            <div className="card-header">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary to-blue-600 rounded-lg flex items-center justify-center">
                    <Bot className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground text-lg">{agent.name}</h3>
                    <p className="text-sm text-muted-foreground">
                      {agent.persona.tone} • {agent.voiceProvider} • {agent.llmProvider}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-1">
                  <button
                    onClick={() => handleEdit(agent)}
                    className="p-2 rounded-md hover:bg-accent"
                    title="Edit agent"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {/* Duplicate agent */}}
                    className="p-2 rounded-md hover:bg-accent"
                    title="Duplicate agent"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(agent.id)}
                    className="p-2 rounded-md hover:bg-accent text-destructive"
                    title="Delete agent"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
            
            <div className="card-content">
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Persona</label>
                    <p className="text-sm text-foreground">
                      {agent.persona.style} • {agent.persona.language}
                    </p>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Intents</label>
                    <p className="text-sm text-foreground">
                      {agent.intents?.length || 0} configured
                    </p>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Scripts</label>
                    <p className="text-sm text-foreground">
                      {Object.values(agent.scripts).filter(s => s.trim()).length} configured
                    </p>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Transfers</label>
                    <p className="text-sm text-foreground">
                      {agent.transferRules?.length || 0} rules
                    </p>
                  </div>
                </div>

                {/* Performance Metrics */}
                <div className="border-t border-border pt-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Performance</span>
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-1">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-xs">Active</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <BarChart3 className="w-3 h-3 text-muted-foreground" />
                        <span className="text-xs">87% Success</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="card-footer">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">
                  Updated {new Date(agent.updatedAt).toLocaleDateString()}
                </span>
                <div className="flex items-center space-x-2">
                  <button className="btn btn-sm btn-outline flex items-center space-x-1">
                    <Play className="w-3 h-3" />
                    <span>Test</span>
                  </button>
                  <button className="btn btn-sm btn-primary flex items-center space-x-1">
                    <Zap className="w-3 h-3" />
                    <span>Deploy</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
        
        {voiceAgents.length === 0 && (
          <div className="col-span-full text-center py-12">
            <Bot className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">No voice agents yet</h3>
            <p className="text-muted-foreground mb-4">
              Create your first voice agent to get started
            </p>
            <button
              onClick={() => setIsCreating(true)}
              className="btn btn-primary"
            >
              Create Voice Agent
            </button>
          </div>
        )}
      </div>

      {/* Advanced Create/Edit Modal */}
      {isCreating && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-card rounded-lg shadow-lg w-full max-w-6xl max-h-[95vh] overflow-hidden m-4">
            <form onSubmit={handleSubmit} className="h-full flex flex-col">
              {/* Header */}
              <div className="flex items-center justify-between border-b border-border p-6">
                <div>
                  <h2 className="text-2xl font-bold text-foreground">
                    {editingId ? 'Edit Voice Agent' : 'Create Advanced Voice Agent'}
                  </h2>
                  <p className="text-muted-foreground mt-1">
                    Configure a powerful, self-reliant AI agent for GoHighLevel integration
                  </p>
                </div>
                <button
                  type="button"
                  onClick={resetForm}
                  className="text-muted-foreground hover:text-foreground p-2 rounded-md hover:bg-accent"
                >
                  ✕
                </button>
              </div>

              {/* Tab Navigation */}
              <div className="border-b border-border px-6">
                <nav className="flex space-x-8">
                  {[
                    { id: 'basic', label: 'Basic Config', icon: Settings },
                    { id: 'advanced', label: 'Advanced', icon: Brain },
                    { id: 'intents', label: 'Intents', icon: Target },
                    { id: 'transfers', label: 'Transfers', icon: MessageSquare },
                    { id: 'testing', label: 'Testing', icon: Play }
                  ].map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id as any)}
                      className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                        activeTab === tab.id
                          ? 'border-primary text-primary'
                          : 'border-transparent text-muted-foreground hover:text-foreground'
                      }`}
                    >
                      <tab.icon className="w-4 h-4" />
                      <span>{tab.label}</span>
                    </button>
                  ))}
                </nav>
              </div>

              {/* Tab Content */}
              <div className="flex-1 overflow-y-auto p-6">
                {activeTab === 'basic' && (
                  <div className="space-y-6">
                    <h3 className="text-lg font-semibold text-foreground">Basic Configuration</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-foreground mb-2">
                          Agent Name *
                        </label>
                        <input
                          type="text"
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          className="w-full px-3 py-2 border border-input rounded-md"
                          placeholder="e.g., Sales Assistant, Support Bot"
                          required
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-foreground mb-2">
                          Default Language
                        </label>
                        <select
                          value={formData.defaultLanguage}
                          onChange={(e) => setFormData({ ...formData, defaultLanguage: e.target.value })}
                          className="w-full px-3 py-2 border border-input rounded-md"
                        >
                          <option value="en-US">English (US)</option>
                          <option value="en-GB">English (UK)</option>
                          <option value="es-ES">Spanish</option>
                          <option value="fr-FR">French</option>
                          <option value="de-DE">German</option>
                        </select>
                      </div>
                    </div>

                    {/* Persona Settings */}
                    <div className="space-y-4">
                      <h4 className="text-md font-semibold text-foreground">Persona Configuration</h4>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-foreground mb-2">
                            Tone
                          </label>
                          <select
                            value={formData.persona.tone}
                            onChange={(e) => setFormData({
                              ...formData,
                              persona: { ...formData.persona, tone: e.target.value as any }
                            })}
                            className="w-full px-3 py-2 border border-input rounded-md"
                          >
                            <option value="professional">Professional</option>
                            <option value="friendly">Friendly</option>
                            <option value="casual">Casual</option>
                            <option value="authoritative">Authoritative</option>
                          </select>
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-foreground mb-2">
                            Style
                          </label>
                          <select
                            value={formData.persona.style}
                            onChange={(e) => setFormData({
                              ...formData,
                              persona: { ...formData.persona, style: e.target.value as any }
                            })}
                            className="w-full px-3 py-2 border border-input rounded-md"
                          >
                            <option value="conversational">Conversational</option>
                            <option value="formal">Formal</option>
                            <option value="technical">Technical</option>
                            <option value="empathetic">Empathetic</option>
                          </select>
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-foreground mb-2">
                            Language
                          </label>
                          <select
                            value={formData.persona.language}
                            onChange={(e) => setFormData({
                              ...formData,
                              persona: { ...formData.persona, language: e.target.value }
                            })}
                            className="w-full px-3 py-2 border border-input rounded-md"
                          >
                            <option value="en-US">English (US)</option>
                            <option value="en-GB">English (UK)</option>
                            <option value="es-ES">Spanish</option>
                            <option value="fr-FR">French</option>
                            <option value="de-DE">German</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    {/* Provider Settings */}
                    <div className="space-y-4">
                      <h4 className="text-md font-semibold text-foreground">Provider Configuration</h4>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-foreground mb-2">
                            Voice Provider
                          </label>
                          <select
                            value={formData.voiceProvider}
                            onChange={(e) => setFormData({ ...formData, voiceProvider: e.target.value as any })}
                            className="w-full px-3 py-2 border border-input rounded-md"
                          >
                            <option value="elevenlabs">ElevenLabs</option>
                            <option value="azure">Azure Speech</option>
                            <option value="aws">AWS Polly</option>
                            <option value="google">Google Cloud TTS</option>
                          </select>
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-foreground mb-2">
                            LLM Provider
                          </label>
                          <select
                            value={formData.llmProvider}
                            onChange={(e) => setFormData({ ...formData, llmProvider: e.target.value as any })}
                            className="w-full px-3 py-2 border border-input rounded-md"
                          >
                            <option value="openai">OpenAI</option>
                            <option value="anthropic">Anthropic</option>
                            <option value="azure">Azure OpenAI</option>
                            <option value="cohere">Cohere</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    {/* Scripts */}
                    <div className="space-y-4">
                      <h4 className="text-md font-semibold text-foreground">Scripts & Responses</h4>
                      
                      <div className="space-y-4">
                        {Object.entries(formData.scripts).map(([key, value]) => (
                          <div key={key}>
                            <label className="block text-sm font-medium text-foreground mb-2 capitalize">
                              {key.replace(/([A-Z])/g, ' $1').trim()}
                            </label>
                            <textarea
                              value={value}
                              onChange={(e) => setFormData({
                                ...formData,
                                scripts: { ...formData.scripts, [key]: e.target.value }
                              })}
                              className="w-full px-3 py-2 border border-input rounded-md"
                              rows={3}
                              placeholder={`Enter ${key} script...`}
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'advanced' && (
                  <div className="space-y-6">
                    <h3 className="text-lg font-semibold text-foreground">Advanced Configuration</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <h4 className="text-md font-semibold text-foreground">Conversation Settings</h4>
                        
                        <div>
                          <label className="block text-sm font-medium text-foreground mb-2">
                            Max Conversation Turns
                          </label>
                          <input
                            type="number"
                            value={advancedConfig.maxConversationTurns}
                            onChange={(e) => setAdvancedConfig({...advancedConfig, maxConversationTurns: parseInt(e.target.value)})}
                            className="w-full px-3 py-2 border border-input rounded-md"
                            min="1"
                            max="50"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-foreground mb-2">
                            Response Timeout (seconds)
                          </label>
                          <input
                            type="number"
                            value={advancedConfig.responseTimeout}
                            onChange={(e) => setAdvancedConfig({...advancedConfig, responseTimeout: parseInt(e.target.value)})}
                            className="w-full px-3 py-2 border border-input rounded-md"
                            min="5"
                            max="120"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-foreground mb-2">
                            Confidence Threshold
                          </label>
                          <input
                            type="range"
                            min="0.1"
                            max="1"
                            step="0.1"
                            value={advancedConfig.confidenceThreshold}
                            onChange={(e) => setAdvancedConfig({...advancedConfig, confidenceThreshold: parseFloat(e.target.value)})}
                            className="w-full"
                          />
                          <div className="text-sm text-muted-foreground">
                            {advancedConfig.confidenceThreshold}
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        <h4 className="text-md font-semibold text-foreground">AI Model Settings</h4>
                        
                        <div>
                          <label className="block text-sm font-medium text-foreground mb-2">
                            Temperature
                          </label>
                          <input
                            type="range"
                            min="0"
                            max="2"
                            step="0.1"
                            value={advancedConfig.temperature}
                            onChange={(e) => setAdvancedConfig({...advancedConfig, temperature: parseFloat(e.target.value)})}
                            className="w-full"
                          />
                          <div className="text-sm text-muted-foreground">
                            {advancedConfig.temperature}
                          </div>
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-foreground mb-2">
                            Max Tokens
                          </label>
                          <input
                            type="number"
                            value={advancedConfig.maxTokens}
                            onChange={(e) => setAdvancedConfig({...advancedConfig, maxTokens: parseInt(e.target.value)})}
                            className="w-full px-3 py-2 border border-input rounded-md"
                            min="50"
                            max="1000"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-foreground mb-2">
                            Top P
                          </label>
                          <input
                            type="range"
                            min="0"
                            max="1"
                            step="0.1"
                            value={advancedConfig.topP}
                            onChange={(e) => setAdvancedConfig({...advancedConfig, topP: parseFloat(e.target.value)})}
                            className="w-full"
                          />
                          <div className="text-sm text-muted-foreground">
                            {advancedConfig.topP}
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <h4 className="text-md font-semibold text-foreground">Advanced Features</h4>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id="sentimentAnalysis"
                            checked={advancedConfig.enableSentimentAnalysis}
                            onChange={(e) => setAdvancedConfig({...advancedConfig, enableSentimentAnalysis: e.target.checked})}
                            className="rounded"
                          />
                          <label htmlFor="sentimentAnalysis" className="text-sm font-medium text-foreground">
                            Enable Sentiment Analysis
                          </label>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id="emotionDetection"
                            checked={advancedConfig.enableEmotionDetection}
                            onChange={(e) => setAdvancedConfig({...advancedConfig, enableEmotionDetection: e.target.checked})}
                            className="rounded"
                          />
                          <label htmlFor="emotionDetection" className="text-sm font-medium text-foreground">
                            Enable Emotion Detection
                          </label>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id="interruptionHandling"
                            checked={advancedConfig.enableInterruptionHandling}
                            onChange={(e) => setAdvancedConfig({...advancedConfig, enableInterruptionHandling: e.target.checked})}
                            className="rounded"
                          />
                          <label htmlFor="interruptionHandling" className="text-sm font-medium text-foreground">
                            Enable Interruption Handling
                          </label>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id="bargeIn"
                            checked={advancedConfig.bargeInEnabled}
                            onChange={(e) => setAdvancedConfig({...advancedConfig, bargeInEnabled: e.target.checked})}
                            className="rounded"
                          />
                          <label htmlFor="bargeIn" className="text-sm font-medium text-foreground">
                            Enable Barge-in
                          </label>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <h4 className="text-md font-semibold text-foreground">Custom Instructions</h4>
                      
                      <div>
                        <label className="block text-sm font-medium text-foreground mb-2">
                          System Prompt
                        </label>
                        <textarea
                          value={advancedConfig.systemPrompt}
                          onChange={(e) => setAdvancedConfig({...advancedConfig, systemPrompt: e.target.value})}
                          className="w-full px-3 py-2 border border-input rounded-md"
                          rows={4}
                          placeholder="Enter custom system prompt for the AI agent..."
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-foreground mb-2">
                          Additional Instructions
                        </label>
                        <textarea
                          value={advancedConfig.customInstructions}
                          onChange={(e) => setAdvancedConfig({...advancedConfig, customInstructions: e.target.value})}
                          className="w-full px-3 py-2 border border-input rounded-md"
                          rows={3}
                          placeholder="Enter additional instructions for the agent..."
                        />
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'intents' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold text-foreground">Intent Recognition</h3>
                      <button
                        type="button"
                        onClick={() => {
                          const newIntent: Intent = {
                            id: Date.now().toString(),
                            name: '',
                            keywords: [],
                            confidence: 0.7,
                            response: '',
                            actions: []
                          };
                          setIntents([...intents, newIntent]);
                        }}
                        className="btn btn-primary flex items-center space-x-2"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Add Intent</span>
                      </button>
                    </div>
                    
                    <div className="space-y-4">
                      {intents.map((intent, index) => (
                        <div key={intent.id} className="card">
                          <div className="card-content">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div>
                                <label className="block text-sm font-medium text-foreground mb-2">
                                  Intent Name
                                </label>
                                <input
                                  type="text"
                                  value={intent.name}
                                  onChange={(e) => {
                                    const updated = [...intents];
                                    updated[index].name = e.target.value;
                                    setIntents(updated);
                                  }}
                                  className="w-full px-3 py-2 border border-input rounded-md"
                                  placeholder="e.g., book_appointment, ask_question"
                                />
                              </div>
                              
                              <div>
                                <label className="block text-sm font-medium text-foreground mb-2">
                                  Confidence Threshold
                                </label>
                                <input
                                  type="range"
                                  min="0.1"
                                  max="1"
                                  step="0.1"
                                  value={intent.confidence}
                                  onChange={(e) => {
                                    const updated = [...intents];
                                    updated[index].confidence = parseFloat(e.target.value);
                                    setIntents(updated);
                                  }}
                                  className="w-full"
                                />
                                <div className="text-sm text-muted-foreground">
                                  {intent.confidence}
                                </div>
                              </div>
                            </div>
                            
                            <div className="mt-4">
                              <label className="block text-sm font-medium text-foreground mb-2">
                                Keywords (comma-separated)
                              </label>
                              <input
                                type="text"
                                value={intent.keywords.join(', ')}
                                onChange={(e) => {
                                  const updated = [...intents];
                                  updated[index].keywords = e.target.value.split(',').map(k => k.trim());
                                  setIntents(updated);
                                }}
                                className="w-full px-3 py-2 border border-input rounded-md"
                                placeholder="e.g., book, appointment, schedule, meeting"
                              />
                            </div>
                            
                            <div className="mt-4">
                              <label className="block text-sm font-medium text-foreground mb-2">
                                Response
                              </label>
                              <textarea
                                value={intent.response}
                                onChange={(e) => {
                                  const updated = [...intents];
                                  updated[index].response = e.target.value;
                                  setIntents(updated);
                                }}
                                className="w-full px-3 py-2 border border-input rounded-md"
                                rows={3}
                                placeholder="Response when this intent is detected..."
                              />
                            </div>
                            
                            <div className="mt-4 flex justify-end">
                              <button
                                type="button"
                                onClick={() => {
                                  const updated = intents.filter((_, i) => i !== index);
                                  setIntents(updated);
                                }}
                                className="btn btn-sm btn-destructive"
                              >
                                Remove Intent
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                      
                      {intents.length === 0 && (
                        <div className="text-center py-8">
                          <Target className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                          <h4 className="text-lg font-semibold text-foreground mb-2">No Intents Configured</h4>
                          <p className="text-muted-foreground">
                            Add intents to help your agent understand and respond to specific user requests
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {activeTab === 'transfers' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold text-foreground">Transfer Rules</h3>
                      <button
                        type="button"
                        onClick={() => {
                          const newRule: TransferRule = {
                            id: Date.now().toString(),
                            condition: '',
                            target: 'human',
                            priority: 1
                          };
                          setTransferRules([...transferRules, newRule]);
                        }}
                        className="btn btn-primary flex items-center space-x-2"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Add Rule</span>
                      </button>
                    </div>
                    
                    <div className="space-y-4">
                      {transferRules.map((rule, index) => (
                        <div key={rule.id} className="card">
                          <div className="card-content">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                              <div>
                                <label className="block text-sm font-medium text-foreground mb-2">
                                  Condition
                                </label>
                                <input
                                  type="text"
                                  value={rule.condition}
                                  onChange={(e) => {
                                    const updated = [...transferRules];
                                    updated[index].condition = e.target.value;
                                    setTransferRules(updated);
                                  }}
                                  className="w-full px-3 py-2 border border-input rounded-md"
                                  placeholder="e.g., user says 'speak to human'"
                                />
                              </div>
                              
                              <div>
                                <label className="block text-sm font-medium text-foreground mb-2">
                                  Target
                                </label>
                                <select
                                  value={rule.target}
                                  onChange={(e) => {
                                    const updated = [...transferRules];
                                    updated[index].target = e.target.value as any;
                                    setTransferRules(updated);
                                  }}
                                  className="w-full px-3 py-2 border border-input rounded-md"
                                >
                                  <option value="human">Human Agent</option>
                                  <option value="voicemail">Voicemail</option>
                                  <option value="other_agent">Other Agent</option>
                                </select>
                              </div>
                              
                              <div>
                                <label className="block text-sm font-medium text-foreground mb-2">
                                  Priority
                                </label>
                                <input
                                  type="number"
                                  value={rule.priority}
                                  onChange={(e) => {
                                    const updated = [...transferRules];
                                    updated[index].priority = parseInt(e.target.value);
                                    setTransferRules(updated);
                                  }}
                                  className="w-full px-3 py-2 border border-input rounded-md"
                                  min="1"
                                  max="10"
                                />
                              </div>
                            </div>
                            
                            <div className="mt-4 flex justify-end">
                              <button
                                type="button"
                                onClick={() => {
                                  const updated = transferRules.filter((_, i) => i !== index);
                                  setTransferRules(updated);
                                }}
                                className="btn btn-sm btn-destructive"
                              >
                                Remove Rule
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                      
                      {transferRules.length === 0 && (
                        <div className="text-center py-8">
                          <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                          <h4 className="text-lg font-semibold text-foreground mb-2">No Transfer Rules</h4>
                          <p className="text-muted-foreground">
                            Add rules to determine when and how to transfer calls
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {activeTab === 'testing' && (
                  <div className="space-y-6">
                    <h3 className="text-lg font-semibold text-foreground">Agent Testing</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="card">
                        <div className="card-header">
                          <h4 className="text-md font-semibold text-foreground">Quick Test</h4>
                        </div>
                        <div className="card-content">
                          <div className="space-y-4">
                            <div>
                              <label className="block text-sm font-medium text-foreground mb-2">
                                Test Message
                              </label>
                              <textarea
                                className="w-full px-3 py-2 border border-input rounded-md"
                                rows={3}
                                placeholder="Enter a test message to see how the agent responds..."
                              />
                            </div>
                            
                            <button className="btn btn-primary w-full flex items-center justify-center space-x-2">
                              <Play className="w-4 h-4" />
                              <span>Test Response</span>
                            </button>
                          </div>
                        </div>
                      </div>
                      
                      <div className="card">
                        <div className="card-header">
                          <h4 className="text-md font-semibold text-foreground">Performance Metrics</h4>
                        </div>
                        <div className="card-content">
                          <div className="space-y-3">
                            <div className="flex justify-between">
                              <span className="text-sm text-muted-foreground">Response Time</span>
                              <span className="text-sm font-medium text-foreground">1.2s</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-sm text-muted-foreground">Confidence Score</span>
                              <span className="text-sm font-medium text-foreground">0.87</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-sm text-muted-foreground">Intent Match</span>
                              <span className="text-sm font-medium text-foreground">✓</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-sm text-muted-foreground">Sentiment</span>
                              <span className="text-sm font-medium text-foreground">Positive</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="card">
                      <div className="card-header">
                        <h4 className="text-md font-semibold text-foreground">Test Scenarios</h4>
                      </div>
                      <div className="card-content">
                        <div className="space-y-3">
                          {[
                            "Hello, I'd like to book an appointment",
                            "I have a question about your services",
                            "Can I speak to a human?",
                            "I'm not interested, please remove me",
                            "What are your business hours?"
                          ].map((scenario, index) => (
                            <div key={index} className="flex items-center justify-between p-3 border border-border rounded-md">
                              <span className="text-sm text-foreground">{scenario}</span>
                              <button className="btn btn-sm btn-outline">
                                Test
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between p-6 border-t border-border bg-muted/20">
                <div className="flex items-center space-x-4">
                  <button
                    type="button"
                    onClick={resetForm}
                    className="btn btn-secondary"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    className="btn btn-outline flex items-center space-x-2"
                  >
                    <Copy className="w-4 h-4" />
                    <span>Save as Template</span>
                  </button>
                </div>
                
                <div className="flex items-center space-x-4">
                  <button
                    type="button"
                    className="btn btn-outline flex items-center space-x-2"
                  >
                    <Play className="w-4 h-4" />
                    <span>Test Agent</span>
                  </button>
                  <button
                    type="submit"
                    className="btn btn-primary flex items-center space-x-2"
                  >
                    <Save className="w-4 h-4" />
                    <span>{editingId ? 'Update Agent' : 'Create Agent'}</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default VoiceAgentBuilder;
