import React, { useState, useEffect } from 'react';
import { 
  Zap, 
  Play, 
  Pause, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Clock, 
  BarChart3, 
  Settings,
  RefreshCw,
  Download,
  Eye,
  Filter,
  Search,
  Brain,
  Target,
  Activity,
  Users,
  MessageSquare,
  Phone,
  Database,
  Shield,
  TrendingUp,
  Rocket,
  Cloud,
  Server,
  Globe,
  Lock,
  Unlock,
  ArrowRight,
  ArrowDown,
  ChevronRight,
  ChevronDown
} from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';

interface DeploymentEnvironment {
  id: string;
  name: string;
  type: 'staging' | 'production' | 'development';
  status: 'active' | 'inactive' | 'deploying' | 'error';
  url: string;
  lastDeployment: string | null;
  version: string;
  health: 'healthy' | 'warning' | 'critical';
  resources: {
    cpu: number;
    memory: number;
    storage: number;
  };
}

interface DeploymentPackage {
  id: string;
  name: string;
  version: string;
  description: string;
  size: number;
  createdAt: string;
  status: 'ready' | 'building' | 'failed' | 'deployed';
  components: Array<{
    name: string;
    type: 'agent' | 'workflow' | 'integration' | 'config';
    status: 'ready' | 'building' | 'failed';
    size: number;
  }>;
  checksum: string;
  dependencies: string[];
}

interface DeploymentJob {
  id: string;
  packageId: string;
  environmentId: string;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';
  progress: number;
  startedAt: string | null;
  completedAt: string | null;
  duration: number;
  logs: Array<{
    timestamp: string;
    level: 'info' | 'warning' | 'error' | 'success';
    message: string;
  }>;
  steps: Array<{
    name: string;
    status: 'pending' | 'running' | 'completed' | 'failed' | 'skipped';
    duration: number;
    message?: string;
  }>;
}

interface DeploymentMetrics {
  totalDeployments: number;
  successfulDeployments: number;
  failedDeployments: number;
  averageDeploymentTime: number;
  activeEnvironments: number;
  lastDeployment: string | null;
  uptime: number;
}

const OneClickDeployment: React.FC = () => {
  const { darkMode } = useStore();
  const [environments, setEnvironments] = useState<DeploymentEnvironment[]>([]);
  const [packages, setPackages] = useState<DeploymentPackage[]>([]);
  const [deploymentJobs, setDeploymentJobs] = useState<DeploymentJob[]>([]);
  const [metrics, setMetrics] = useState<DeploymentMetrics>({
    totalDeployments: 0,
    successfulDeployments: 0,
    failedDeployments: 0,
    averageDeploymentTime: 0,
    activeEnvironments: 0,
    lastDeployment: null,
    uptime: 0
  });
  const [selectedPackage, setSelectedPackage] = useState<string>('');
  const [selectedEnvironment, setSelectedEnvironment] = useState<string>('');
  const [isDeploying, setIsDeploying] = useState(false);
  const [activeTab, setActiveTab] = useState<'deploy' | 'environments' | 'packages' | 'jobs'>('deploy');

  // Sample data - in real app this would come from deployment API
  useEffect(() => {
    const sampleEnvironments: DeploymentEnvironment[] = [
      {
        id: 'env_1',
        name: 'Production',
        type: 'production',
        status: 'active',
        url: 'https://voice-ai-prod.company.com',
        lastDeployment: '2024-01-15T10:30:00Z',
        version: 'v2.1.4',
        health: 'healthy',
        resources: {
          cpu: 45.2,
          memory: 67.8,
          storage: 234.5
        }
      },
      {
        id: 'env_2',
        name: 'Staging',
        type: 'staging',
        status: 'active',
        url: 'https://voice-ai-staging.company.com',
        lastDeployment: '2024-01-15T11:15:00Z',
        version: 'v2.2.0-beta',
        health: 'warning',
        resources: {
          cpu: 23.1,
          memory: 45.6,
          storage: 156.7
        }
      },
      {
        id: 'env_3',
        name: 'Development',
        type: 'development',
        status: 'inactive',
        url: 'https://voice-ai-dev.company.com',
        lastDeployment: '2024-01-14T16:45:00Z',
        version: 'v2.2.0-dev',
        health: 'healthy',
        resources: {
          cpu: 12.3,
          memory: 28.9,
          storage: 89.2
        }
      }
    ];

    const samplePackages: DeploymentPackage[] = [
      {
        id: 'pkg_1',
        name: 'F45 Fitness Agent Bundle',
        version: 'v1.2.3',
        description: 'Complete F45 fitness agent with trial booking and membership management',
        size: 45.6,
        createdAt: '2024-01-15T09:30:00Z',
        status: 'ready',
        components: [
          { name: 'F45 Agent Config', type: 'agent', status: 'ready', size: 12.3 },
          { name: 'Trial Booking Workflow', type: 'workflow', status: 'ready', size: 8.7 },
          { name: 'GHL Integration', type: 'integration', status: 'ready', size: 15.2 },
          { name: 'Custom Fields', type: 'config', status: 'ready', size: 9.4 }
        ],
        checksum: 'a1b2c3d4e5f6...',
        dependencies: ['ghl-api-v2', 'voice-ai-core']
      },
      {
        id: 'pkg_2',
        name: 'Legal Consultation Suite',
        version: 'v2.0.1',
        description: 'Legal consultation agent with case type qualification and attorney matching',
        size: 67.8,
        createdAt: '2024-01-15T08:15:00Z',
        status: 'building',
        components: [
          { name: 'Legal Agent Config', type: 'agent', status: 'building', size: 18.9 },
          { name: 'Case Qualification Workflow', type: 'workflow', status: 'ready', size: 12.4 },
          { name: 'Attorney Matching Logic', type: 'integration', status: 'ready', size: 22.1 },
          { name: 'Compliance Config', type: 'config', status: 'ready', size: 14.4 }
        ],
        checksum: 'b2c3d4e5f6a1...',
        dependencies: ['ghl-api-v2', 'legal-db-connector']
      },
      {
        id: 'pkg_3',
        name: 'Emergency Response Bundle',
        version: 'v1.5.0',
        description: 'Emergency response agents for plumbing, towing, and construction',
        size: 89.2,
        createdAt: '2024-01-15T07:45:00Z',
        status: 'deployed',
        components: [
          { name: 'Plumbing Agent', type: 'agent', status: 'ready', size: 15.6 },
          { name: 'Towing Agent', type: 'agent', status: 'ready', size: 14.8 },
          { name: 'Construction Agent', type: 'agent', status: 'ready', size: 16.2 },
          { name: 'Emergency Workflows', type: 'workflow', status: 'ready', size: 18.7 },
          { name: 'Dispatch Integration', type: 'integration', status: 'ready', size: 23.9 }
        ],
        checksum: 'c3d4e5f6a1b2...',
        dependencies: ['ghl-api-v2', 'emergency-dispatch-api']
      }
    ];

    const sampleJobs: DeploymentJob[] = [
      {
        id: 'job_1',
        packageId: 'pkg_1',
        environmentId: 'env_1',
        status: 'completed',
        progress: 100,
        startedAt: '2024-01-15T10:15:00Z',
        completedAt: '2024-01-15T10:30:00Z',
        duration: 900,
        logs: [
          { timestamp: '2024-01-15T10:15:00Z', level: 'info', message: 'Deployment started' },
          { timestamp: '2024-01-15T10:16:00Z', level: 'info', message: 'Validating package integrity' },
          { timestamp: '2024-01-15T10:17:00Z', level: 'success', message: 'Package validation passed' },
          { timestamp: '2024-01-15T10:18:00Z', level: 'info', message: 'Backing up current version' },
          { timestamp: '2024-01-15T10:20:00Z', level: 'info', message: 'Deploying agent configuration' },
          { timestamp: '2024-01-15T10:25:00Z', level: 'info', message: 'Updating GHL integrations' },
          { timestamp: '2024-01-15T10:28:00Z', level: 'info', message: 'Running health checks' },
          { timestamp: '2024-01-15T10:30:00Z', level: 'success', message: 'Deployment completed successfully' }
        ],
        steps: [
          { name: 'Pre-deployment checks', status: 'completed', duration: 60, message: 'All checks passed' },
          { name: 'Package validation', status: 'completed', duration: 60, message: 'Integrity verified' },
          { name: 'Backup creation', status: 'completed', duration: 120, message: 'Backup created' },
          { name: 'Agent deployment', status: 'completed', duration: 300, message: 'Agent deployed' },
          { name: 'Integration update', status: 'completed', duration: 180, message: 'GHL updated' },
          { name: 'Health verification', status: 'completed', duration: 120, message: 'System healthy' }
        ]
      },
      {
        id: 'job_2',
        packageId: 'pkg_2',
        environmentId: 'env_2',
        status: 'running',
        progress: 65,
        startedAt: '2024-01-15T11:00:00Z',
        completedAt: null,
        duration: 0,
        logs: [
          { timestamp: '2024-01-15T11:00:00Z', level: 'info', message: 'Deployment started' },
          { timestamp: '2024-01-15T11:01:00Z', level: 'info', message: 'Validating package integrity' },
          { timestamp: '2024-01-15T11:02:00Z', level: 'success', message: 'Package validation passed' },
          { timestamp: '2024-01-15T11:03:00Z', level: 'info', message: 'Backing up current version' },
          { timestamp: '2024-01-15T11:05:00Z', level: 'info', message: 'Deploying agent configuration' },
          { timestamp: '2024-01-15T11:10:00Z', level: 'warning', message: 'Integration update in progress...' }
        ],
        steps: [
          { name: 'Pre-deployment checks', status: 'completed', duration: 60, message: 'All checks passed' },
          { name: 'Package validation', status: 'completed', duration: 60, message: 'Integrity verified' },
          { name: 'Backup creation', status: 'completed', duration: 120, message: 'Backup created' },
          { name: 'Agent deployment', status: 'completed', duration: 300, message: 'Agent deployed' },
          { name: 'Integration update', status: 'running', duration: 0, message: 'In progress...' },
          { name: 'Health verification', status: 'pending', duration: 0 }
        ]
      }
    ];

    setEnvironments(sampleEnvironments);
    setPackages(samplePackages);
    setDeploymentJobs(sampleJobs);
    
    // Calculate metrics
    const successful = sampleJobs.filter(j => j.status === 'completed').length;
    const failed = sampleJobs.filter(j => j.status === 'failed').length;
    const avgTime = sampleJobs.reduce((sum, j) => sum + j.duration, 0) / sampleJobs.length;
    const active = sampleEnvironments.filter(e => e.status === 'active').length;
    
    setMetrics({
      totalDeployments: sampleJobs.length,
      successfulDeployments: successful,
      failedDeployments: failed,
      averageDeploymentTime: avgTime,
      activeEnvironments: active,
      lastDeployment: sampleJobs.find(j => j.completedAt)?.completedAt || null,
      uptime: 99.8
    });
  }, []);

  const handleDeploy = () => {
    if (!selectedPackage || !selectedEnvironment) {
      toast.error('Please select both package and environment');
      return;
    }

    setIsDeploying(true);
    
    // Create new deployment job
    const newJob: DeploymentJob = {
      id: `job_${Date.now()}`,
      packageId: selectedPackage,
      environmentId: selectedEnvironment,
      status: 'running',
      progress: 0,
      startedAt: new Date().toISOString(),
      completedAt: null,
      duration: 0,
      logs: [
        { timestamp: new Date().toISOString(), level: 'info', message: 'Deployment started' }
      ],
      steps: [
        { name: 'Pre-deployment checks', status: 'pending', duration: 0 },
        { name: 'Package validation', status: 'pending', duration: 0 },
        { name: 'Backup creation', status: 'pending', duration: 0 },
        { name: 'Agent deployment', status: 'pending', duration: 0 },
        { name: 'Integration update', status: 'pending', duration: 0 },
        { name: 'Health verification', status: 'pending', duration: 0 }
      ]
    };

    setDeploymentJobs(prev => [newJob, ...prev]);
    toast.success('Deployment started');

    // Simulate deployment progress
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      setDeploymentJobs(prev => 
        prev.map(job => 
          job.id === newJob.id 
            ? { ...job, progress: Math.min(progress, 100) }
            : job
        )
      );

      if (progress >= 100) {
        clearInterval(interval);
        setIsDeploying(false);
        setDeploymentJobs(prev => 
          prev.map(job => 
            job.id === newJob.id 
              ? { 
                  ...job, 
                  status: 'completed' as const,
                  completedAt: new Date().toISOString(),
                  duration: 300
                }
              : job
          )
        );
        toast.success('Deployment completed successfully');
      }
    }, 1000);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-400 bg-green-100';
      case 'inactive': return 'text-gray-400 bg-gray-100';
      case 'deploying': return 'text-blue-400 bg-blue-100';
      case 'error': return 'text-red-400 bg-red-100';
      case 'completed': return 'text-green-400 bg-green-100';
      case 'running': return 'text-blue-400 bg-blue-100';
      case 'failed': return 'text-red-400 bg-red-100';
      case 'pending': return 'text-yellow-400 bg-yellow-100';
      case 'ready': return 'text-green-400 bg-green-100';
      case 'building': return 'text-blue-400 bg-blue-100';
      case 'deployed': return 'text-green-400 bg-green-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const getHealthColor = (health: string) => {
    switch (health) {
      case 'healthy': return 'text-green-400';
      case 'warning': return 'text-yellow-400';
      case 'critical': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const renderDeployTab = () => (
    <div className="space-y-6">
      {/* Quick Deploy */}
      <div className="card p-6">
        <h2 className="text-xl font-semibold text-foreground mb-6">One-Click Deployment</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-2">
              Select Package
            </label>
            <select
              className="w-full input"
              value={selectedPackage}
              onChange={(e) => setSelectedPackage(e.target.value)}
            >
              <option value="">Choose a package...</option>
              {packages.map(pkg => (
                <option key={pkg.id} value={pkg.id}>{pkg.name} ({pkg.version})</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-2">
              Select Environment
            </label>
            <select
              className="w-full input"
              value={selectedEnvironment}
              onChange={(e) => setSelectedEnvironment(e.target.value)}
            >
              <option value="">Choose an environment...</option>
              {environments.map(env => (
                <option key={env.id} value={env.id}>{env.name} ({env.type})</option>
              ))}
            </select>
          </div>
        </div>
        <div className="flex justify-end mt-6">
          <button
            onClick={handleDeploy}
            disabled={isDeploying || !selectedPackage || !selectedEnvironment}
            className="btn btn-primary btn-lg"
          >
            {isDeploying ? (
              <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
            ) : (
              <Rocket className="w-5 h-5 mr-2" />
            )}
            {isDeploying ? 'Deploying...' : 'Deploy Now'}
          </button>
        </div>
      </div>

      {/* Recent Deployments */}
      <div className="card p-6">
        <h2 className="text-xl font-semibold text-foreground mb-6">Recent Deployments</h2>
        <div className="space-y-4">
          {deploymentJobs.slice(0, 5).map((job) => (
            <div key={job.id} className="flex items-center justify-between p-4 bg-secondary rounded-lg">
              <div className="flex items-center space-x-4">
                <div className={`w-3 h-3 rounded-full ${getStatusColor(job.status).split(' ')[0]}`}></div>
                <div>
                  <p className="font-medium text-foreground">
                    {packages.find(p => p.id === job.packageId)?.name}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {environments.find(e => e.id === job.environmentId)?.name} • 
                    {job.startedAt ? new Date(job.startedAt).toLocaleString() : 'Not started'}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <p className="text-sm font-medium text-foreground">{job.progress}%</p>
                  <div className="w-24 bg-muted rounded-full h-2">
                    <div 
                      className="bg-primary h-2 rounded-full" 
                      style={{ width: `${job.progress}%` }}
                    ></div>
                  </div>
                </div>
                <div className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(job.status)}`}>
                  {job.status}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderEnvironmentsTab = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {environments.map((env) => (
          <div key={env.id} className="card p-6 hover:shadow-lg transition-all duration-200">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-foreground">{env.name}</h3>
                <p className="text-sm text-muted-foreground capitalize">{env.type}</p>
              </div>
              <div className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(env.status)}`}>
                {env.status}
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Health</span>
                <span className={`font-medium ${getHealthColor(env.health)}`}>
                  {env.health}
                </span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Version</span>
                <span className="font-medium text-foreground">{env.version}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">CPU Usage</span>
                <span className="font-medium text-foreground">{env.resources.cpu}%</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Memory</span>
                <span className="font-medium text-foreground">{env.resources.memory}%</span>
              </div>
            </div>
            
            <div className="mt-4 pt-4 border-t border-border">
              <a 
                href={env.url} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-primary hover:text-primary-foreground text-sm font-medium"
              >
                <Globe className="w-4 h-4 inline mr-1" />
                Visit Environment
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="p-6 bg-background min-h-screen text-foreground">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">One-Click Deployment</h1>
            <p className="text-muted-foreground">
              Deploy voice AI agents to any environment with a single click
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <button className="btn btn-outline">
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </button>
            <button className="btn btn-outline">
              <Download className="w-4 h-4 mr-2" />
              Export Logs
            </button>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="mb-6">
        <div className="flex space-x-1 bg-secondary p-1 rounded-lg w-fit">
          {[
            { id: 'deploy', label: 'Deploy', icon: Rocket },
            { id: 'environments', label: 'Environments', icon: Server },
            { id: 'packages', label: 'Packages', icon: Cloud },
            { id: 'jobs', label: 'Deployment Jobs', icon: Activity }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-primary text-primary-foreground shadow-lg'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Deployments</p>
              <p className="text-2xl font-bold text-foreground">{metrics.totalDeployments}</p>
            </div>
            <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
              <Rocket className="w-6 h-6 text-primary" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Success Rate</p>
              <p className="text-2xl font-bold text-green-400">
                {Math.round((metrics.successfulDeployments / metrics.totalDeployments) * 100)}%
              </p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Avg Deploy Time</p>
              <p className="text-2xl font-bold text-foreground">
                {Math.round(metrics.averageDeploymentTime / 60)}m
              </p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Clock className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Uptime</p>
              <p className="text-2xl font-bold text-foreground">{metrics.uptime}%</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      {activeTab === 'deploy' && renderDeployTab()}
      {activeTab === 'environments' && renderEnvironmentsTab()}
      {activeTab === 'packages' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Deployment Packages</h2>
          <p className="text-muted-foreground">Package management interface will be displayed here.</p>
        </div>
      )}
      {activeTab === 'jobs' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Deployment Jobs</h2>
          <p className="text-muted-foreground">Deployment job history and logs will be displayed here.</p>
        </div>
      )}
    </div>
  );
};

export default OneClickDeployment;
