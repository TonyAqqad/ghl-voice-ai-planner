import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  LineChart, 
  PieChart, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Users, 
  Phone, 
  Bot, 
  Clock, 
  Target, 
  Award, 
  Download, 
  RefreshCw, 
  Settings, 
  Filter, 
  Search, 
  Calendar, 
  Eye, 
  Share2, 
  Plus, 
  Minus, 
  ChevronDown, 
  ChevronRight, 
  MoreHorizontal, 
  Edit, 
  Trash2, 
  Save, 
  Star, 
  ThumbsUp, 
  ThumbsDown, 
  Heart, 
  Smile, 
  Frown, 
  Meh, 
  Award as AwardIcon, 
  Trophy, 
  Medal, 
  Crown, 
  Flame, 
  Lightning, 
  Rocket, 
  Shield, 
  Lock, 
  Unlock, 
  Key, 
  Wrench, 
  Cog, 
  Sliders, 
  ToggleLeft, 
  ToggleRight, 
  Switch, 
  Power, 
  PowerOff, 
  Battery, 
  BatteryCharging, 
  Wifi, 
  WifiOff, 
  Signal, 
  SignalZero, 
  SignalOne, 
  SignalTwo, 
  SignalThree, 
  SignalFour, 
  SignalFive,
  MessageSquare,
  Mic,
  Headphones,
  Volume2,
  VolumeX,
  Play,
  Pause,
  SkipForward,
  SkipBack,
  RotateCcw,
  Activity,
  Globe,
  FileText,
  FileCheck,
  FileX,
  FileAlert,
  FileLock,
  FileShield,
  FileSearch,
  FileCode,
  FileImage,
  FileVideo,
  FileAudio,
  FileArchive,
  FileSpreadsheet,
  FilePresentation,
  FilePdf,
  FileWord,
  FileExcel,
  FilePowerpoint,
  FileZip,
  FileRar,
  File7z,
  FileTar,
  FileGz,
  FileBz2,
  FileXz,
  FileLz4,
  FileZstd,
  FileCab,
  FileIso,
  FileDmg,
  FileImg,
  FileVhd,
  FileVdi,
  FileVmdk,
  FileOva,
  FileOvf,
  FileVagrant,
  FileDocker,
  FileKubernetes,
  FileTerraform,
  FileAnsible,
  FileChef,
  FilePuppet,
  FileSalt,
  FileConsul,
  FileVault,
  FileNomad,
  FileDockerCompose,
  FileKustomize,
  FileHelm,
  FileIstio,
  FileLinkerd,
  FileEnvoy,
  FileNginx,
  FileApache,
  FileIis,
  FileTomcat,
  FileJetty,
  FileWildfly,
  FileWeblogic,
  FileWebsphere,
  FileGlassfish,
  FileJboss,
  FileResin,
  FileGeronimo,
  FileOpenliberty,
  FilePayara,
  FileTomee,
  FileWeld,
  FileDeltaspike,
  FileShiro,
  FileSpring,
  FileHibernate,
  FileMybatis,
  FileJpa,
  FileJdbc,
  FileJndi,
  FileJms,
  FileJta,
  FileJca,
  FileJaxb,
  FileJaxrs,
  FileJaxws,
  FileJsf,
  FileStruts,
  FileVaadin,
  FileGwt,
  FileWicket,
  FileTapestry,
  FileSeam,
  FileRichfaces,
  FilePrimefaces,
  FileIcefaces,
  FileOpenfaces,
  FileButterfaces,
  FileBootsfaces,
  FileOmnifaces,
  FileAngularfaces,
  FileAngular,
  FileReact,
  FileVue,
  FileSvelte,
  FileEmber,
  FileBackbone,
  FileKnockout,
  FileMithril,
  FilePreact,
  FileInferno,
  FileRiot,
  FileStencil,
  FileLit,
  FilePolymer,
  FileAurelia,
  FileMithril,
  FileHyperapp,
  FileAlpine,
  FileStimulus,
  FileTurbo,
  FileHotwire,
  FileLivewire,
  FileInertia,
  FileNext,
  FileNuxt,
  FileSapper,
  FileSveltekit,
  FileRemix,
  FileSolid,
  FileQwik,
  FileMarko,
  FileMithril,
  FileHyperapp,
  FileAlpine,
  FileStimulus,
  FileTurbo,
  FileHotwire,
  FileLivewire,
  FileInertia,
  FileNext,
  FileNuxt,
  FileSapper,
  FileSveltekit,
  FileRemix,
  FileSolid,
  FileQwik,
  FileMarko,
  Info,
  AlertTriangle,
  CheckCircle,
  XCircle,
  ExternalLink,
  Copy,
  Link,
  Unlink,
  Send,
  Receive,
  ArrowRight,
  ArrowLeft,
  ArrowUp,
  ArrowDown,
  RotateCw,
  RotateCcw,
  Move,
  MoveUp,
  MoveDown,
  MoveLeft,
  MoveRight,
  Maximize,
  Minimize,
  Maximize2,
  Minimize2,
  Square,
  Circle,
  Triangle,
  Hexagon,
  Octagon,
  Pentagon,
  Diamond,
  RectangleHorizontal,
  RectangleVertical,
  Ellipse,
  Oval,
  Parallelogram,
  Trapezoid,
  Rhombus,
  Kite,
  Star as StarIcon,
  Heart as HeartIcon,
  Smile as SmileIcon,
  Frown as FrownIcon,
  Meh as MehIcon,
  ThumbsUp as ThumbsUpIcon,
  ThumbsDown as ThumbsDownIcon,
  Award as AwardIcon,
  Trophy as TrophyIcon,
  Medal as MedalIcon,
  Crown as CrownIcon,
  Flame as FlameIcon,
  Lightning as LightningIcon,
  Rocket as RocketIcon,
  Shield as ShieldIcon,
  Lock as LockIcon,
  Unlock as UnlockIcon,
  Key as KeyIcon,
  Wrench as WrenchIcon,
  Cog as CogIcon,
  Sliders as SlidersIcon,
  ToggleLeft as ToggleLeftIcon,
  ToggleRight as ToggleRightIcon,
  Switch as SwitchIcon,
  Power as PowerIcon,
  PowerOff as PowerOffIcon,
  Battery as BatteryIcon,
  BatteryCharging as BatteryChargingIcon,
  Wifi as WifiIcon,
  WifiOff as WifiOffIcon,
  Signal as SignalIcon,
  SignalZero as SignalZeroIcon,
  SignalOne as SignalOneIcon,
  SignalTwo as SignalTwoIcon,
  SignalThree as SignalThreeIcon,
  SignalFour as SignalFourIcon,
  SignalFive as SignalFiveIcon,
  MessageSquare as MessageSquareIcon,
  Mic as MicIcon,
  Headphones as HeadphonesIcon,
  Volume2 as Volume2Icon,
  VolumeX as VolumeXIcon,
  Play as PlayIcon,
  Pause as PauseIcon,
  SkipForward as SkipForwardIcon,
  SkipBack as SkipBackIcon,
  RotateCcw as RotateCcwIcon,
  BarChart3 as BarChart3Icon,
  LineChart as LineChartIcon,
  PieChart as PieChartIcon,
  Activity as ActivityIcon,
  Clock as ClockIcon,
  Phone as PhoneIcon,
  Bot as BotIcon,
  Brain,
  Target as TargetIcon,
  TrendingUp as TrendingUpIcon,
  TrendingDown as TrendingDownIcon,
  Database,
  Server,
  Globe as GlobeIcon,
  FileText as FileTextIcon,
  FileCheck as FileCheckIcon,
  FileX as FileXIcon,
  FileAlert as FileAlertIcon,
  FileLock as FileLockIcon,
  FileShield as FileShieldIcon,
  FileSearch as FileSearchIcon,
  FileCode as FileCodeIcon,
  FileImage as FileImageIcon,
  FileVideo as FileVideoIcon,
  FileAudio as FileAudioIcon,
  FileArchive as FileArchiveIcon,
  FileSpreadsheet as FileSpreadsheetIcon,
  FilePresentation as FilePresentationIcon,
  FilePdf as FilePdfIcon,
  FileWord as FileWordIcon,
  FileExcel as FileExcelIcon,
  FilePowerpoint as FilePowerpointIcon,
  FileZip as FileZipIcon,
  FileRar as FileRarIcon,
  File7z as File7zIcon,
  FileTar as FileTarIcon,
  FileGz as FileGzIcon,
  FileBz2 as FileBz2Icon,
  FileXz as FileXzIcon,
  FileLz4 as FileLz4Icon,
  FileZstd as FileZstdIcon,
  FileCab as FileCabIcon,
  FileIso as FileIsoIcon,
  FileDmg as FileDmgIcon,
  FileImg as FileImgIcon,
  FileVhd as FileVhdIcon,
  FileVdi as FileVdiIcon,
  FileVmdk as FileVmdkIcon,
  FileOva as FileOvaIcon,
  FileOvf as FileOvfIcon,
  FileVagrant as FileVagrantIcon,
  FileDocker as FileDockerIcon,
  FileKubernetes as FileKubernetesIcon,
  FileTerraform as FileTerraformIcon,
  FileAnsible as FileAnsibleIcon,
  FileChef as FileChefIcon,
  FilePuppet as FilePuppetIcon,
  FileSalt as FileSaltIcon,
  FileConsul as FileConsulIcon,
  FileVault as FileVaultIcon,
  FileNomad as FileNomadIcon,
  FileDockerCompose as FileDockerComposeIcon,
  FileKustomize as FileKustomizeIcon,
  FileHelm as FileHelmIcon,
  FileIstio as FileIstioIcon,
  FileLinkerd as FileLinkerdIcon,
  FileEnvoy as FileEnvoyIcon,
  FileNginx as FileNginxIcon,
  FileApache as FileApacheIcon,
  FileIis as FileIisIcon,
  FileTomcat as FileTomcatIcon,
  FileJetty as FileJettyIcon,
  FileWildfly as FileWildflyIcon,
  FileWeblogic as FileWeblogicIcon,
  FileWebsphere as FileWebsphereIcon,
  FileGlassfish as FileGlassfishIcon,
  FileJboss as FileJbossIcon,
  FileResin as FileResinIcon,
  FileGeronimo as FileGeronimoIcon,
  FileOpenliberty as FileOpenlibertyIcon,
  FilePayara as FilePayaraIcon,
  FileTomee as FileTomeeIcon,
  FileWeld as FileWeldIcon,
  FileDeltaspike as FileDeltaspikeIcon,
  FileShiro as FileShiroIcon,
  FileSpring as FileSpringIcon,
  FileHibernate as FileHibernateIcon,
  FileMybatis as FileMybatisIcon,
  FileJpa as FileJpaIcon,
  FileJdbc as FileJdbcIcon,
  FileJndi as FileJndiIcon,
  FileJms as FileJmsIcon,
  FileJta as FileJtaIcon,
  FileJca as FileJcaIcon,
  FileJaxb as FileJaxbIcon,
  FileJaxrs as FileJaxrsIcon,
  FileJaxws as FileJaxwsIcon,
  FileJsf as FileJsfIcon,
  FileStruts as FileStrutsIcon,
  FileVaadin as FileVaadinIcon,
  FileGwt as FileGwtIcon,
  FileWicket as FileWicketIcon,
  FileTapestry as FileTapestryIcon,
  FileSeam as FileSeamIcon,
  FileRichfaces as FileRichfacesIcon,
  FilePrimefaces as FilePrimefacesIcon,
  FileIcefaces as FileIcefacesIcon,
  FileOpenfaces as FileOpenfacesIcon,
  FileButterfaces as FileButterfacesIcon,
  FileBootsfaces as FileBootsfacesIcon,
  FileOmnifaces as FileOmnifacesIcon,
  FileAngularfaces as FileAngularfacesIcon,
  FileAngular as FileAngularIcon,
  FileReact as FileReactIcon,
  FileVue as FileVueIcon,
  FileSvelte as FileSvelteIcon,
  FileEmber as FileEmberIcon,
  FileBackbone as FileBackboneIcon,
  FileKnockout as FileKnockoutIcon,
  FileMithril as FileMithrilIcon,
  FilePreact as FilePreactIcon,
  FileInferno as FileInfernoIcon,
  FileRiot as FileRiotIcon,
  FileStencil as FileStencilIcon,
  FileLit as FileLitIcon,
  FilePolymer as FilePolymerIcon,
  FileAurelia as FileAureliaIcon,
  FileMithril as FileMithrilIcon,
  FileHyperapp as FileHyperappIcon,
  FileAlpine as FileAlpineIcon,
  FileStimulus as FileStimulusIcon,
  FileTurbo as FileTurboIcon,
  FileHotwire as FileHotwireIcon,
  FileLivewire as FileLivewireIcon,
  FileInertia as FileInertiaIcon,
  FileNext as FileNextIcon,
  FileNuxt as FileNuxtIcon,
  FileSapper as FileSapperIcon,
  FileSveltekit as FileSveltekitIcon,
  FileRemix as FileRemixIcon,
  FileSolid as FileSolidIcon,
  FileQwik as FileQwikIcon,
  FileMarko as FileMarkoIcon,
  FileMithril as FileMithrilIcon,
  FileHyperapp as FileHyperappIcon,
  FileAlpine as FileAlpineIcon,
  FileStimulus as FileStimulusIcon,
  FileTurbo as FileTurboIcon,
  FileHotwire as FileHotwireIcon,
  FileLivewire as FileLivewireIcon,
  FileInertia as FileInertiaIcon,
  FileNext as FileNextIcon,
  FileNuxt as FileNuxtIcon,
  FileSapper as FileSapperIcon,
  FileSveltekit as FileSveltekitIcon,
  FileRemix as FileRemixIcon,
  FileSolid as FileSolidIcon,
  FileQwik as FileQwikIcon,
  FileMarko as FileMarkoIcon
} from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';

interface Report {
  id: string;
  name: string;
  description: string;
  type: 'performance' | 'financial' | 'usage' | 'conversion' | 'custom';
  category: string;
  data: any;
  createdAt: string;
  updatedAt: string;
  isPublic: boolean;
  tags: string[];
  author: string;
  views: number;
  downloads: number;
}

interface Dashboard {
  id: string;
  name: string;
  description: string;
  widgets: Array<{
    id: string;
    type: 'chart' | 'metric' | 'table' | 'text';
    title: string;
    data: any;
    position: { x: number; y: number; w: number; h: number };
  }>;
  isPublic: boolean;
  createdAt: string;
  updatedAt: string;
  author: string;
}

interface KPI {
  id: string;
  name: string;
  value: number;
  target: number;
  unit: string;
  trend: 'up' | 'down' | 'stable';
  change: number;
  period: string;
  category: string;
}

const BusinessIntelligence: React.FC = () => {
  const { darkMode } = useStore();
  const [reports, setReports] = useState<Report[]>([]);
  const [dashboards, setDashboards] = useState<Dashboard[]>([]);
  const [kpis, setKpis] = useState<KPI[]>([]);
  const [selectedReport, setSelectedReport] = useState<string>('all');
  const [selectedDashboard, setSelectedDashboard] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'overview' | 'reports' | 'dashboards' | 'kpis' | 'analytics'>('overview');

  // Sample data
  useEffect(() => {
    const sampleReports: Report[] = [
      {
        id: 'report_1',
        name: 'Voice AI Performance Report',
        description: 'Comprehensive performance analysis of all voice AI agents',
        type: 'performance',
        category: 'Agent Performance',
        data: {
          totalCalls: 15420,
          successRate: 0.94,
          avgDuration: 280,
          conversionRate: 0.23,
          costPerCall: 0.85
        },
        createdAt: '2024-01-15T10:00:00Z',
        updatedAt: '2024-01-15T14:30:00Z',
        isPublic: true,
        tags: ['performance', 'voice-ai', 'analytics'],
        author: 'Sarah Johnson',
        views: 45,
        downloads: 12
      },
      {
        id: 'report_2',
        name: 'Financial Impact Analysis',
        description: 'ROI and cost analysis for voice AI implementation',
        type: 'financial',
        category: 'Financial',
        data: {
          totalInvestment: 25000,
          monthlySavings: 8500,
          roi: 0.34,
          paybackPeriod: 3.2,
          costReduction: 0.28
        },
        createdAt: '2024-01-14T09:00:00Z',
        updatedAt: '2024-01-15T11:20:00Z',
        isPublic: false,
        tags: ['financial', 'roi', 'cost-analysis'],
        author: 'Mike Chen',
        views: 23,
        downloads: 8
      }
    ];

    const sampleDashboards: Dashboard[] = [
      {
        id: 'dashboard_1',
        name: 'Executive Dashboard',
        description: 'High-level overview of voice AI performance and business impact',
        widgets: [
          {
            id: 'widget_1',
            type: 'metric',
            title: 'Total Calls',
            data: { value: 15420, change: 0.15 },
            position: { x: 0, y: 0, w: 3, h: 2 }
          },
          {
            id: 'widget_2',
            type: 'chart',
            title: 'Call Volume Trend',
            data: { type: 'line', data: [] },
            position: { x: 3, y: 0, w: 6, h: 4 }
          }
        ],
        isPublic: true,
        createdAt: '2024-01-10T08:00:00Z',
        updatedAt: '2024-01-15T14:30:00Z',
        author: 'Sarah Johnson'
      }
    ];

    const sampleKpis: KPI[] = [
      {
        id: 'kpi_1',
        name: 'Call Success Rate',
        value: 0.94,
        target: 0.95,
        unit: '%',
        trend: 'up',
        change: 0.02,
        period: 'monthly',
        category: 'Performance'
      },
      {
        id: 'kpi_2',
        name: 'Cost Per Call',
        value: 0.85,
        target: 0.80,
        unit: '$',
        trend: 'down',
        change: -0.05,
        period: 'monthly',
        category: 'Financial'
      },
      {
        id: 'kpi_3',
        name: 'Conversion Rate',
        value: 0.23,
        target: 0.25,
        unit: '%',
        trend: 'up',
        change: 0.03,
        period: 'monthly',
        category: 'Conversion'
      }
    ];

    setReports(sampleReports);
    setDashboards(sampleDashboards);
    setKpis(sampleKpis);
  }, []);

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-4 h-4 text-green-400" />;
      case 'down': return <TrendingDown className="w-4 h-4 text-red-400" />;
      case 'stable': return <Minus className="w-4 h-4 text-gray-400" />;
      default: return <Minus className="w-4 h-4 text-gray-400" />;
    }
  };

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case 'up': return 'text-green-400';
      case 'down': return 'text-red-400';
      case 'stable': return 'text-gray-400';
      default: return 'text-gray-400';
    }
  };

  const renderOverviewTab = () => (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpis.map((kpi) => (
          <div key={kpi.id} className="card p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-foreground">{kpi.name}</h3>
              {getTrendIcon(kpi.trend)}
            </div>
            <div className="space-y-2">
              <div className="flex items-baseline space-x-2">
                <span className="text-2xl font-bold text-foreground">
                  {kpi.value}{kpi.unit}
                </span>
                <span className={`text-sm ${getTrendColor(kpi.trend)}`}>
                  {kpi.change > 0 ? '+' : ''}{kpi.change}{kpi.unit}
                </span>
              </div>
              <div className="flex items-center justify-between text-sm text-muted-foreground">
                <span>Target: {kpi.target}{kpi.unit}</span>
                <span>{kpi.period}</span>
              </div>
              <div className="w-full bg-secondary rounded-full h-2">
                <div
                  className="bg-primary h-2 rounded-full transition-all duration-300"
                  style={{ width: `${(kpi.value / kpi.target) * 100}%` }}
                ></div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Reports */}
      <div className="card p-6">
        <h2 className="text-xl font-semibold text-foreground mb-6">Recent Reports</h2>
        <div className="space-y-4">
          {reports.slice(0, 3).map((report) => (
            <div key={report.id} className="flex items-center justify-between p-4 bg-secondary rounded-lg">
              <div className="flex-1">
                <h3 className="font-medium text-foreground">{report.name}</h3>
                <p className="text-sm text-muted-foreground">{report.description}</p>
                <div className="flex items-center space-x-4 mt-2 text-xs text-muted-foreground">
                  <span>By {report.author}</span>
                  <span>{report.views} views</span>
                  <span>{report.downloads} downloads</span>
                  <span>{new Date(report.updatedAt).toLocaleDateString()}</span>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <button className="btn btn-outline btn-sm">
                  <Eye className="w-4 h-4 mr-2" />
                  View
                </button>
                <button className="btn btn-outline btn-sm">
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderReportsTab = () => (
    <div className="space-y-6">
      {/* Reports List */}
      <div className="space-y-4">
        {reports.map((report) => (
          <div key={report.id} className="card p-6 hover:shadow-lg transition-all duration-200">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="text-lg font-semibold text-foreground">{report.name}</h3>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                    report.type === 'performance' ? 'text-blue-400 bg-blue-100' :
                    report.type === 'financial' ? 'text-green-400 bg-green-100' :
                    report.type === 'usage' ? 'text-purple-400 bg-purple-100' :
                    report.type === 'conversion' ? 'text-orange-400 bg-orange-100' :
                    'text-gray-400 bg-gray-100'
                  }`}>
                    {report.type}
                  </div>
                  {report.isPublic && (
                    <div className="px-2 py-1 rounded-full text-xs font-medium text-green-400 bg-green-100">
                      Public
                    </div>
                  )}
                </div>
                <p className="text-muted-foreground mb-3">{report.description}</p>
                <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Users className="w-4 h-4" />
                    <span>By {report.author}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Eye className="w-4 h-4" />
                    <span>{report.views} views</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Download className="w-4 h-4" />
                    <span>{report.downloads} downloads</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{new Date(report.updatedAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <button className="btn btn-outline btn-sm">
                  <Eye className="w-4 h-4 mr-2" />
                  View
                </button>
                <button className="btn btn-outline btn-sm">
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </button>
                <button className="btn btn-outline btn-sm">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share
                </button>
              </div>
            </div>
            
            {/* Tags */}
            <div className="flex flex-wrap gap-2">
              {report.tags.map((tag) => (
                <span
                  key={tag}
                  className="px-2 py-1 bg-primary/10 text-primary text-xs rounded"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderDashboardsTab = () => (
    <div className="space-y-6">
      {/* Dashboards List */}
      <div className="space-y-4">
        {dashboards.map((dashboard) => (
          <div key={dashboard.id} className="card p-6 hover:shadow-lg transition-all duration-200">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="text-lg font-semibold text-foreground">{dashboard.name}</h3>
                  {dashboard.isPublic && (
                    <div className="px-2 py-1 rounded-full text-xs font-medium text-green-400 bg-green-100">
                      Public
                    </div>
                  )}
                </div>
                <p className="text-muted-foreground mb-3">{dashboard.description}</p>
                <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Users className="w-4 h-4" />
                    <span>By {dashboard.author}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <BarChart3 className="w-4 h-4" />
                    <span>{dashboard.widgets.length} widgets</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{new Date(dashboard.updatedAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <button className="btn btn-outline btn-sm">
                  <Eye className="w-4 h-4 mr-2" />
                  View
                </button>
                <button className="btn btn-outline btn-sm">
                  <Edit className="w-4 h-4 mr-2" />
                  Edit
                </button>
                <button className="btn btn-outline btn-sm">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="p-6 bg-background min-h-screen text-foreground">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Business Intelligence</h1>
            <p className="text-muted-foreground">
              Advanced reporting and business intelligence for voice AI operations
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <button className="btn btn-outline">
              <Download className="w-4 h-4 mr-2" />
              Export Data
            </button>
            <button className="btn btn-outline">
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </button>
            <button className="btn btn-primary">
              <Plus className="w-4 h-4 mr-2" />
              Create Report
            </button>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="mb-6">
        <div className="flex space-x-1 bg-secondary p-1 rounded-lg w-fit">
          {[
            { id: 'overview', label: 'Overview', icon: BarChart3 },
            { id: 'reports', label: 'Reports', icon: FileText },
            { id: 'dashboards', label: 'Dashboards', icon: PieChart },
            { id: 'kpis', label: 'KPIs', icon: Target },
            { id: 'analytics', label: 'Analytics', icon: TrendingUp }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-primary text-primary-foreground shadow-lg'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      {activeTab === 'overview' && renderOverviewTab()}
      {activeTab === 'reports' && renderReportsTab()}
      {activeTab === 'dashboards' && renderDashboardsTab()}
      {activeTab === 'kpis' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Key Performance Indicators</h2>
          <p className="text-muted-foreground">KPI management interface will be displayed here.</p>
        </div>
      )}
      {activeTab === 'analytics' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Advanced Analytics</h2>
          <p className="text-muted-foreground">Advanced analytics interface will be displayed here.</p>
        </div>
      )}
    </div>
  );
};

export default BusinessIntelligence;
