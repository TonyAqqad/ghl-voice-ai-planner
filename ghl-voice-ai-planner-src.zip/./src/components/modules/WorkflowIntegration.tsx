import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, 
  Trash2, 
  Eye, 
  Download, 
  Plus, 
  Settings,
  Zap,
  Phone,
  MessageSquare,
  User,
  Calendar,
  Mail,
  Database,
  Webhook,
  Clock,
  GitBranch,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Activity
} from 'lucide-react';

interface WorkflowNode {
  id: string;
  type: 'trigger' | 'action' | 'condition';
  name: string;
  x: number;
  y: number;
  config?: any;
}

interface Workflow {
  id: string;
  name: string;
  status: 'draft' | 'active' | 'error';
  createdAt: Date;
  nodes: WorkflowNode[];
  connections: Array<{ from: string; to: string }>;
}

interface WorkflowTrigger {
  id: string;
  name: string;
  type: string;
  description: string;
  status: 'active' | 'inactive';
  config: any;
}

interface WorkflowAction {
  id: string;
  name: string;
  category: 'ghl' | 'custom';
  description: string;
  config: any;
}

const WorkflowIntegration: React.FC = () => {
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [currentWorkflow, setCurrentWorkflow] = useState<Workflow | null>(null);
  const [selectedNode, setSelectedNode] = useState<WorkflowNode | null>(null);
  const [activeTab, setActiveTab] = useState<'designer' | 'triggers' | 'actions' | 'templates'>('designer');
  const [logs, setLogs] = useState<Array<{ type: string; message: string; timestamp: string }>>([
    { type: 'info', message: 'System initialized. Ready for workflow design.', timestamp: new Date().toLocaleTimeString() }
  ]);
  const [isDragging, setIsDragging] = useState(false);
  const canvasRef = useRef<HTMLDivElement>(null);

  const nodeTypes = [
    { type: 'trigger', name: 'Voice Call', icon: Phone, color: 'bg-green-500', description: 'Starts workflow on incoming call' },
    { type: 'trigger', name: 'SMS Received', icon: MessageSquare, color: 'bg-blue-500', description: 'Triggered when SMS is received' },
    { type: 'trigger', name: 'Contact Created', icon: User, color: 'bg-purple-500', description: 'Triggered when contact is created' },
    { type: 'action', name: 'Send SMS', icon: MessageSquare, color: 'bg-blue-500', description: 'Send text message to contact' },
    { type: 'action', name: 'Create Task', icon: Calendar, color: 'bg-orange-500', description: 'Create follow-up task' },
    { type: 'action', name: 'Send Email', icon: Mail, color: 'bg-red-500', description: 'Send automated email' },
    { type: 'action', name: 'Update Contact', icon: User, color: 'bg-green-500', description: 'Update contact information' },
    { type: 'action', name: 'Webhook Call', icon: Webhook, color: 'bg-purple-500', description: 'Call external API' },
    { type: 'condition', name: 'If/Else', icon: GitBranch, color: 'bg-yellow-500', description: 'Branch based on condition' },
    { type: 'action', name: 'Delay', icon: Clock, color: 'bg-gray-500', description: 'Wait for specified time' },
  ];

  const triggers: WorkflowTrigger[] = [
    { id: '1', name: 'Voice Call Received', type: 'voice', description: 'Triggered when a call is received on configured phone number', status: 'active', config: {} },
    { id: '2', name: 'SMS Received', type: 'sms', description: 'Triggered when an SMS is received', status: 'inactive', config: {} },
    { id: '3', name: 'Contact Created', type: 'contact', description: 'Triggered when a new contact is created in GHL', status: 'inactive', config: {} },
    { id: '4', name: 'Opportunity Updated', type: 'opportunity', description: 'Triggered when an opportunity status changes', status: 'inactive', config: {} },
  ];

  const actions: WorkflowAction[] = [
    { id: '1', name: 'Update Contact', category: 'ghl', description: 'Update contact fields and tags', config: {} },
    { id: '2', name: 'Create Task', category: 'ghl', description: 'Create follow-up tasks and appointments', config: {} },
    { id: '3', name: 'Send Email', category: 'ghl', description: 'Send automated emails', config: {} },
    { id: '4', name: 'Send SMS', category: 'ghl', description: 'Send text messages', config: {} },
    { id: '5', name: 'Add to Campaign', category: 'ghl', description: 'Add contact to marketing campaign', config: {} },
    { id: '6', name: 'Webhook Call', category: 'custom', description: 'Call external API endpoint', config: {} },
    { id: '7', name: 'Database Query', category: 'custom', description: 'Execute custom database query', config: {} },
    { id: '8', name: 'Delay', category: 'custom', description: 'Wait for specified time', config: {} },
    { id: '9', name: 'Conditional Logic', category: 'custom', description: 'Branch workflow based on conditions', config: {} },
    { id: '10', name: 'Voice AI Response', category: 'custom', description: 'Generate AI response and speak', config: {} },
  ];

  const templates = [
    { name: 'Lead Qualification', description: 'Automatically qualify leads from voice calls', category: 'sales' },
    { name: 'Appointment Booking', description: 'Schedule appointments through voice interaction', category: 'scheduling' },
    { name: 'Customer Support', description: 'Handle customer inquiries and support requests', category: 'support' },
    { name: 'Follow-up Sequence', description: 'Automated follow-up after initial contact', category: 'marketing' },
    { name: 'Survey Collection', description: 'Collect feedback and survey responses', category: 'research' },
    { name: 'Payment Processing', description: 'Handle payments and billing inquiries', category: 'billing' },
  ];

  useEffect(() => {
    loadWorkflows();
  }, []);

  const loadWorkflows = () => {
    const saved = localStorage.getItem('ghl-workflows');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setWorkflows(parsed.map((w: any) => ({
          ...w,
          createdAt: new Date(w.createdAt)
        })));
      } catch (error) {
        console.error('Failed to load workflows:', error);
      }
    }
  };

  const saveWorkflows = (newWorkflows: Workflow[]) => {
    localStorage.setItem('ghl-workflows', JSON.stringify(newWorkflows));
    setWorkflows(newWorkflows);
  };

  const addLog = (type: string, message: string) => {
    const newLog = {
      type,
      message,
      timestamp: new Date().toLocaleTimeString()
    };
    setLogs(prev => [...prev, newLog]);
  };

  const createWorkflow = () => {
    const name = prompt('Enter workflow name:');
    if (name) {
      const workflow: Workflow = {
        id: Date.now().toString(),
        name,
        status: 'draft',
        createdAt: new Date(),
        nodes: [],
        connections: []
      };
      
      const newWorkflows = [workflow, ...workflows];
      saveWorkflows(newWorkflows);
      setCurrentWorkflow(workflow);
      addLog('success', `Created workflow: ${name}`);
    }
  };

  const testWorkflow = () => {
    if (!currentWorkflow) {
      alert('Please create or select a workflow first');
      return;
    }
    
    addLog('info', `Testing workflow: ${currentWorkflow.name}`);
    // Simulate workflow execution
    setTimeout(() => {
      addLog('success', 'Workflow test completed successfully');
    }, 2000);
  };

  const exportWorkflow = () => {
    if (!currentWorkflow) {
      alert('Please create or select a workflow first');
      return;
    }
    
    const exportData = {
      workflow: currentWorkflow,
      nodes: currentWorkflow.nodes,
      connections: currentWorkflow.connections
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${currentWorkflow.name}_workflow.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    addLog('success', `Exported workflow: ${currentWorkflow.name}`);
  };

  const clearLogs = () => {
    setLogs([{ type: 'info', message: 'Logs cleared.', timestamp: new Date().toLocaleTimeString() }]);
  };

  const handleDragStart = (e: React.DragEvent, nodeType: any) => {
    e.dataTransfer.setData('application/json', JSON.stringify(nodeType));
    setIsDragging(true);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (!currentWorkflow) {
      addLog('error', 'Please create a workflow first');
      return;
    }

    const nodeData = JSON.parse(e.dataTransfer.getData('application/json'));
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const newNode: WorkflowNode = {
      id: Date.now().toString(),
      type: nodeData.type,
      name: nodeData.name,
      x: x - 100, // Center the node
      y: y - 25,
      config: {}
    };

    const updatedWorkflow = {
      ...currentWorkflow,
      nodes: [...currentWorkflow.nodes, newNode]
    };

    setCurrentWorkflow(updatedWorkflow);
    const updatedWorkflows = workflows.map(w => w.id === currentWorkflow.id ? updatedWorkflow : w);
    saveWorkflows(updatedWorkflows);
    
    addLog('info', `Added ${nodeData.name} node to workflow`);
  };

  const selectNode = (node: WorkflowNode) => {
    setSelectedNode(node);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-400';
      case 'draft': return 'text-yellow-400';
      case 'error': return 'text-red-400';
      default: return 'text-muted-foreground';
    }
  };

  const getLogColor = (type: string) => {
    switch (type) {
      case 'error': return 'text-red-400';
      case 'warning': return 'text-yellow-400';
      case 'success': return 'text-green-400';
      case 'info': return 'text-blue-400';
      default: return 'text-muted-foreground';
    }
  };

  const stats = {
    total: workflows.length,
    active: workflows.filter(w => w.status === 'active').length,
    draft: workflows.filter(w => w.status === 'draft').length,
    error: workflows.filter(w => w.status === 'error').length
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground gradient-text">Workflow Integration</h1>
          <p className="text-muted-foreground mt-2">Design and manage workflow automation for your voice AI agents</p>
        </div>
        <div className="flex gap-2">
          <button onClick={createWorkflow} className="btn btn-primary flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Create Workflow
          </button>
          <button onClick={testWorkflow} className="btn btn-outline flex items-center gap-2">
            <Play className="w-4 h-4" />
            Test Workflow
          </button>
          <button onClick={exportWorkflow} className="btn btn-outline flex items-center gap-2">
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="card p-6 text-center">
          <div className="text-3xl font-bold gradient-text mb-2">{stats.total}</div>
          <div className="text-sm text-muted-foreground">Total Workflows</div>
        </div>
        <div className="card p-6 text-center">
          <div className="text-3xl font-bold text-green-400 mb-2">{stats.active}</div>
          <div className="text-sm text-muted-foreground">Active</div>
        </div>
        <div className="card p-6 text-center">
          <div className="text-3xl font-bold text-yellow-400 mb-2">{stats.draft}</div>
          <div className="text-sm text-muted-foreground">Draft</div>
        </div>
        <div className="card p-6 text-center">
          <div className="text-3xl font-bold text-red-400 mb-2">{stats.error}</div>
          <div className="text-sm text-muted-foreground">Errors</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-border">
        {[
          { id: 'designer', label: 'Workflow Designer', icon: Settings },
          { id: 'triggers', label: 'Triggers', icon: Zap },
          { id: 'actions', label: 'Actions', icon: Activity },
          { id: 'templates', label: 'Templates', icon: Download }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-2 px-4 py-2 border-b-2 transition-colors ${
              activeTab === tab.id
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'designer' && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Node Palette */}
          <div className="card p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Node Palette</h3>
            <div className="space-y-3">
              {nodeTypes.map((nodeType, index) => (
                <div
                  key={index}
                  draggable
                  onDragStart={(e) => handleDragStart(e, nodeType)}
                  className="workflow-node p-3 cursor-move hover:border-primary transition-colors"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <div className={`w-3 h-3 rounded-full ${nodeType.color}`}></div>
                    <span className="text-sm font-medium">{nodeType.name}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">{nodeType.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Workflow Canvas */}
          <div className="lg:col-span-3">
            <div className="card p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Workflow Canvas</h3>
              <div
                ref={canvasRef}
                onDragOver={handleDragOver}
                onDrop={handleDrop}
                className={`workflow-canvas min-h-96 border-2 border-dashed rounded-lg p-4 relative ${
                  isDragging ? 'border-primary bg-primary/5' : 'border-border'
                }`}
              >
                {currentWorkflow?.nodes.length === 0 ? (
                  <div className="text-center text-muted-foreground py-12">
                    <p className="text-lg mb-2">Drag nodes from the palette to start building your workflow</p>
                    <p className="text-sm">Connect nodes by dragging from one output to another input</p>
                  </div>
                ) : (
                  currentWorkflow?.nodes.map((node) => (
                    <div
                      key={node.id}
                      onClick={() => selectNode(node)}
                      className={`workflow-node absolute p-3 cursor-pointer transition-all ${
                        selectedNode?.id === node.id ? 'border-primary bg-primary/10' : 'hover:border-primary'
                      }`}
                      style={{ left: `${node.x}px`, top: `${node.y}px`, width: '200px' }}
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <div className={`w-3 h-3 rounded-full ${
                          node.type === 'trigger' ? 'bg-green-500' :
                          node.type === 'action' ? 'bg-blue-500' : 'bg-yellow-500'
                        }`}></div>
                        <span className="text-sm font-medium">{node.name}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">Click to configure</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'triggers' && (
        <div className="card p-6">
          <h3 className="text-xl font-semibold text-foreground mb-4">Workflow Triggers</h3>
          <div className="space-y-4">
            {triggers.map((trigger) => (
              <div key={trigger.id} className="card p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-foreground">{trigger.name}</h4>
                    <p className="text-sm text-muted-foreground">{trigger.description}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-sm font-medium ${getStatusColor(trigger.status)}`}>
                      {trigger.status.toUpperCase()}
                    </span>
                    <button className="btn btn-outline btn-sm">Configure</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'actions' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="card p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">GHL Actions</h3>
            <div className="space-y-3">
              {actions.filter(a => a.category === 'ghl').map((action) => (
                <div key={action.id} className="card p-3">
                  <h4 className="font-medium text-foreground">{action.name}</h4>
                  <p className="text-sm text-muted-foreground">{action.description}</p>
                </div>
              ))}
            </div>
          </div>
          
          <div className="card p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Custom Actions</h3>
            <div className="space-y-3">
              {actions.filter(a => a.category === 'custom').map((action) => (
                <div key={action.id} className="card p-3">
                  <h4 className="font-medium text-foreground">{action.name}</h4>
                  <p className="text-sm text-muted-foreground">{action.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'templates' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {templates.map((template, index) => (
            <div key={index} className="card p-6">
              <h3 className="text-lg font-semibold text-foreground mb-2">{template.name}</h3>
              <p className="text-sm text-muted-foreground mb-4">{template.description}</p>
              <div className="flex gap-2">
                <button className="btn btn-primary btn-sm">Use Template</button>
                <button className="btn btn-outline btn-sm">Preview</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Workflow Logs */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold text-foreground">Workflow Execution Logs</h3>
          <button onClick={clearLogs} className="btn btn-outline flex items-center gap-2">
            <Trash2 className="w-4 h-4" />
            Clear Logs
          </button>
        </div>
        <div className="bg-muted p-4 rounded-md h-64 overflow-y-auto font-mono text-sm">
          {logs.map((log, index) => (
            <div key={index} className={`py-1 ${getLogColor(log.type)}`}>
              [{log.timestamp}] {log.message}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default WorkflowIntegration;
