import React from 'react';
import { TestTube, Play, Mic } from 'lucide-react';

const TestingSimulator: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Testing Simulator</h1>
          <p className="text-muted-foreground mt-2">
            Test your voice agents and workflows before deployment
          </p>
        </div>
        <button className="btn btn-primary flex items-center space-x-2">
          <Play className="w-4 h-4" />
          <span>Start Test</span>
        </button>
      </div>
      
      <div className="card">
        <div className="card-content text-center py-12">
          <TestTube className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">
            Voice Agent Testing
          </h3>
          <p className="text-muted-foreground">
            Simulate calls and test your voice agents with real-time feedback
          </p>
        </div>
      </div>
    </div>
  );
};

export default TestingSimulator;
