import React from 'react';
import { Database, Plus } from 'lucide-react';

const CustomFieldsManager: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Custom Fields & Values</h1>
          <p className="text-muted-foreground mt-2">
            Define custom fields and manage custom values for your voice agents
          </p>
        </div>
        <button className="btn btn-primary flex items-center space-x-2">
          <Plus className="w-4 h-4" />
          <span>Add Field</span>
        </button>
      </div>
      
      <div className="card">
        <div className="card-content text-center py-12">
          <Database className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">
            Custom Fields Manager
          </h3>
          <p className="text-muted-foreground">
            Create and manage custom fields for contacts, opportunities, and companies
          </p>
        </div>
      </div>
    </div>
  );
};

export default CustomFieldsManager;
