import React, { useState, useEffect } from 'react';
import { 
  Brain, 
  Zap, 
  Settings, 
  BarChart3, 
  Play, 
  Pause, 
  RefreshCw, 
  CheckCircle, 
  AlertTriangle, 
  Clock, 
  Target, 
  TrendingUp,
  Activity,
  Cpu,
  Database,
  Network,
  Shield,
  Eye,
  Edit,
  Trash2,
  Plus,
  Filter,
  Search
} from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';

interface AutomationRule {
  id: string;
  name: string;
  description: string;
  trigger: {
    type: 'call_start' | 'call_end' | 'intent_detected' | 'transfer_requested' | 'custom';
    conditions: Record<string, any>;
  };
  actions: Array<{
    type: 'update_contact' | 'send_webhook' | 'create_task' | 'send_notification' | 'update_pipeline' | 'add_tag';
    config: Record<string, any>;
  }>;
  conditions: Array<{
    field: string;
    operator: 'equals' | 'contains' | 'greater_than' | 'less_than' | 'exists' | 'not_exists';
    value: any;
  }>;
  priority: number;
  enabled: boolean;
  lastExecuted: string | null;
  executionCount: number;
  successRate: number;
}

interface AutomationAnalytics {
  totalRules: number;
  activeRules: number;
  executionsToday: number;
  successRate: number;
  topPerformingRules: Array<{
    id: string;
    name: string;
    executions: number;
    successRate: number;
  }>;
  recentExecutions: Array<{
    id: string;
    ruleName: string;
    timestamp: string;
    status: 'success' | 'failed' | 'pending';
    duration: number;
  }>;
}

const IntelligentAutomationEngine: React.FC = () => {
  const { darkMode } = useStore();
  const [automationRules, setAutomationRules] = useState<AutomationRule[]>([]);
  const [analytics, setAnalytics] = useState<AutomationAnalytics>({
    totalRules: 0,
    activeRules: 0,
    executionsToday: 0,
    successRate: 0,
    topPerformingRules: [],
    recentExecutions: []
  });
  const [activeTab, setActiveTab] = useState<'rules' | 'analytics' | 'logs' | 'settings'>('rules');
  const [isCreatingRule, setIsCreatingRule] = useState(false);
  const [selectedRule, setSelectedRule] = useState<AutomationRule | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'enabled' | 'disabled'>('all');

  // Sample data - in real app this would come from API
  useEffect(() => {
    const sampleRules: AutomationRule[] = [
      {
        id: 'rule_1',
        name: 'High-Value Lead Follow-up',
        description: 'Automatically create follow-up task for leads with high intent scores',
        trigger: {
          type: 'call_end',
          conditions: { minDuration: 120, intentScore: 0.8 }
        },
        actions: [
          {
            type: 'create_task',
            config: { title: 'Follow up with high-value lead', assignee: 'sales_team', dueDate: '+1 day' }
          },
          {
            type: 'add_tag',
            config: { tag: 'High Priority Lead' }
          }
        ],
        conditions: [
          { field: 'intent_score', operator: 'greater_than', value: 0.8 },
          { field: 'call_duration', operator: 'greater_than', value: 120 }
        ],
        priority: 1,
        enabled: true,
        lastExecuted: '2024-01-15T10:30:00Z',
        executionCount: 45,
        successRate: 0.95
      },
      {
        id: 'rule_2',
        name: 'Emergency Transfer Alert',
        description: 'Send immediate notification when emergency transfer is requested',
        trigger: {
          type: 'transfer_requested',
          conditions: { transferType: 'emergency' }
        },
        actions: [
          {
            type: 'send_notification',
            config: { 
              type: 'sms', 
              message: 'Emergency transfer requested for {{contact_name}}', 
              recipients: ['manager@company.com'] 
            }
          },
          {
            type: 'send_webhook',
            config: { 
              url: 'https://api.company.com/emergency-alert',
              method: 'POST',
              payload: { contact_id: '{{contact_id}}', urgency: 'high' }
            }
          }
        ],
        conditions: [
          { field: 'transfer_type', operator: 'equals', value: 'emergency' }
        ],
        priority: 1,
        enabled: true,
        lastExecuted: '2024-01-15T09:15:00Z',
        executionCount: 12,
        successRate: 1.0
      },
      {
        id: 'rule_3',
        name: 'Appointment Booking Confirmation',
        description: 'Send confirmation email and SMS when appointment is booked',
        trigger: {
          type: 'intent_detected',
          conditions: { intent: 'book_appointment' }
        },
        actions: [
          {
            type: 'send_notification',
            config: { 
              type: 'email', 
              template: 'appointment_confirmation',
              to: '{{contact_email}}'
            }
          },
          {
            type: 'update_contact',
            config: { 
              field: 'appointment_status', 
              value: 'confirmed' 
            }
          }
        ],
        conditions: [
          { field: 'intent', operator: 'equals', value: 'book_appointment' }
        ],
        priority: 2,
        enabled: true,
        lastExecuted: '2024-01-15T11:45:00Z',
        executionCount: 78,
        successRate: 0.92
      }
    ];

    setAutomationRules(sampleRules);
    
    // Calculate analytics
    const activeRules = sampleRules.filter(rule => rule.enabled).length;
    const totalExecutions = sampleRules.reduce((sum, rule) => sum + rule.executionCount, 0);
    const avgSuccessRate = sampleRules.reduce((sum, rule) => sum + rule.successRate, 0) / sampleRules.length;
    
    setAnalytics({
      totalRules: sampleRules.length,
      activeRules,
      executionsToday: totalExecutions,
      successRate: avgSuccessRate,
      topPerformingRules: sampleRules
        .sort((a, b) => b.executionCount - a.executionCount)
        .slice(0, 5)
        .map(rule => ({
          id: rule.id,
          name: rule.name,
          executions: rule.executionCount,
          successRate: rule.successRate
        })),
      recentExecutions: [
        {
          id: 'exec_1',
          ruleName: 'High-Value Lead Follow-up',
          timestamp: '2024-01-15T10:30:00Z',
          status: 'success',
          duration: 150
        },
        {
          id: 'exec_2',
          ruleName: 'Emergency Transfer Alert',
          timestamp: '2024-01-15T09:15:00Z',
          status: 'success',
          duration: 50
        },
        {
          id: 'exec_3',
          ruleName: 'Appointment Booking Confirmation',
          timestamp: '2024-01-15T11:45:00Z',
          status: 'failed',
          duration: 200
        }
      ]
    });
  }, []);

  const filteredRules = automationRules.filter(rule => {
    const matchesSearch = rule.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         rule.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || 
                         (filterStatus === 'enabled' && rule.enabled) ||
                         (filterStatus === 'disabled' && !rule.enabled);
    return matchesSearch && matchesStatus;
  });

  const handleToggleRule = (ruleId: string) => {
    setAutomationRules(rules => 
      rules.map(rule => 
        rule.id === ruleId 
          ? { ...rule, enabled: !rule.enabled }
          : rule
      )
    );
    toast.success('Rule status updated');
  };

  const handleDeleteRule = (ruleId: string) => {
    if (window.confirm('Are you sure you want to delete this automation rule?')) {
      setAutomationRules(rules => rules.filter(rule => rule.id !== ruleId));
      toast.success('Rule deleted');
    }
  };

  const renderRuleCard = (rule: AutomationRule) => (
    <div key={rule.id} className="card p-6 hover:shadow-lg transition-all duration-200">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <h3 className="text-lg font-semibold text-foreground">{rule.name}</h3>
            <div className={`w-2 h-2 rounded-full ${rule.enabled ? 'bg-green-400' : 'bg-gray-400'}`}></div>
          </div>
          <p className="text-muted-foreground text-sm mb-3">{rule.description}</p>
          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
            <div className="flex items-center space-x-1">
              <Target className="w-4 h-4" />
              <span>{rule.actions.length} actions</span>
            </div>
            <div className="flex items-center space-x-1">
              <Activity className="w-4 h-4" />
              <span>{rule.executionCount} executions</span>
            </div>
            <div className="flex items-center space-x-1">
              <TrendingUp className="w-4 h-4" />
              <span>{Math.round(rule.successRate * 100)}% success</span>
            </div>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setSelectedRule(rule)}
            className="p-2 text-muted-foreground hover:text-foreground hover:bg-accent rounded"
          >
            <Edit className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleToggleRule(rule.id)}
            className={`p-2 rounded ${
              rule.enabled 
                ? 'text-green-400 hover:text-green-300 hover:bg-green-100' 
                : 'text-gray-400 hover:text-gray-300 hover:bg-gray-100'
            }`}
          >
            {rule.enabled ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </button>
          <button
            onClick={() => handleDeleteRule(rule.id)}
            className="p-2 text-destructive hover:text-red-400 hover:bg-red-100 rounded"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
      
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Priority</span>
          <span className="font-medium text-foreground">{rule.priority}</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Last Executed</span>
          <span className="font-medium text-foreground">
            {rule.lastExecuted ? new Date(rule.lastExecuted).toLocaleDateString() : 'Never'}
          </span>
        </div>
      </div>
    </div>
  );

  const renderAnalyticsTab = () => (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Rules</p>
              <p className="text-2xl font-bold text-foreground">{analytics.totalRules}</p>
            </div>
            <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
              <Settings className="w-6 h-6 text-primary" />
            </div>
          </div>
        </div>
        
        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Active Rules</p>
              <p className="text-2xl font-bold text-foreground">{analytics.activeRules}</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>
        
        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Executions Today</p>
              <p className="text-2xl font-bold text-foreground">{analytics.executionsToday}</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Activity className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>
        
        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Success Rate</p>
              <p className="text-2xl font-bold text-foreground">{Math.round(analytics.successRate * 100)}%</p>
            </div>
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Top Performing Rules */}
      <div className="card p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Top Performing Rules</h3>
        <div className="space-y-3">
          {analytics.topPerformingRules.map((rule, index) => (
            <div key={rule.id} className="flex items-center justify-between p-3 bg-secondary rounded">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium">
                  {index + 1}
                </div>
                <div>
                  <p className="font-medium text-foreground">{rule.name}</p>
                  <p className="text-sm text-muted-foreground">{rule.executions} executions</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium text-foreground">{Math.round(rule.successRate * 100)}%</p>
                <p className="text-xs text-muted-foreground">success rate</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Executions */}
      <div className="card p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Recent Executions</h3>
        <div className="space-y-3">
          {analytics.recentExecutions.map((execution) => (
            <div key={execution.id} className="flex items-center justify-between p-3 bg-secondary rounded">
              <div className="flex items-center space-x-3">
                <div className={`w-2 h-2 rounded-full ${
                  execution.status === 'success' ? 'bg-green-400' :
                  execution.status === 'failed' ? 'bg-red-400' :
                  'bg-yellow-400'
                }`}></div>
                <div>
                  <p className="font-medium text-foreground">{execution.ruleName}</p>
                  <p className="text-sm text-muted-foreground">
                    {new Date(execution.timestamp).toLocaleString()}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium text-foreground">{execution.duration}ms</p>
                <p className="text-xs text-muted-foreground capitalize">{execution.status}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="p-6 bg-background min-h-screen text-foreground">
      <div className="mb-8">
        <h1 className="text-3xl font-bold gradient-text mb-2">Intelligent Automation Engine</h1>
        <p className="text-muted-foreground">
          AI-powered automation rules that learn and adapt to optimize your voice AI performance
        </p>
      </div>

      {/* Tab Navigation */}
      <div className="mb-6">
        <div className="flex space-x-1 bg-secondary p-1 rounded-lg w-fit">
          {[
            { id: 'rules', label: 'Automation Rules', icon: Settings },
            { id: 'analytics', label: 'Analytics', icon: BarChart3 },
            { id: 'logs', label: 'Execution Logs', icon: Activity },
            { id: 'settings', label: 'Settings', icon: Brain }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-primary text-primary-foreground shadow-lg'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      {activeTab === 'rules' && (
        <div className="space-y-6">
          {/* Search and Filters */}
          <div className="card p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <input
                    type="text"
                    placeholder="Search automation rules..."
                    className="w-full pl-10 input"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
              <div className="flex space-x-2">
                <select
                  className="input"
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value as any)}
                >
                  <option value="all">All Rules</option>
                  <option value="enabled">Enabled</option>
                  <option value="disabled">Disabled</option>
                </select>
                <button className="btn btn-primary">
                  <Plus className="w-4 h-4 mr-2" />
                  New Rule
                </button>
              </div>
            </div>
          </div>

          {/* Rules Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredRules.map(renderRuleCard)}
          </div>
        </div>
      )}

      {activeTab === 'analytics' && renderAnalyticsTab()}
      
      {activeTab === 'logs' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Execution Logs</h2>
          <p className="text-muted-foreground">Detailed execution logs and debugging information will be displayed here.</p>
        </div>
      )}
      
      {activeTab === 'settings' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Automation Settings</h2>
          <p className="text-muted-foreground">Configure global automation settings and preferences.</p>
        </div>
      )}
    </div>
  );
};

export default IntelligentAutomationEngine;
