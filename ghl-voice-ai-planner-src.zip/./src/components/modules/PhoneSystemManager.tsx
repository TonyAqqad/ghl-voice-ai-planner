import React from 'react';
import { Phone, Plus, Settings } from 'lucide-react';

const PhoneSystemManager: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Phone System Manager</h1>
          <p className="text-muted-foreground mt-2">
            Configure phone numbers, IVR menus, and call routing
          </p>
        </div>
        <button className="btn btn-primary flex items-center space-x-2">
          <Plus className="w-4 h-4" />
          <span>Add Phone Number</span>
        </button>
      </div>
      
      <div className="card">
        <div className="card-content text-center py-12">
          <Phone className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">
            Phone System Configuration
          </h3>
          <p className="text-muted-foreground">
            Manage your phone numbers, IVR menus, and call routing rules
          </p>
        </div>
      </div>
    </div>
  );
};

export default PhoneSystemManager;
