import React, { useState, useEffect } from 'react';
import { 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  RefreshCw, 
  Play, 
  Pause, 
  Settings, 
  Download, 
  Upload, 
  Save, 
  Edit, 
  Trash2, 
  Plus, 
  Minus, 
  ChevronDown, 
  ChevronRight, 
  Eye, 
  EyeOff, 
  Filter, 
  Search, 
  SortAsc, 
  SortDesc, 
  MoreHorizontal, 
  Star, 
  ThumbsUp, 
  ThumbsDown, 
  Heart, 
  Smile, 
  Frown, 
  Meh, 
  Award, 
  Trophy, 
  Medal, 
  Crown, 
  Flame, 
  Lightning, 
  Rocket, 
  Shield, 
  Lock, 
  Unlock, 
  Key, 
  Wrench, 
  Cog, 
  Sliders, 
  ToggleLeft, 
  ToggleRight, 
  Switch, 
  Power, 
  PowerOff, 
  Battery, 
  BatteryCharging, 
  Wifi, 
  WifiOff, 
  Signal, 
  SignalZero, 
  SignalOne, 
  SignalTwo, 
  SignalThree, 
  SignalFour, 
  SignalFive,
  MessageSquare,
  Mic,
  Headphones,
  Volume2,
  VolumeX,
  SkipForward,
  SkipBack,
  RotateCcw,
  BarChart3,
  LineChart,
  PieChart,
  Activity,
  Clock,
  Users,
  Phone,
  Bot,
  Brain,
  Target,
  TrendingUp,
  TrendingDown,
  Database,
  Server,
  Globe,
  FileText,
  FileCheck,
  FileX,
  FileAlert,
  FileLock,
  FileShield,
  FileSearch,
  FileCode,
  FileImage,
  FileVideo,
  FileAudio,
  FileArchive,
  FileSpreadsheet,
  FilePresentation,
  FilePdf,
  FileWord,
  FileExcel,
  FilePowerpoint,
  FileZip,
  FileRar,
  File7z,
  FileTar,
  FileGz,
  FileBz2,
  FileXz,
  FileLz4,
  FileZstd,
  FileCab,
  FileIso,
  FileDmg,
  FileImg,
  FileVhd,
  FileVdi,
  FileVmdk,
  FileOva,
  FileOvf,
  FileVagrant,
  FileDocker,
  FileKubernetes,
  FileTerraform,
  FileAnsible,
  FileChef,
  FilePuppet,
  FileSalt,
  FileConsul,
  FileVault,
  FileNomad,
  FileDockerCompose,
  FileKustomize,
  FileHelm,
  FileIstio,
  FileLinkerd,
  FileEnvoy,
  FileNginx,
  FileApache,
  FileIis,
  FileTomcat,
  FileJetty,
  FileWildfly,
  FileWeblogic,
  FileWebsphere,
  FileGlassfish,
  FileJboss,
  FileResin,
  FileGeronimo,
  FileOpenliberty,
  FilePayara,
  FileTomee,
  FileWeld,
  FileDeltaspike,
  FileShiro,
  FileSpring,
  FileHibernate,
  FileMybatis,
  FileJpa,
  FileJdbc,
  FileJndi,
  FileJms,
  FileJta,
  FileJca,
  FileJaxb,
  FileJaxrs,
  FileJaxws,
  FileJsf,
  FileStruts,
  FileVaadin,
  FileGwt,
  FileWicket,
  FileTapestry,
  FileSeam,
  FileRichfaces,
  FilePrimefaces,
  FileIcefaces,
  FileOpenfaces,
  FileButterfaces,
  FileBootsfaces,
  FileOmnifaces,
  FileAngularfaces,
  FileAngular,
  FileReact,
  FileVue,
  FileSvelte,
  FileEmber,
  FileBackbone,
  FileKnockout,
  FileMithril,
  FilePreact,
  FileInferno,
  FileRiot,
  FileStencil,
  FileLit,
  FilePolymer,
  FileAurelia,
  FileMithril,
  FileHyperapp,
  FileAlpine,
  FileStimulus,
  FileTurbo,
  FileHotwire,
  FileLivewire,
  FileInertia,
  FileNext,
  FileNuxt,
  FileSapper,
  FileSveltekit,
  FileRemix,
  FileSolid,
  FileQwik,
  FileMarko,
  FileMithril,
  FileHyperapp,
  FileAlpine,
  FileStimulus,
  FileTurbo,
  FileHotwire,
  FileLivewire,
  FileInertia,
  FileNext,
  FileNuxt,
  FileSapper,
  FileSveltekit,
  FileRemix,
  FileSolid,
  FileQwik,
  FileMarko,
  Info,
  ExternalLink,
  Copy,
  Link,
  Unlink,
  Send,
  Receive,
  ArrowRight,
  ArrowLeft,
  ArrowUp,
  ArrowDown,
  RotateCw,
  RotateCcw,
  Move,
  MoveUp,
  MoveDown,
  MoveLeft,
  MoveRight,
  Maximize,
  Minimize,
  Maximize2,
  Minimize2,
  Square,
  Circle,
  Triangle,
  Hexagon,
  Octagon,
  Pentagon,
  Diamond,
  RectangleHorizontal,
  RectangleVertical,
  Ellipse,
  Oval,
  Parallelogram,
  Trapezoid,
  Rhombus,
  Kite,
  Star as StarIcon,
  Heart as HeartIcon,
  Smile as SmileIcon,
  Frown as FrownIcon,
  Meh as MehIcon,
  ThumbsUp as ThumbsUpIcon,
  ThumbsDown as ThumbsDownIcon,
  Award as AwardIcon,
  Trophy as TrophyIcon,
  Medal as MedalIcon,
  Crown as CrownIcon,
  Flame as FlameIcon,
  Lightning as LightningIcon,
  Rocket as RocketIcon,
  Shield as ShieldIcon,
  Lock as LockIcon,
  Unlock as UnlockIcon,
  Key as KeyIcon,
  Wrench as WrenchIcon,
  Cog as CogIcon,
  Sliders as SlidersIcon,
  ToggleLeft as ToggleLeftIcon,
  ToggleRight as ToggleRightIcon,
  Switch as SwitchIcon,
  Power as PowerIcon,
  PowerOff as PowerOffIcon,
  Battery as BatteryIcon,
  BatteryCharging as BatteryChargingIcon,
  Wifi as WifiIcon,
  WifiOff as WifiOffIcon,
  Signal as SignalIcon,
  SignalZero as SignalZeroIcon,
  SignalOne as SignalOneIcon,
  SignalTwo as SignalTwoIcon,
  SignalThree as SignalThreeIcon,
  SignalFour as SignalFourIcon,
  SignalFive as SignalFiveIcon,
  MessageSquare as MessageSquareIcon,
  Mic as MicIcon,
  Headphones as HeadphonesIcon,
  Volume2 as Volume2Icon,
  VolumeX as VolumeXIcon,
  Play as PlayIcon,
  Pause as PauseIcon,
  SkipForward as SkipForwardIcon,
  SkipBack as SkipBackIcon,
  RotateCcw as RotateCcwIcon,
  BarChart3 as BarChart3Icon,
  LineChart as LineChartIcon,
  PieChart as PieChartIcon,
  Activity as ActivityIcon,
  Clock as ClockIcon,
  Phone as PhoneIcon,
  Bot as BotIcon,
  Brain as BrainIcon,
  Target as TargetIcon,
  TrendingUp as TrendingUpIcon,
  TrendingDown as TrendingDownIcon,
  Database as DatabaseIcon,
  Server as ServerIcon,
  Globe as GlobeIcon,
  FileText as FileTextIcon,
  FileCheck as FileCheckIcon,
  FileX as FileXIcon,
  FileAlert as FileAlertIcon,
  FileLock as FileLockIcon,
  FileShield as FileShieldIcon,
  FileSearch as FileSearchIcon,
  FileCode as FileCodeIcon,
  FileImage as FileImageIcon,
  FileVideo as FileVideoIcon,
  FileAudio as FileAudioIcon,
  FileArchive as FileArchiveIcon,
  FileSpreadsheet as FileSpreadsheetIcon,
  FilePresentation as FilePresentationIcon,
  FilePdf as FilePdfIcon,
  FileWord as FileWordIcon,
  FileExcel as FileExcelIcon,
  FilePowerpoint as FilePowerpointIcon,
  FileZip as FileZipIcon,
  FileRar as FileRarIcon,
  File7z as File7zIcon,
  FileTar as FileTarIcon,
  FileGz as FileGzIcon,
  FileBz2 as FileBz2Icon,
  FileXz as FileXzIcon,
  FileLz4 as FileLz4Icon,
  FileZstd as FileZstdIcon,
  FileCab as FileCabIcon,
  FileIso as FileIsoIcon,
  FileDmg as FileDmgIcon,
  FileImg as FileImgIcon,
  FileVhd as FileVhdIcon,
  FileVdi as FileVdiIcon,
  FileVmdk as FileVmdkIcon,
  FileOva as FileOvaIcon,
  FileOvf as FileOvfIcon,
  FileVagrant as FileVagrantIcon,
  FileDocker as FileDockerIcon,
  FileKubernetes as FileKubernetesIcon,
  FileTerraform as FileTerraformIcon,
  FileAnsible as FileAnsibleIcon,
  FileChef as FileChefIcon,
  FilePuppet as FilePuppetIcon,
  FileSalt as FileSaltIcon,
  FileConsul as FileConsulIcon,
  FileVault as FileVaultIcon,
  FileNomad as FileNomadIcon,
  FileDockerCompose as FileDockerComposeIcon,
  FileKustomize as FileKustomizeIcon,
  FileHelm as FileHelmIcon,
  FileIstio as FileIstioIcon,
  FileLinkerd as FileLinkerdIcon,
  FileEnvoy as FileEnvoyIcon,
  FileNginx as FileNginxIcon,
  FileApache as FileApacheIcon,
  FileIis as FileIisIcon,
  FileTomcat as FileTomcatIcon,
  FileJetty as FileJettyIcon,
  FileWildfly as FileWildflyIcon,
  FileWeblogic as FileWeblogicIcon,
  FileWebsphere as FileWebsphereIcon,
  FileGlassfish as FileGlassfishIcon,
  FileJboss as FileJbossIcon,
  FileResin as FileResinIcon,
  FileGeronimo as FileGeronimoIcon,
  FileOpenliberty as FileOpenlibertyIcon,
  FilePayara as FilePayaraIcon,
  FileTomee as FileTomeeIcon,
  FileWeld as FileWeldIcon,
  FileDeltaspike as FileDeltaspikeIcon,
  FileShiro as FileShiroIcon,
  FileSpring as FileSpringIcon,
  FileHibernate as FileHibernateIcon,
  FileMybatis as FileMybatisIcon,
  FileJpa as FileJpaIcon,
  FileJdbc as FileJdbcIcon,
  FileJndi as FileJndiIcon,
  FileJms as FileJmsIcon,
  FileJta as FileJtaIcon,
  FileJca as FileJcaIcon,
  FileJaxb as FileJaxbIcon,
  FileJaxrs as FileJaxrsIcon,
  FileJaxws as FileJaxwsIcon,
  FileJsf as FileJsfIcon,
  FileStruts as FileStrutsIcon,
  FileVaadin as FileVaadinIcon,
  FileGwt as FileGwtIcon,
  FileWicket as FileWicketIcon,
  FileTapestry as FileTapestryIcon,
  FileSeam as FileSeamIcon,
  FileRichfaces as FileRichfacesIcon,
  FilePrimefaces as FilePrimefacesIcon,
  FileIcefaces as FileIcefacesIcon,
  FileOpenfaces as FileOpenfacesIcon,
  FileButterfaces as FileButterfacesIcon,
  FileBootsfaces as FileBootsfacesIcon,
  FileOmnifaces as FileOmnifacesIcon,
  FileAngularfaces as FileAngularfacesIcon,
  FileAngular as FileAngularIcon,
  FileReact as FileReactIcon,
  FileVue as FileVueIcon,
  FileSvelte as FileSvelteIcon,
  FileEmber as FileEmberIcon,
  FileBackbone as FileBackboneIcon,
  FileKnockout as FileKnockoutIcon,
  FileMithril as FileMithrilIcon,
  FilePreact as FilePreactIcon,
  FileInferno as FileInfernoIcon,
  FileRiot as FileRiotIcon,
  FileStencil as FileStencilIcon,
  FileLit as FileLitIcon,
  FilePolymer as FilePolymerIcon,
  FileAurelia as FileAureliaIcon,
  FileMithril as FileMithrilIcon,
  FileHyperapp as FileHyperappIcon,
  FileAlpine as FileAlpineIcon,
  FileStimulus as FileStimulusIcon,
  FileTurbo as FileTurboIcon,
  FileHotwire as FileHotwireIcon,
  FileLivewire as FileLivewireIcon,
  FileInertia as FileInertiaIcon,
  FileNext as FileNextIcon,
  FileNuxt as FileNuxtIcon,
  FileSapper as FileSapperIcon,
  FileSveltekit as FileSveltekitIcon,
  FileRemix as FileRemixIcon,
  FileSolid as FileSolidIcon,
  FileQwik as FileQwikIcon,
  FileMarko as FileMarkoIcon,
  FileMithril as FileMithrilIcon,
  FileHyperapp as FileHyperappIcon,
  FileAlpine as FileAlpineIcon,
  FileStimulus as FileStimulusIcon,
  FileTurbo as FileTurboIcon,
  FileHotwire as FileHotwireIcon,
  FileLivewire as FileLivewireIcon,
  FileInertia as FileInertiaIcon,
  FileNext as FileNextIcon,
  FileNuxt as FileNuxtIcon,
  FileSapper as FileSapperIcon,
  FileSveltekit as FileSveltekitIcon,
  FileRemix as FileRemixIcon,
  FileSolid as FileSolidIcon,
  FileQwik as FileQwikIcon,
  FileMarko as FileMarkoIcon
} from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';

interface GHLValidationTest {
  id: string;
  name: string;
  description: string;
  category: 'api' | 'webhook' | 'custom_fields' | 'workflows' | 'pipelines' | 'tags' | 'merge_tags' | 'compliance';
  status: 'pending' | 'running' | 'passed' | 'failed' | 'warning';
  priority: 'critical' | 'high' | 'medium' | 'low';
  duration: number;
  lastRun: string | null;
  results: {
    message: string;
    details: string;
    suggestions: string[];
    fixCommands: string[];
  };
  dependencies: string[];
  autoFixable: boolean;
}

interface GHLIntegrationReport {
  id: string;
  agentId: string;
  agentName: string;
  overallScore: number;
  status: 'excellent' | 'good' | 'needs_improvement' | 'critical_issues';
  tests: GHLValidationTest[];
  recommendations: Array<{
    priority: 'critical' | 'high' | 'medium' | 'low';
    category: string;
    title: string;
    description: string;
    impact: string;
    effort: 'low' | 'medium' | 'high';
    autoFixable: boolean;
  }>;
  createdAt: string;
  updatedAt: string;
}

interface GHLConnection {
  id: string;
  name: string;
  locationId: string;
  apiKey: string;
  status: 'connected' | 'disconnected' | 'error';
  lastTested: string;
  permissions: string[];
  rateLimits: {
    requestsPerMinute: number;
    requestsPerDay: number;
    remaining: number;
  };
}

const GHLIntegrationValidator: React.FC = () => {
  const { darkMode } = useStore();
  const [validationReports, setValidationReports] = useState<GHLIntegrationReport[]>([]);
  const [ghlConnections, setGhlConnections] = useState<GHLConnection[]>([]);
  const [isRunningTests, setIsRunningTests] = useState(false);
  const [selectedAgent, setSelectedAgent] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeTab, setActiveTab] = useState<'overview' | 'validation' | 'connections' | 'reports' | 'fixes'>('overview');

  // Sample data
  useEffect(() => {
    const sampleReports: GHLIntegrationReport[] = [
      {
        id: 'report_1',
        agentId: 'agent_1',
        agentName: 'F45 Fitness Trial Booking',
        overallScore: 87,
        status: 'good',
        tests: [
          {
            id: 'test_1',
            name: 'API Connection Test',
            description: 'Test GHL API connectivity and authentication',
            category: 'api',
            status: 'passed',
            priority: 'critical',
            duration: 1200,
            lastRun: '2024-01-15T14:30:00Z',
            results: {
              message: 'API connection successful',
              details: 'Successfully connected to GHL API with valid credentials',
              suggestions: [],
              fixCommands: []
            },
            dependencies: [],
            autoFixable: false
          },
          {
            id: 'test_2',
            name: 'Custom Fields Validation',
            description: 'Validate required custom fields exist in GHL',
            category: 'custom_fields',
            status: 'warning',
            priority: 'high',
            duration: 800,
            lastRun: '2024-01-15T14:30:00Z',
            results: {
              message: 'Some custom fields missing',
              details: 'Missing fields: fitness_goals, trial_date_preference',
              suggestions: [
                'Create missing custom fields in GHL',
                'Update agent configuration to use existing fields'
              ],
              fixCommands: [
                'ghl create-custom-field --name="fitness_goals" --type="text"',
                'ghl create-custom-field --name="trial_date_preference" --type="date"'
              ]
            },
            dependencies: ['test_1'],
            autoFixable: true
          },
          {
            id: 'test_3',
            name: 'Webhook Configuration',
            description: 'Test webhook endpoints and payload validation',
            category: 'webhook',
            status: 'passed',
            priority: 'high',
            duration: 1500,
            lastRun: '2024-01-15T14:30:00Z',
            results: {
              message: 'Webhook configuration valid',
              details: 'All webhook endpoints responding correctly',
              suggestions: [],
              fixCommands: []
            },
            dependencies: ['test_1'],
            autoFixable: false
          },
          {
            id: 'test_4',
            name: 'Workflow Integration',
            description: 'Validate workflow triggers and actions',
            category: 'workflows',
            status: 'failed',
            priority: 'medium',
            duration: 2000,
            lastRun: '2024-01-15T14:30:00Z',
            results: {
              message: 'Workflow integration failed',
              details: 'Workflow "Trial Booking Follow-up" not found in GHL',
              suggestions: [
                'Create the missing workflow in GHL',
                'Update workflow references in agent configuration'
              ],
              fixCommands: [
                'ghl create-workflow --name="Trial Booking Follow-up" --template="trial-followup"'
              ]
            },
            dependencies: ['test_1'],
            autoFixable: true
          },
          {
            id: 'test_5',
            name: 'Merge Tags Validation',
            description: 'Validate merge tags are properly formatted',
            category: 'merge_tags',
            status: 'passed',
            priority: 'medium',
            duration: 600,
            lastRun: '2024-01-15T14:30:00Z',
            results: {
              message: 'All merge tags valid',
              details: 'All merge tags are properly formatted and available',
              suggestions: [],
              fixCommands: []
            },
            dependencies: ['test_1'],
            autoFixable: false
          }
        ],
        recommendations: [
          {
            priority: 'high',
            category: 'Custom Fields',
            title: 'Create Missing Custom Fields',
            description: 'Add fitness_goals and trial_date_preference custom fields to improve data collection',
            impact: 'High - Required for proper lead qualification',
            effort: 'low',
            autoFixable: true
          },
          {
            priority: 'medium',
            category: 'Workflows',
            title: 'Set Up Trial Booking Follow-up Workflow',
            description: 'Create automated follow-up workflow for trial bookings',
            impact: 'Medium - Improves conversion rates',
            effort: 'medium',
            autoFixable: true
          }
        ],
        createdAt: '2024-01-15T14:00:00Z',
        updatedAt: '2024-01-15T14:30:00Z'
      }
    ];

    const sampleConnections: GHLConnection[] = [
      {
        id: 'conn_1',
        name: 'Main GHL Location',
        locationId: 'loc_12345',
        apiKey: 'sk-***',
        status: 'connected',
        lastTested: '2024-01-15T14:30:00Z',
        permissions: ['contacts', 'workflows', 'pipelines', 'custom_fields', 'webhooks'],
        rateLimits: {
          requestsPerMinute: 60,
          requestsPerDay: 10000,
          remaining: 8500
        }
      }
    ];

    setValidationReports(sampleReports);
    setGhlConnections(sampleConnections);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'passed': return 'text-green-400 bg-green-100';
      case 'failed': return 'text-red-400 bg-red-100';
      case 'warning': return 'text-yellow-400 bg-yellow-100';
      case 'running': return 'text-blue-400 bg-blue-100';
      case 'pending': return 'text-gray-400 bg-gray-100';
      case 'excellent': return 'text-green-400 bg-green-100';
      case 'good': return 'text-blue-400 bg-blue-100';
      case 'needs_improvement': return 'text-yellow-400 bg-yellow-100';
      case 'critical_issues': return 'text-red-400 bg-red-100';
      case 'connected': return 'text-green-400 bg-green-100';
      case 'disconnected': return 'text-gray-400 bg-gray-100';
      case 'error': return 'text-red-400 bg-red-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'text-red-400 bg-red-100';
      case 'high': return 'text-orange-400 bg-orange-100';
      case 'medium': return 'text-yellow-400 bg-yellow-100';
      case 'low': return 'text-green-400 bg-green-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const handleRunValidation = async (agentId: string) => {
    setIsRunningTests(true);
    toast.success('Starting GHL integration validation...');
    
    // Simulate validation process
    setTimeout(() => {
      setIsRunningTests(false);
      toast.success('GHL integration validation completed!');
    }, 3000);
  };

  const handleAutoFix = async (testId: string) => {
    toast.success('Auto-fixing GHL integration issues...');
    
    // Simulate auto-fix process
    setTimeout(() => {
      toast.success('Auto-fix completed successfully!');
    }, 2000);
  };

  const renderOverviewTab = () => (
    <div className="space-y-6">
      {/* Integration Health Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Agents</p>
              <p className="text-2xl font-bold text-foreground">{validationReports.length}</p>
            </div>
            <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
              <Bot className="w-6 h-6 text-primary" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Integration Score</p>
              <p className="text-2xl font-bold text-green-400">
                {Math.round(validationReports.reduce((acc, report) => acc + report.overallScore, 0) / validationReports.length)}%
              </p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Tests Passed</p>
              <p className="text-2xl font-bold text-blue-400">
                {validationReports.reduce((acc, report) => 
                  acc + report.tests.filter(test => test.status === 'passed').length, 0
                )}
              </p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Target className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Issues Found</p>
              <p className="text-2xl font-bold text-red-400">
                {validationReports.reduce((acc, report) => 
                  acc + report.tests.filter(test => test.status === 'failed' || test.status === 'warning').length, 0
                )}
              </p>
            </div>
            <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Recent Validation Results */}
      <div className="card p-6">
        <h2 className="text-xl font-semibold text-foreground mb-6">Recent Validation Results</h2>
        <div className="space-y-4">
          {validationReports.map((report) => (
            <div key={report.id} className="flex items-center justify-between p-4 bg-secondary rounded-lg">
              <div className="flex items-center space-x-4">
                <div className={`w-3 h-3 rounded-full ${getStatusColor(report.status).split(' ')[0]}`}></div>
                <div>
                  <p className="font-medium text-foreground">{report.agentName}</p>
                  <p className="text-sm text-muted-foreground">
                    Score: {report.overallScore}% • {report.tests.length} tests
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <p className="text-sm font-medium text-foreground">{report.overallScore}%</p>
                  <p className="text-xs text-muted-foreground">Integration Score</p>
                </div>
                <button
                  onClick={() => handleRunValidation(report.agentId)}
                  disabled={isRunningTests}
                  className="btn btn-outline btn-sm"
                >
                  {isRunningTests ? (
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Play className="w-4 h-4 mr-2" />
                  )}
                  Re-test
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderValidationTab = () => (
    <div className="space-y-6">
      {/* Validation Tests */}
      {validationReports.map((report) => (
        <div key={report.id} className="card p-6">
          <div className="flex items-start justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold text-foreground">{report.agentName}</h3>
              <p className="text-muted-foreground">Integration Score: {report.overallScore}%</p>
            </div>
            <div className="flex items-center space-x-2">
              <div className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(report.status)}`}>
                {report.status}
              </div>
              <button
                onClick={() => handleRunValidation(report.agentId)}
                disabled={isRunningTests}
                className="btn btn-primary btn-sm"
              >
                {isRunningTests ? (
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Play className="w-4 h-4 mr-2" />
                )}
                Run Tests
              </button>
            </div>
          </div>

          <div className="space-y-4">
            {report.tests.map((test) => (
              <div key={test.id} className="flex items-start justify-between p-4 bg-secondary rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h4 className="font-medium text-foreground">{test.name}</h4>
                    <div className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(test.status)}`}>
                      {test.status}
                    </div>
                    <div className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(test.priority)}`}>
                      {test.priority}
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{test.description}</p>
                  <p className="text-sm text-foreground">{test.results.message}</p>
                  {test.results.details && (
                    <p className="text-xs text-muted-foreground mt-1">{test.results.details}</p>
                  )}
                  {test.results.suggestions.length > 0 && (
                    <div className="mt-2">
                      <p className="text-xs font-medium text-muted-foreground">Suggestions:</p>
                      <ul className="list-disc list-inside text-xs text-muted-foreground space-y-1">
                        {test.results.suggestions.map((suggestion, idx) => (
                          <li key={idx}>{suggestion}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
                <div className="flex items-center space-x-2 ml-4">
                  {test.autoFixable && (test.status === 'failed' || test.status === 'warning') && (
                    <button
                      onClick={() => handleAutoFix(test.id)}
                      className="btn btn-outline btn-sm"
                    >
                      <Wrench className="w-4 h-4 mr-2" />
                      Auto Fix
                    </button>
                  )}
                  <button className="btn btn-outline btn-sm">
                    <Eye className="w-4 h-4 mr-2" />
                    Details
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Recommendations */}
          {report.recommendations.length > 0 && (
            <div className="mt-6">
              <h4 className="font-medium text-foreground mb-3">Recommendations</h4>
              <div className="space-y-3">
                {report.recommendations.map((rec, idx) => (
                  <div key={idx} className="p-3 bg-muted rounded-lg">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <h5 className="font-medium text-foreground">{rec.title}</h5>
                          <div className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(rec.priority)}`}>
                            {rec.priority}
                          </div>
                          <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                            rec.effort === 'low' ? 'text-green-400 bg-green-100' :
                            rec.effort === 'medium' ? 'text-yellow-400 bg-yellow-100' :
                            'text-red-400 bg-red-100'
                          }`}>
                            {rec.effort} effort
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground mb-1">{rec.description}</p>
                        <p className="text-xs text-muted-foreground">Impact: {rec.impact}</p>
                      </div>
                      {rec.autoFixable && (
                        <button className="btn btn-outline btn-sm">
                          <Wrench className="w-4 h-4 mr-2" />
                          Auto Fix
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );

  return (
    <div className="p-6 bg-background min-h-screen text-foreground">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">GHL Integration Validator</h1>
            <p className="text-muted-foreground">
              Automated validation and testing for GoHighLevel integrations
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <button className="btn btn-outline">
              <Download className="w-4 h-4 mr-2" />
              Export Report
            </button>
            <button className="btn btn-outline">
              <Settings className="w-4 h-4 mr-2" />
              Validator Settings
            </button>
            <button className="btn btn-primary">
              <Play className="w-4 h-4 mr-2" />
              Run All Tests
            </button>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="mb-6">
        <div className="flex space-x-1 bg-secondary p-1 rounded-lg w-fit">
          {[
            { id: 'overview', label: 'Overview', icon: BarChart3 },
            { id: 'validation', label: 'Validation Tests', icon: CheckCircle },
            { id: 'connections', label: 'GHL Connections', icon: Database },
            { id: 'reports', label: 'Reports', icon: FileText },
            { id: 'fixes', label: 'Auto Fixes', icon: Wrench }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-primary text-primary-foreground shadow-lg'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      {activeTab === 'overview' && renderOverviewTab()}
      {activeTab === 'validation' && renderValidationTab()}
      {activeTab === 'connections' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">GHL Connections</h2>
          <p className="text-muted-foreground">GHL connection management interface will be displayed here.</p>
        </div>
      )}
      {activeTab === 'reports' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Validation Reports</h2>
          <p className="text-muted-foreground">Detailed validation reports interface will be displayed here.</p>
        </div>
      )}
      {activeTab === 'fixes' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Auto Fixes</h2>
          <p className="text-muted-foreground">Automated fix management interface will be displayed here.</p>
        </div>
      )}
    </div>
  );
};

export default GHLIntegrationValidator;
