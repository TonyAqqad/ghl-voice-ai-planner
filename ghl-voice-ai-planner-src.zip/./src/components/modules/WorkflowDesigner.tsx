import React, { useState } from 'react';
import { Workflow, Bot, Code, Plus, Settings, Play, Save, Trash2, Edit, Eye, Download } from 'lucide-react';
import { useStore } from '../../store/useStore';
import TraditionalWorkflowCreator from './TraditionalWorkflowCreator';
import AICustomActionWorkflowCreator from './AICustomActionWorkflowCreator';

type WorkflowType = 'traditional' | 'ai_custom_actions' | 'voice_flow';

const WorkflowDesigner: React.FC = () => {
  const { workflows, addWorkflow, updateWorkflow, deleteWorkflow } = useStore();
  const [activeTab, setActiveTab] = useState<WorkflowType>('traditional');
  const [selectedWorkflow, setSelectedWorkflow] = useState<Workflow | null>(null);
  const [isCreating, setIsCreating] = useState(false);

  const workflowTypes = [
    {
      id: 'traditional' as const,
      name: 'Traditional Workflows',
      description: 'GHL native workflows with triggers, filters, and actions',
      icon: Settings,
      color: 'text-blue-400',
      bgColor: 'bg-blue-500/10',
      borderColor: 'border-blue-500/20'
    },
    {
      id: 'ai_custom_actions' as const,
      name: 'AI Custom Actions',
      description: 'Real-time webhook actions during Voice AI calls',
      icon: Bot,
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/10',
      borderColor: 'border-purple-500/20'
    },
    {
      id: 'voice_flow' as const,
      name: 'Voice Flow Designer',
      description: 'Visual call flow designer for Voice AI agents',
      icon: Code,
      color: 'text-green-400',
      bgColor: 'bg-green-500/10',
      borderColor: 'border-green-500/20'
    }
  ];

  const filteredWorkflows = workflows.filter(workflow => {
    switch (activeTab) {
      case 'traditional':
        return workflow.trigger.type === 'traditional';
      case 'ai_custom_actions':
        return workflow.trigger.type === 'ai_custom_actions';
      case 'voice_flow':
        return workflow.trigger.type === 'voice_flow';
      default:
        return true;
    }
  });

  const handleCreateWorkflow = () => {
    setIsCreating(true);
    setSelectedWorkflow(null);
  };

  const handleEditWorkflow = (workflow: Workflow) => {
    setSelectedWorkflow(workflow);
    setIsCreating(false);
  };

  const handleDeleteWorkflow = (workflowId: string) => {
    if (confirm('Are you sure you want to delete this workflow?')) {
      deleteWorkflow(workflowId);
    }
  };

  const exportWorkflow = (workflow: Workflow) => {
    const exportData = {
      ...workflow,
      exportedAt: new Date().toISOString(),
      version: '1.0.0'
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${workflow.name.replace(/\s+/g, '-').toLowerCase()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const renderWorkflowList = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">
          {workflowTypes.find(t => t.id === activeTab)?.name} Workflows
        </h2>
        <button
          onClick={handleCreateWorkflow}
          className="btn btn-primary"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create New
        </button>
      </div>

      {filteredWorkflows.length === 0 ? (
        <div className="text-center py-12">
          <div className="w-16 h-16 mx-auto mb-4 bg-muted rounded-full flex items-center justify-center">
            {(() => {
              const IconComponent = workflowTypes.find(t => t.id === activeTab)?.icon;
              return IconComponent ? <IconComponent className="w-8 h-8 text-muted-foreground" /> : null;
            })()}
          </div>
          <h3 className="text-lg font-medium text-foreground mb-2">No Workflows Yet</h3>
          <p className="text-muted-foreground mb-4">
            Create your first {workflowTypes.find(t => t.id === activeTab)?.name.toLowerCase()} workflow
          </p>
          <button
            onClick={handleCreateWorkflow}
            className="btn btn-primary"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Workflow
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredWorkflows.map((workflow) => (
            <div key={workflow.id} className="card hover:shadow-lg transition-all duration-200">
              <div className="card-content">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 rounded-lg ${workflowTypes.find(t => t.id === activeTab)?.bgColor} flex items-center justify-center`}>
                      {(() => {
                        const IconComponent = workflowTypes.find(t => t.id === activeTab)?.icon;
                        const color = workflowTypes.find(t => t.id === activeTab)?.color;
                        return IconComponent ? <IconComponent className={`w-5 h-5 ${color}`} /> : null;
                      })()}
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">{workflow.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        {workflow.trigger.type.replace('_', ' ').toUpperCase()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => handleEditWorkflow(workflow)}
                      className="p-1 hover:bg-accent rounded"
                      title="Edit"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => exportWorkflow(workflow)}
                      className="p-1 hover:bg-accent rounded"
                      title="Export"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteWorkflow(workflow.id)}
                      className="p-1 hover:bg-destructive/20 rounded text-destructive"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                
                <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                  {workflow.description}
                </p>
                
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>
                    {workflow.nodes.length} {workflow.nodes.length === 1 ? 'step' : 'steps'}
                  </span>
                  <span>
                    {new Date(workflow.updatedAt).toLocaleDateString()}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  const renderWorkflowCreator = () => {
    switch (activeTab) {
      case 'traditional':
        return <TraditionalWorkflowCreator />;
      case 'ai_custom_actions':
        return <AICustomActionWorkflowCreator />;
      case 'voice_flow':
        return (
          <div className="min-h-screen bg-background p-6">
            <div className="max-w-7xl mx-auto">
              <div className="text-center py-12">
                <Code className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                <h2 className="text-2xl font-bold text-foreground mb-2">Voice Flow Designer</h2>
                <p className="text-muted-foreground mb-6">
                  Visual call flow designer coming soon
                </p>
                <div className="bg-muted rounded-lg p-6 max-w-md mx-auto">
                  <h3 className="font-semibold mb-2">Features Coming Soon:</h3>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Drag & drop call flow builder</li>
                    <li>• Visual node connections</li>
                    <li>• Real-time testing</li>
                    <li>• Voice AI integration</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">Workflow Designer</h1>
              <p className="text-muted-foreground">
                Create and manage automation workflows for Voice AI agents
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <button className="btn btn-outline">
                <Play className="w-4 h-4 mr-2" />
                Test All
              </button>
              <button className="btn btn-primary">
                <Save className="w-4 h-4 mr-2" />
                Save All
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-6">
          <nav className="flex space-x-8">
            {workflowTypes.map((type) => (
              <button
                key={type.id}
                onClick={() => setActiveTab(type.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors duration-200 ${
                  activeTab === type.id
                    ? `border-primary ${type.color}`
                    : 'border-transparent text-muted-foreground hover:text-foreground hover:border-border'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <type.icon className="w-4 h-4" />
                  <span>{type.name}</span>
                </div>
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-6 py-6">
        {isCreating ? (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">
                Create New {workflowTypes.find(t => t.id === activeTab)?.name}
              </h2>
              <button
                onClick={() => setIsCreating(false)}
                className="btn btn-outline"
              >
                Back to List
              </button>
            </div>
            {renderWorkflowCreator()}
          </div>
        ) : selectedWorkflow ? (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Edit Workflow</h2>
              <button
                onClick={() => setSelectedWorkflow(null)}
                className="btn btn-outline"
              >
                Back to List
              </button>
            </div>
            {renderWorkflowCreator()}
          </div>
        ) : (
          renderWorkflowList()
        )}
      </div>
    </div>
  );
};

export default WorkflowDesigner;