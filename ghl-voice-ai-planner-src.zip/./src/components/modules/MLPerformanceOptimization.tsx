import React, { useState, useEffect } from 'react';
import { Brain, Zap, TrendingUp, Target, BarChart3, RefreshCw, Play, Pause, Settings, CheckCircle, AlertTriangle, Lightbulb, Activity, Clock, Cpu } from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';
import { v4 as uuidv4 } from 'uuid';

interface MLModel {
  id: string;
  name: string;
  type: 'performance' | 'conversation' | 'sentiment' | 'intent' | 'optimization';
  status: 'training' | 'ready' | 'deployed' | 'failed';
  accuracy: number;
  lastTrained: string;
  trainingData: number;
  predictions: number;
  performance: {
    latency: number;
    throughput: number;
    memoryUsage: number;
    cpuUsage: number;
  };
}

interface OptimizationRule {
  id: string;
  name: string;
  description: string;
  condition: string;
  action: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  isActive: boolean;
  successRate: number;
  timesTriggered: number;
  lastTriggered: string | null;
  impact: {
    performanceGain: number;
    costReduction: number;
    satisfactionImprovement: number;
  };
}

interface RealTimeMetric {
  id: string;
  agentId: string;
  timestamp: string;
  metric: string;
  value: number;
  threshold: number;
  status: 'normal' | 'warning' | 'critical';
  trend: 'up' | 'down' | 'stable';
}

interface OptimizationSuggestion {
  id: string;
  agentId: string;
  type: 'performance' | 'cost' | 'quality' | 'efficiency';
  title: string;
  description: string;
  potentialGain: number;
  confidence: number;
  implementation: {
    difficulty: 'easy' | 'medium' | 'hard';
    timeRequired: number;
    automated: boolean;
  };
  status: 'new' | 'implemented' | 'testing' | 'rejected';
  createdAt: string;
}

const MLPerformanceOptimization: React.FC = () => {
  const { voiceAgents } = useStore();
  const [mlModels, setMlModels] = useState<MLModel[]>([]);
  const [optimizationRules, setOptimizationRules] = useState<OptimizationRule[]>([]);
  const [realTimeMetrics, setRealTimeMetrics] = useState<RealTimeMetric[]>([]);
  const [optimizationSuggestions, setOptimizationSuggestions] = useState<OptimizationSuggestion[]>([]);
  const [selectedAgentId, setSelectedAgentId] = useState<string>('');
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [autoOptimization, setAutoOptimization] = useState(false);

  useEffect(() => {
    // Mock data for ML models
    const mockModels: MLModel[] = [
      {
        id: uuidv4(),
        name: 'Performance Predictor v2.1',
        type: 'performance',
        status: 'deployed',
        accuracy: 94.2,
        lastTrained: '2023-10-26T16:00:00Z',
        trainingData: 125000,
        predictions: 45000,
        performance: {
          latency: 12,
          throughput: 850,
          memoryUsage: 2.3,
          cpuUsage: 15.2
        }
      },
      {
        id: uuidv4(),
        name: 'Conversation Quality Analyzer',
        type: 'conversation',
        status: 'ready',
        accuracy: 91.8,
        lastTrained: '2023-10-25T14:30:00Z',
        trainingData: 89000,
        predictions: 23000,
        performance: {
          latency: 18,
          throughput: 650,
          memoryUsage: 1.8,
          cpuUsage: 12.5
        }
      },
      {
        id: uuidv4(),
        name: 'Intent Recognition Engine',
        type: 'intent',
        status: 'training',
        accuracy: 0,
        lastTrained: '2023-10-26T17:00:00Z',
        trainingData: 0,
        predictions: 0,
        performance: {
          latency: 0,
          throughput: 0,
          memoryUsage: 0,
          cpuUsage: 0
        }
      }
    ];

    // Mock optimization rules
    const mockRules: OptimizationRule[] = [
      {
        id: uuidv4(),
        name: 'Auto-Scale During Peak Hours',
        description: 'Automatically increase resources during high-traffic periods',
        condition: 'call_volume > 100 AND response_time > 2000ms',
        action: 'scale_up_resources(2x)',
        priority: 'high',
        isActive: true,
        successRate: 87.5,
        timesTriggered: 23,
        lastTriggered: '2023-10-26T18:15:00Z',
        impact: {
          performanceGain: 35,
          costReduction: 12,
          satisfactionImprovement: 18
        }
      },
      {
        id: uuidv4(),
        name: 'Dynamic Script Optimization',
        description: 'Automatically adjust script based on conversation success rate',
        condition: 'conversation_success_rate < 75%',
        action: 'optimize_script_flow()',
        priority: 'medium',
        isActive: true,
        successRate: 92.3,
        timesTriggered: 15,
        lastTriggered: '2023-10-26T17:45:00Z',
        impact: {
          performanceGain: 22,
          costReduction: 8,
          satisfactionImprovement: 25
        }
      }
    ];

    // Mock real-time metrics
    const mockMetrics: RealTimeMetric[] = [
      {
        id: uuidv4(),
        agentId: voiceAgents[0]?.id || '',
        timestamp: new Date().toISOString(),
        metric: 'Response Time',
        value: 1250,
        threshold: 2000,
        status: 'normal',
        trend: 'down'
      },
      {
        id: uuidv4(),
        agentId: voiceAgents[0]?.id || '',
        timestamp: new Date().toISOString(),
        metric: 'Success Rate',
        value: 89.5,
        threshold: 85,
        status: 'normal',
        trend: 'up'
      },
      {
        id: uuidv4(),
        agentId: voiceAgents[1]?.id || '',
        timestamp: new Date().toISOString(),
        metric: 'CPU Usage',
        value: 85,
        threshold: 80,
        status: 'warning',
        trend: 'up'
      }
    ];

    // Mock optimization suggestions
    const mockSuggestions: OptimizationSuggestion[] = [
      {
        id: uuidv4(),
        agentId: voiceAgents[0]?.id || '',
        type: 'performance',
        title: 'Implement Response Caching',
        description: 'Cache frequent responses to reduce processing time by 40%',
        potentialGain: 40,
        confidence: 0.89,
        implementation: {
          difficulty: 'medium',
          timeRequired: 45,
          automated: true
        },
        status: 'new',
        createdAt: '2023-10-26T18:30:00Z'
      },
      {
        id: uuidv4(),
        agentId: voiceAgents[1]?.id || '',
        type: 'cost',
        title: 'Optimize LLM Model Usage',
        description: 'Switch to more cost-effective model for non-critical conversations',
        potentialGain: 25,
        confidence: 0.76,
        implementation: {
          difficulty: 'easy',
          timeRequired: 20,
          automated: false
        },
        status: 'testing',
        createdAt: '2023-10-26T18:15:00Z'
      }
    ];

    setMlModels(mockModels);
    setOptimizationRules(mockRules);
    setRealTimeMetrics(mockMetrics);
    setOptimizationSuggestions(mockSuggestions);
    setSelectedAgentId(voiceAgents[0]?.id || '');
  }, [voiceAgents]);

  const handleStartOptimization = async () => {
    if (!selectedAgentId) {
      toast.error('Please select an agent to optimize.');
      return;
    }

    setIsOptimizing(true);
    toast.loading('Starting ML-powered optimization...', { id: 'ml-optimization' });

    // Simulate optimization process
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Generate new optimization suggestion
    const newSuggestion: OptimizationSuggestion = {
      id: uuidv4(),
      agentId: selectedAgentId,
      type: ['performance', 'cost', 'quality', 'efficiency'][Math.floor(Math.random() * 4)] as any,
      title: 'AI-Generated Optimization',
      description: 'ML model has identified potential improvements for this agent.',
      potentialGain: Math.random() * 50 + 10,
      confidence: Math.random() * 0.4 + 0.6,
      implementation: {
        difficulty: ['easy', 'medium', 'hard'][Math.floor(Math.random() * 3)] as any,
        timeRequired: Math.floor(Math.random() * 60) + 15,
        automated: Math.random() > 0.5
      },
      status: 'new',
      createdAt: new Date().toISOString()
    };

    setOptimizationSuggestions(prev => [newSuggestion, ...prev]);
    setIsOptimizing(false);
    toast.success('ML optimization complete!', { id: 'ml-optimization' });
  };

  const handleImplementSuggestion = (suggestionId: string) => {
    setOptimizationSuggestions(prev => 
      prev.map(s => s.id === suggestionId ? { ...s, status: 'implemented' as const } : s)
    );
    toast.success('Optimization suggestion implemented!');
  };

  const handleToggleAutoOptimization = () => {
    setAutoOptimization(!autoOptimization);
    toast.success(`Auto-optimization ${!autoOptimization ? 'enabled' : 'disabled'}`);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'deployed': return 'text-green-500';
      case 'ready': return 'text-blue-500';
      case 'training': return 'text-yellow-500';
      case 'failed': return 'text-red-500';
      case 'normal': return 'text-green-500';
      case 'warning': return 'text-yellow-500';
      case 'critical': return 'text-red-500';
      default: return 'text-muted-foreground';
    }
  };

  const getTrendIcon = (trend: RealTimeMetric['trend']) => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-4 h-4 text-green-500" />;
      case 'down': return <TrendingUp className="w-4 h-4 text-red-500 rotate-180" />;
      case 'stable': return <Activity className="w-4 h-4 text-blue-500" />;
      default: return null;
    }
  };

  const selectedAgent = voiceAgents.find(a => a.id === selectedAgentId);
  const agentMetrics = realTimeMetrics.filter(m => m.agentId === selectedAgentId);
  const agentSuggestions = optimizationSuggestions.filter(s => s.agentId === selectedAgentId);

  return (
    <div className="p-6 bg-background min-h-screen text-foreground">
      <h1 className="text-3xl font-bold gradient-text mb-6">Real-Time Agent Performance Optimization with ML</h1>
      <p className="text-muted-foreground mb-8">
        Leverage advanced machine learning models to continuously optimize your Voice AI agents in real-time, automatically improving performance, reducing costs, and enhancing customer satisfaction.
      </p>

      {/* Optimization Controls */}
      <div className="card p-6 mb-8">
        <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
          <Brain className="w-6 h-6 mr-2 text-purple-400" /> ML Optimization Controls
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div>
            <label htmlFor="select-agent" className="block text-sm font-medium text-muted-foreground mb-1">
              Select Agent
            </label>
            <select
              id="select-agent"
              className="w-full input"
              value={selectedAgentId}
              onChange={(e) => setSelectedAgentId(e.target.value)}
            >
              <option value="">-- Select an Agent --</option>
              {voiceAgents.map(agent => (
                <option key={agent.id} value={agent.id}>{agent.name}</option>
              ))}
            </select>
          </div>
          <div className="flex items-end">
            <button
              onClick={handleStartOptimization}
              className="btn btn-primary w-full flex items-center justify-center"
              disabled={isOptimizing || !selectedAgentId}
            >
              {isOptimizing ? (
                <>
                  <RefreshCw className="w-5 h-5 mr-2 animate-spin" /> Optimizing...
                </>
              ) : (
                <>
                  <Zap className="w-5 h-5 mr-2" /> Start ML Optimization
                </>
              )}
            </button>
          </div>
          <div className="flex items-end">
            <button
              onClick={handleToggleAutoOptimization}
              className={`btn w-full flex items-center justify-center ${autoOptimization ? 'btn-primary' : 'btn-outline'}`}
            >
              <Settings className="w-5 h-5 mr-2" />
              {autoOptimization ? 'Auto-ON' : 'Auto-OFF'}
            </button>
          </div>
        </div>
      </div>

      {/* ML Models Status */}
      <div className="card p-6 mb-8">
        <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
          <Cpu className="w-6 h-6 mr-2 text-blue-400" /> ML Models Status
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {mlModels.map((model) => (
            <div key={model.id} className="bg-secondary p-4 rounded-lg border border-border">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-medium text-foreground">{model.name}</h3>
                <span className={`text-sm font-medium ${getStatusColor(model.status)}`}>
                  {model.status.charAt(0).toUpperCase() + model.status.slice(1)}
                </span>
              </div>
              <p className="text-sm text-muted-foreground mb-3">{model.type.replace('_', ' ').toUpperCase()}</p>
              <div className="space-y-2 text-xs text-muted-foreground">
                <div className="flex justify-between">
                  <span>Accuracy:</span>
                  <span className="font-medium text-foreground">{model.accuracy.toFixed(1)}%</span>
                </div>
                <div className="flex justify-between">
                  <span>Latency:</span>
                  <span className="font-medium text-foreground">{model.performance.latency}ms</span>
                </div>
                <div className="flex justify-between">
                  <span>Predictions:</span>
                  <span className="font-medium text-foreground">{model.predictions.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>CPU Usage:</span>
                  <span className="font-medium text-foreground">{model.performance.cpuUsage}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Real-Time Metrics */}
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
            <Activity className="w-6 h-6 mr-2 text-green-400" /> Real-Time Metrics
          </h2>
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {agentMetrics.map((metric) => (
              <div key={metric.id} className="bg-secondary p-4 rounded-lg border border-border">
                <div className="flex justify-between items-center mb-2">
                  <div className="flex items-center space-x-2">
                    <h3 className="font-medium text-foreground">{metric.metric}</h3>
                    {getTrendIcon(metric.trend)}
                  </div>
                  <span className={`text-sm font-medium ${getStatusColor(metric.status)}`}>
                    {metric.status.charAt(0).toUpperCase() + metric.status.slice(1)}
                  </span>
                </div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-2xl font-bold text-foreground">{metric.value}</span>
                  <span className="text-sm text-muted-foreground">Threshold: {metric.threshold}</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full ${
                      metric.status === 'critical' ? 'bg-red-500' :
                      metric.status === 'warning' ? 'bg-yellow-500' : 'bg-green-500'
                    }`}
                    style={{ width: `${Math.min((metric.value / metric.threshold) * 100, 100)}%` }}
                  ></div>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {new Date(metric.timestamp).toLocaleTimeString()}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Optimization Suggestions */}
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
            <Lightbulb className="w-6 h-6 mr-2 text-yellow-400" /> ML Optimization Suggestions
          </h2>
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {agentSuggestions.map((suggestion) => (
              <div key={suggestion.id} className="bg-secondary p-4 rounded-lg border border-border">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-medium text-foreground">{suggestion.title}</h3>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    suggestion.type === 'performance' ? 'bg-blue-100 text-blue-800' :
                    suggestion.type === 'cost' ? 'bg-green-100 text-green-800' :
                    suggestion.type === 'quality' ? 'bg-purple-100 text-purple-800' :
                    'bg-orange-100 text-orange-800'
                  }`}>
                    {suggestion.type}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground mb-3">{suggestion.description}</p>
                <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground mb-3">
                  <div>Potential Gain: <span className="font-medium text-foreground">{suggestion.potentialGain.toFixed(1)}%</span></div>
                  <div>Confidence: <span className="font-medium text-foreground">{(suggestion.confidence * 100).toFixed(1)}%</span></div>
                  <div>Difficulty: <span className="font-medium text-foreground">{suggestion.implementation.difficulty}</span></div>
                  <div>Time: <span className="font-medium text-foreground">{suggestion.implementation.timeRequired}m</span></div>
                </div>
                <div className="flex justify-between items-center">
                  <span className={`text-xs font-medium ${
                    suggestion.status === 'implemented' ? 'text-green-500' :
                    suggestion.status === 'testing' ? 'text-yellow-500' :
                    suggestion.status === 'rejected' ? 'text-red-500' : 'text-blue-500'
                  }`}>
                    {suggestion.status.charAt(0).toUpperCase() + suggestion.status.slice(1)}
                  </span>
                  {suggestion.status === 'new' && (
                    <button
                      onClick={() => handleImplementSuggestion(suggestion.id)}
                      className="btn btn-sm btn-primary"
                    >
                      <CheckCircle className="w-4 h-4 mr-1" /> Implement
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Optimization Rules */}
      <div className="card p-6 mt-6">
        <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
          <Target className="w-6 h-6 mr-2 text-orange-400" /> Active Optimization Rules
        </h2>
        <div className="space-y-4">
          {optimizationRules.map((rule) => (
            <div key={rule.id} className="bg-secondary p-4 rounded-lg border border-border">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-medium text-foreground">{rule.name}</h3>
                <div className="flex items-center space-x-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    rule.priority === 'critical' ? 'bg-red-100 text-red-800' :
                    rule.priority === 'high' ? 'bg-orange-100 text-orange-800' :
                    rule.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-green-100 text-green-800'
                  }`}>
                    {rule.priority}
                  </span>
                  <span className={`text-sm font-medium ${rule.isActive ? 'text-green-500' : 'text-red-500'}`}>
                    {rule.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>
              </div>
              <p className="text-sm text-muted-foreground mb-3">{rule.description}</p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs text-muted-foreground mb-3">
                <div>
                  <p>Success Rate: <span className="font-medium text-foreground">{rule.successRate.toFixed(1)}%</span></p>
                </div>
                <div>
                  <p>Triggered: <span className="font-medium text-foreground">{rule.timesTriggered} times</span></p>
                </div>
                <div>
                  <p>Performance Gain: <span className="font-medium text-foreground">{rule.impact.performanceGain}%</span></p>
                </div>
                <div>
                  <p>Cost Reduction: <span className="font-medium text-foreground">{rule.impact.costReduction}%</span></p>
                </div>
              </div>
              <div className="bg-background p-2 rounded text-xs font-mono text-foreground">
                <p><strong>Condition:</strong> {rule.condition}</p>
                <p><strong>Action:</strong> {rule.action}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MLPerformanceOptimization;
