import React, { useState, useEffect } from 'react';
import { 
  Play, 
  RotateCcw, 
  Trash2, 
  Eye, 
  CheckCircle, 
  XCircle, 
  Clock, 
  AlertTriangle,
  Activity,
  Phone,
  Bot,
  Settings,
  Zap,
  Shield,
  Database,
  Workflow,
  Webhook,
  Monitor
} from 'lucide-react';

interface DeploymentStep {
  id: string;
  name: string;
  status: 'pending' | 'active' | 'completed' | 'failed';
  description: string;
  icon: React.ComponentType<any>;
}

interface Deployment {
  id: string;
  agentName: string;
  environment: string;
  status: 'deploying' | 'deployed' | 'failed' | 'rolled-back';
  startTime: Date;
  endTime?: Date;
  steps: DeploymentStep[];
}

interface DeploymentConfig {
  agentName: string;
  voiceProvider: string;
  llmProvider: string;
  phoneNumber: string;
  environment: string;
  rollbackStrategy: string;
  healthCheck: string;
  enableMonitoring: boolean;
}

const VoiceAIDeployer: React.FC = () => {
  const [deployments, setDeployments] = useState<Deployment[]>([]);
  const [currentDeployment, setCurrentDeployment] = useState<Deployment | null>(null);
  const [isDeploying, setIsDeploying] = useState(false);
  const [deploymentProgress, setDeploymentProgress] = useState(0);
  const [logs, setLogs] = useState<Array<{ type: string; message: string; timestamp: string }>>([
    { type: 'info', message: 'System initialized. Ready for deployment.', timestamp: new Date().toLocaleTimeString() }
  ]);
  const [config, setConfig] = useState<DeploymentConfig>({
    agentName: '',
    voiceProvider: 'elevenlabs',
    llmProvider: 'openai',
    phoneNumber: '',
    environment: 'staging',
    rollbackStrategy: 'automatic',
    healthCheck: '60',
    enableMonitoring: true
  });

  const deploymentSteps: DeploymentStep[] = [
    { id: 'validate', name: 'Validate Configuration', description: 'Verify agent settings and dependencies', status: 'pending', icon: CheckCircle },
    { id: 'schema', name: 'Sync Schema Registry', description: 'Synchronize custom fields with GHL', status: 'pending', icon: Database },
    { id: 'agent', name: 'Create/Update Agent', description: 'Deploy voice AI agent configuration', status: 'pending', icon: Bot },
    { id: 'actions', name: 'Attach Actions', description: 'Connect custom actions and webhooks', status: 'pending', icon: Zap },
    { id: 'phone', name: 'Configure Phone Routing', description: 'Setup phone number and IVR routing', status: 'pending', icon: Phone },
    { id: 'workflows', name: 'Setup Workflows', description: 'Configure automation workflows', status: 'pending', icon: Workflow },
    { id: 'webhooks', name: 'Configure Webhooks', description: 'Setup webhook endpoints and security', status: 'pending', icon: Webhook },
    { id: 'health', name: 'Health Check', description: 'Verify agent functionality and connectivity', status: 'pending', icon: Shield },
    { id: 'monitoring', name: 'Enable Monitoring', description: 'Activate real-time monitoring and alerts', status: 'pending', icon: Monitor }
  ];

  useEffect(() => {
    loadDeploymentHistory();
  }, []);

  const loadDeploymentHistory = () => {
    const saved = localStorage.getItem('ghl-deployments');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setDeployments(parsed.map((d: any) => ({
          ...d,
          startTime: new Date(d.startTime),
          endTime: d.endTime ? new Date(d.endTime) : undefined
        })));
      } catch (error) {
        console.error('Failed to load deployment history:', error);
      }
    }
  };

  const saveDeploymentHistory = (newDeployments: Deployment[]) => {
    localStorage.setItem('ghl-deployments', JSON.stringify(newDeployments));
    setDeployments(newDeployments);
  };

  const addLog = (type: string, message: string) => {
    const newLog = {
      type,
      message,
      timestamp: new Date().toLocaleTimeString()
    };
    setLogs(prev => [...prev, newLog]);
  };

  const startDeployment = async () => {
    if (!config.agentName.trim() || !config.phoneNumber.trim()) {
      alert('Please fill in all required fields');
      return;
    }

    setIsDeploying(true);
    setDeploymentProgress(0);
    
    const newDeployment: Deployment = {
      id: Date.now().toString(),
      agentName: config.agentName,
      environment: config.environment,
      status: 'deploying',
      startTime: new Date(),
      steps: deploymentSteps.map(step => ({ ...step, status: 'pending' as const }))
    };

    setCurrentDeployment(newDeployment);
    addLog('info', `Starting deployment for agent: ${config.agentName}`);

    try {
      await executeDeploymentSteps(newDeployment);
      newDeployment.status = 'deployed';
      newDeployment.endTime = new Date();
      addLog('success', 'Deployment completed successfully!');
    } catch (error) {
      newDeployment.status = 'failed';
      newDeployment.endTime = new Date();
      addLog('error', `Deployment failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }

    const updatedDeployments = [newDeployment, ...deployments];
    saveDeploymentHistory(updatedDeployments);
    setCurrentDeployment(null);
    setIsDeploying(false);
  };

  const executeDeploymentSteps = async (deployment: Deployment) => {
    const steps = [...deploymentSteps];
    
    for (let i = 0; i < steps.length; i++) {
      const step = steps[i];
      
      // Update step status to active
      const updatedSteps = steps.map(s => 
        s.id === step.id ? { ...s, status: 'active' as const } : s
      );
      setCurrentDeployment(prev => prev ? { ...prev, steps: updatedSteps } : null);
      
      addLog('info', `Executing step: ${step.name}`);

      try {
        await executeStep(step);
        
        // Update step status to completed
        const completedSteps = updatedSteps.map(s => 
          s.id === step.id ? { ...s, status: 'completed' as const } : s
        );
        setCurrentDeployment(prev => prev ? { ...prev, steps: completedSteps } : null);
        
        addLog('success', `Step completed: ${step.name}`);
      } catch (error) {
        // Update step status to failed
        const failedSteps = updatedSteps.map(s => 
          s.id === step.id ? { ...s, status: 'failed' as const } : s
        );
        setCurrentDeployment(prev => prev ? { ...prev, steps: failedSteps } : null);
        
        addLog('error', `Step failed: ${step.name} - ${error instanceof Error ? error.message : 'Unknown error'}`);
        throw error;
      }

      // Update progress
      const progress = ((i + 1) / steps.length) * 100;
      setDeploymentProgress(progress);
      
      // Simulate processing time
      await delay(1000 + Math.random() * 2000);
    }
  };

  const executeStep = async (step: DeploymentStep) => {
    // Simulate API calls based on step
    const failureRates: { [key: string]: number } = {
      validate: 0.1,
      schema: 0.05,
      agent: 0.08,
      actions: 0.05,
      phone: 0.1,
      workflows: 0.05,
      webhooks: 0.1,
      health: 0.15,
      monitoring: 0.05
    };

    await delay(500 + Math.random() * 2000);
    
    if (Math.random() < (failureRates[step.id] || 0.1)) {
      throw new Error(`${step.name} failed`);
    }
  };

  const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

  const rollbackDeployment = (deploymentId: string) => {
    if (confirm('Are you sure you want to rollback this deployment?')) {
      const updatedDeployments = deployments.map(d => 
        d.id === deploymentId ? { ...d, status: 'rolled-back' as const } : d
      );
      saveDeploymentHistory(updatedDeployments);
      addLog('warning', `Rolled back deployment: ${deployments.find(d => d.id === deploymentId)?.agentName}`);
    }
  };

  const clearLogs = () => {
    setLogs([{ type: 'info', message: 'Logs cleared.', timestamp: new Date().toLocaleTimeString() }]);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'deployed': return 'text-green-400';
      case 'deploying': return 'text-blue-400';
      case 'failed': return 'text-red-400';
      case 'rolled-back': return 'text-yellow-400';
      default: return 'text-muted-foreground';
    }
  };

  const getStepIcon = (step: DeploymentStep) => {
    const IconComponent = step.icon;
    switch (step.status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-400" />;
      case 'failed':
        return <XCircle className="w-5 h-5 text-red-400" />;
      case 'active':
        return <Activity className="w-5 h-5 text-blue-400 animate-pulse" />;
      default:
        return <Clock className="w-5 h-5 text-muted-foreground" />;
    }
  };

  const formatDuration = (start: Date, end?: Date) => {
    if (!end) return 'In Progress';
    const diff = end.getTime() - start.getTime();
    const minutes = Math.floor(diff / 60000);
    const seconds = Math.floor((diff % 60000) / 1000);
    return `${minutes}m ${seconds}s`;
  };

  const stats = {
    total: deployments.length,
    active: deployments.filter(d => d.status === 'deployed').length,
    pending: deployments.filter(d => d.status === 'deploying').length,
    failed: deployments.filter(d => d.status === 'failed').length
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground gradient-text">Voice AI Deployer</h1>
          <p className="text-muted-foreground mt-2">Deploy, manage, and rollback your voice AI agents with confidence</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={startDeployment}
            disabled={isDeploying}
            className="btn btn-primary flex items-center gap-2"
          >
            {isDeploying ? (
              <>
                <Activity className="w-4 h-4 animate-spin" />
                Deploying...
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                Deploy Agent
              </>
            )}
          </button>
          <button
            onClick={() => deployments.length > 0 && rollbackDeployment(deployments[0].id)}
            disabled={deployments.length === 0}
            className="btn btn-destructive flex items-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            Rollback
          </button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="card p-6 text-center">
          <div className="text-3xl font-bold gradient-text mb-2">{stats.total}</div>
          <div className="text-sm text-muted-foreground">Total Deployments</div>
        </div>
        <div className="card p-6 text-center">
          <div className="text-3xl font-bold text-green-400 mb-2">{stats.active}</div>
          <div className="text-sm text-muted-foreground">Active Agents</div>
        </div>
        <div className="card p-6 text-center">
          <div className="text-3xl font-bold text-yellow-400 mb-2">{stats.pending}</div>
          <div className="text-sm text-muted-foreground">Pending</div>
        </div>
        <div className="card p-6 text-center">
          <div className="text-3xl font-bold text-red-400 mb-2">{stats.failed}</div>
          <div className="text-sm text-muted-foreground">Failed</div>
        </div>
      </div>

      {/* Current Deployment Progress */}
      {currentDeployment && (
        <div className="card p-6">
          <h3 className="text-xl font-semibold text-foreground mb-4">Deployment in Progress</h3>
          <div className="w-full bg-muted rounded-full h-4 relative overflow-hidden mb-4">
            <div 
              className="progress-bar bg-primary rounded-full h-full transition-all duration-500"
              style={{ width: `${deploymentProgress}%` }}
            />
          </div>
          <div className="flex justify-between text-sm text-muted-foreground mb-6">
            <span>Deploying {currentDeployment.agentName}...</span>
            <span>{Math.round(deploymentProgress)}%</span>
          </div>
          
          <div className="space-y-3">
            {currentDeployment.steps.map((step) => (
              <div key={step.id} className={`deployment-step p-4 rounded-lg border ${
                step.status === 'active' ? 'border-primary bg-primary/10' :
                step.status === 'completed' ? 'border-green-400 bg-green-400/10' :
                step.status === 'failed' ? 'border-red-400 bg-red-400/10' :
                'border-border'
              }`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getStepIcon(step)}
                    <div>
                      <div className="font-medium">{step.name}</div>
                      <div className="text-sm text-muted-foreground">{step.description}</div>
                    </div>
                  </div>
                  <span className={`text-sm font-medium ${
                    step.status === 'completed' ? 'text-green-400' :
                    step.status === 'failed' ? 'text-red-400' :
                    step.status === 'active' ? 'text-blue-400' :
                    'text-muted-foreground'
                  }`}>
                    {step.status === 'completed' ? 'Completed' :
                     step.status === 'failed' ? 'Failed' :
                     step.status === 'active' ? 'Running' :
                     'Pending'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Configuration Forms */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Agent Configuration */}
        <div className="card p-6">
          <h3 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
            <Bot className="w-5 h-5" />
            Agent Configuration
          </h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Agent Name *</label>
              <input
                type="text"
                value={config.agentName}
                onChange={(e) => setConfig(prev => ({ ...prev, agentName: e.target.value }))}
                className="w-full p-2 rounded-md bg-card border border-border"
                placeholder="e.g., Sales Assistant"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Voice Provider</label>
              <select
                value={config.voiceProvider}
                onChange={(e) => setConfig(prev => ({ ...prev, voiceProvider: e.target.value }))}
                className="w-full p-2 rounded-md bg-card border border-border"
              >
                <option value="elevenlabs">ElevenLabs</option>
                <option value="openai">OpenAI</option>
                <option value="azure">Azure</option>
                <option value="aws">AWS Polly</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">LLM Provider</label>
              <select
                value={config.llmProvider}
                onChange={(e) => setConfig(prev => ({ ...prev, llmProvider: e.target.value }))}
                className="w-full p-2 rounded-md bg-card border border-border"
              >
                <option value="openai">OpenAI GPT-4</option>
                <option value="anthropic">Anthropic Claude</option>
                <option value="azure">Azure OpenAI</option>
                <option value="google">Google Gemini</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Phone Number *</label>
              <input
                type="text"
                value={config.phoneNumber}
                onChange={(e) => setConfig(prev => ({ ...prev, phoneNumber: e.target.value }))}
                className="w-full p-2 rounded-md bg-card border border-border"
                placeholder="+1234567890"
              />
            </div>
          </div>
        </div>

        {/* Deployment Settings */}
        <div className="card p-6">
          <h3 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Deployment Settings
          </h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Environment</label>
              <select
                value={config.environment}
                onChange={(e) => setConfig(prev => ({ ...prev, environment: e.target.value }))}
                className="w-full p-2 rounded-md bg-card border border-border"
              >
                <option value="staging">Staging</option>
                <option value="production">Production</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Rollback Strategy</label>
              <select
                value={config.rollbackStrategy}
                onChange={(e) => setConfig(prev => ({ ...prev, rollbackStrategy: e.target.value }))}
                className="w-full p-2 rounded-md bg-card border border-border"
              >
                <option value="automatic">Automatic (on failure)</option>
                <option value="manual">Manual only</option>
                <option value="timed">Timed (5 min delay)</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Health Check Interval</label>
              <select
                value={config.healthCheck}
                onChange={(e) => setConfig(prev => ({ ...prev, healthCheck: e.target.value }))}
                className="w-full p-2 rounded-md bg-card border border-border"
              >
                <option value="30">30 seconds</option>
                <option value="60">1 minute</option>
                <option value="300">5 minutes</option>
              </select>
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                id="enable-monitoring"
                checked={config.enableMonitoring}
                onChange={(e) => setConfig(prev => ({ ...prev, enableMonitoring: e.target.checked }))}
                className="mr-2"
              />
              <label htmlFor="enable-monitoring" className="text-sm text-foreground">
                Enable real-time monitoring
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* Deployment History */}
      <div className="card p-6">
        <h3 className="text-xl font-semibold text-foreground mb-4">Deployment History</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="text-sm text-muted-foreground border-b border-border">
                <th className="py-2 px-4">Agent</th>
                <th className="py-2 px-4">Status</th>
                <th className="py-2 px-4">Environment</th>
                <th className="py-2 px-4">Deployed At</th>
                <th className="py-2 px-4">Duration</th>
                <th className="py-2 px-4">Actions</th>
              </tr>
            </thead>
            <tbody>
              {deployments.map((deployment) => (
                <tr key={deployment.id} className="border-b border-border">
                  <td className="py-2 px-4 font-medium">{deployment.agentName}</td>
                  <td className="py-2 px-4">
                    <span className={`font-medium ${getStatusColor(deployment.status)}`}>
                      {deployment.status.toUpperCase()}
                    </span>
                  </td>
                  <td className="py-2 px-4">{deployment.environment}</td>
                  <td className="py-2 px-4">{deployment.startTime.toLocaleString()}</td>
                  <td className="py-2 px-4">{formatDuration(deployment.startTime, deployment.endTime)}</td>
                  <td className="py-2 px-4">
                    <div className="flex gap-2">
                      <button className="btn btn-outline btn-sm flex items-center gap-1">
                        <Eye className="w-3 h-3" />
                        View
                      </button>
                      {deployment.status === 'deployed' && (
                        <button 
                          onClick={() => rollbackDeployment(deployment.id)}
                          className="btn btn-destructive btn-sm flex items-center gap-1"
                        >
                          <RotateCcw className="w-3 h-3" />
                          Rollback
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Deployment Logs */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold text-foreground">Deployment Logs</h3>
          <button onClick={clearLogs} className="btn btn-outline flex items-center gap-2">
            <Trash2 className="w-4 h-4" />
            Clear Logs
          </button>
        </div>
        <div className="bg-muted p-4 rounded-md h-64 overflow-y-auto font-mono text-sm">
          {logs.map((log, index) => (
            <div key={index} className={`log-entry py-1 ${
              log.type === 'error' ? 'text-red-400' :
              log.type === 'warning' ? 'text-yellow-400' :
              log.type === 'success' ? 'text-green-400' :
              'text-blue-400'
            }`}>
              [{log.timestamp}] {log.message}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default VoiceAIDeployer;
