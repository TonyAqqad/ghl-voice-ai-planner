import React, { useState } from 'react';
import { Plus, Trash2, Save, Play, Settings, Zap, Phone, MessageSquare, Bot, Code, Webhook, ChevronDown, ChevronRight, Copy, Download } from 'lucide-react';
import { useStore } from '../../store/useStore';

interface AICustomAction {
  id: string;
  name: string;
  description: string;
  trigger: 'call_start' | 'call_end' | 'transcript_ready' | 'intent_detected' | 'custom_event';
  webhookUrl: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  headers: Record<string, string>;
  payload: string;
  conditions: Array<{
    field: string;
    operator: 'equals' | 'contains' | 'starts_with' | 'ends_with' | 'greater_than' | 'less_than';
    value: string;
  }>;
  responseMapping: Record<string, string>;
  timeout: number;
  retryAttempts: number;
  enabled: boolean;
}

const AICustomActionWorkflowCreator: React.FC = () => {
  const { addWorkflow } = useStore();
  const [actions, setActions] = useState<AICustomAction[]>([]);
  const [selectedAction, setSelectedAction] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);

  const createNewAction = (): AICustomAction => ({
    id: `action_${Date.now()}`,
    name: '',
    description: '',
    trigger: 'call_start',
    webhookUrl: '',
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    payload: '{\n  "call_id": "{{call_id}}",\n  "contact_id": "{{contact_id}}",\n  "transcript": "{{transcript}}",\n  "intent": "{{intent}}",\n  "confidence": "{{confidence}}"\n}',
    conditions: [],
    responseMapping: {},
    timeout: 30,
    retryAttempts: 3,
    enabled: true
  });

  const addAction = () => {
    const newAction = createNewAction();
    setActions([...actions, newAction]);
    setSelectedAction(newAction.id);
    setIsEditing(true);
  };

  const updateAction = (actionId: string, updates: Partial<AICustomAction>) => {
    setActions(actions.map(action => 
      action.id === actionId ? { ...action, ...updates } : action
    ));
  };

  const deleteAction = (actionId: string) => {
    setActions(actions.filter(action => action.id !== actionId));
    if (selectedAction === actionId) {
      setSelectedAction(null);
      setIsEditing(false);
    }
  };

  const duplicateAction = (actionId: string) => {
    const action = actions.find(a => a.id === actionId);
    if (action) {
      const newAction = {
        ...action,
        id: `action_${Date.now()}`,
        name: `${action.name} (Copy)`
      };
      setActions([...actions, newAction]);
    }
  };

  const saveWorkflow = () => {
    if (actions.length === 0) return;
    
    const workflow = {
      id: `ai_workflow_${Date.now()}`,
      name: 'AI Custom Actions Workflow',
      description: 'Voice AI custom actions for real-time call processing',
      trigger: {
        type: 'ai_custom_actions' as const,
        conditions: {}
      },
      nodes: actions.map(action => ({
        id: action.id,
        type: 'ai_custom_action' as const,
        config: action,
        position: { x: 100, y: 100 }
      })),
      edges: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    addWorkflow(workflow);
  };

  const exportActions = () => {
    const exportData = {
      actions: actions,
      exportedAt: new Date().toISOString(),
      version: '1.0.0'
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'ai-custom-actions.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const selectedActionData = actions.find(a => a.id === selectedAction);

  const triggerOptions = [
    { value: 'call_start', label: 'Call Start', description: 'When a call begins' },
    { value: 'call_end', label: 'Call End', description: 'When a call ends' },
    { value: 'transcript_ready', label: 'Transcript Ready', description: 'When transcript is available' },
    { value: 'intent_detected', label: 'Intent Detected', description: 'When AI detects an intent' },
    { value: 'custom_event', label: 'Custom Event', description: 'Custom trigger event' }
  ];

  const mergeTags = [
    { tag: '{{call_id}}', description: 'Unique call identifier' },
    { tag: '{{contact_id}}', description: 'Contact ID in GHL' },
    { tag: '{{contact_name}}', description: 'Contact full name' },
    { tag: '{{contact_phone}}', description: 'Contact phone number' },
    { tag: '{{contact_email}}', description: 'Contact email address' },
    { tag: '{{transcript}}', description: 'Full call transcript' },
    { tag: '{{intent}}', description: 'Detected intent' },
    { tag: '{{confidence}}', description: 'Intent confidence score' },
    { tag: '{{call_duration}}', description: 'Call duration in seconds' },
    { tag: '{{call_direction}}', description: 'inbound or outbound' },
    { tag: '{{agent_name}}', description: 'Voice AI agent name' },
    { tag: '{{timestamp}}', description: 'Current timestamp' }
  ];

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">AI Custom Action Workflow Creator</h1>
          <p className="text-muted-foreground">
            Create real-time webhook actions that trigger during Voice AI calls
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Actions List */}
          <div className="lg:col-span-1">
            <div className="card">
              <div className="card-header">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold">Custom Actions</h2>
                  <button
                    onClick={addAction}
                    className="btn btn-primary btn-sm"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    New Action
                  </button>
                </div>
              </div>
              <div className="card-content">
                {actions.length === 0 ? (
                  <div className="text-center text-muted-foreground py-8">
                    <Bot className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p className="text-lg font-medium mb-2">No Actions Created</p>
                    <p className="text-sm">Create your first AI custom action</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {actions.map((action) => (
                      <div
                        key={action.id}
                        className={`p-3 rounded-lg border cursor-pointer transition-all duration-200 ${
                          selectedAction === action.id
                            ? 'border-primary bg-primary/5'
                            : 'border-border hover:border-primary/50'
                        }`}
                        onClick={() => setSelectedAction(action.id)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className={`w-2 h-2 rounded-full ${
                              action.enabled ? 'bg-green-500' : 'bg-gray-400'
                            }`} />
                            <div>
                              <h3 className="font-medium text-sm">
                                {action.name || 'Unnamed Action'}
                              </h3>
                              <p className="text-xs text-muted-foreground">
                                {triggerOptions.find(t => t.value === action.trigger)?.label}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-1">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                duplicateAction(action.id);
                              }}
                              className="p-1 hover:bg-accent rounded"
                            >
                              <Copy className="w-3 h-3" />
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                deleteAction(action.id);
                              }}
                              className="p-1 hover:bg-destructive/20 rounded text-destructive"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Export Actions */}
            {actions.length > 0 && (
              <div className="card mt-4">
                <div className="card-content">
                  <div className="flex space-x-2">
                    <button
                      onClick={exportActions}
                      className="btn btn-outline btn-sm flex-1"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Export
                    </button>
                    <button
                      onClick={saveWorkflow}
                      className="btn btn-primary btn-sm flex-1"
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Save
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Action Editor */}
          <div className="lg:col-span-2">
            {selectedActionData ? (
              <div className="card">
                <div className="card-header">
                  <div className="flex items-center justify-between">
                    <h2 className="text-xl font-semibold">
                      {isEditing ? 'Edit Action' : 'View Action'}
                    </h2>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => setIsEditing(!isEditing)}
                        className="btn btn-outline btn-sm"
                      >
                        {isEditing ? 'View' : 'Edit'}
                      </button>
                    </div>
                  </div>
                </div>
                <div className="card-content space-y-6">
                  {/* Basic Information */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Basic Information</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">Action Name</label>
                        <input
                          type="text"
                          value={selectedActionData.name}
                          onChange={(e) => updateAction(selectedAction, { name: e.target.value })}
                          disabled={!isEditing}
                          placeholder="Enter action name"
                          className="w-full p-3 border rounded-md bg-card text-foreground disabled:opacity-50"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Trigger</label>
                        <select
                          value={selectedActionData.trigger}
                          onChange={(e) => updateAction(selectedAction, { trigger: e.target.value as any })}
                          disabled={!isEditing}
                          className="w-full p-3 border rounded-md bg-card text-foreground disabled:opacity-50"
                        >
                          {triggerOptions.map(option => (
                            <option key={option.value} value={option.value}>
                              {option.label}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Description</label>
                      <textarea
                        value={selectedActionData.description}
                        onChange={(e) => updateAction(selectedAction, { description: e.target.value })}
                        disabled={!isEditing}
                        placeholder="Describe what this action does"
                        rows={3}
                        className="w-full p-3 border rounded-md bg-card text-foreground disabled:opacity-50"
                      />
                    </div>
                  </div>

                  {/* Webhook Configuration */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Webhook Configuration</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">Webhook URL</label>
                        <input
                          type="url"
                          value={selectedActionData.webhookUrl}
                          onChange={(e) => updateAction(selectedAction, { webhookUrl: e.target.value })}
                          disabled={!isEditing}
                          placeholder="https://your-webhook-url.com"
                          className="w-full p-3 border rounded-md bg-card text-foreground disabled:opacity-50"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Method</label>
                        <select
                          value={selectedActionData.method}
                          onChange={(e) => updateAction(selectedAction, { method: e.target.value as any })}
                          disabled={!isEditing}
                          className="w-full p-3 border rounded-md bg-card text-foreground disabled:opacity-50"
                        >
                          <option value="GET">GET</option>
                          <option value="POST">POST</option>
                          <option value="PUT">PUT</option>
                          <option value="DELETE">DELETE</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Timeout (seconds)</label>
                        <input
                          type="number"
                          value={selectedActionData.timeout}
                          onChange={(e) => updateAction(selectedAction, { timeout: parseInt(e.target.value) })}
                          disabled={!isEditing}
                          min="1"
                          max="300"
                          className="w-full p-3 border rounded-md bg-card text-foreground disabled:opacity-50"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Payload Configuration */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Payload Configuration</h3>
                    <div>
                      <label className="block text-sm font-medium mb-2">Request Payload</label>
                      <textarea
                        value={selectedActionData.payload}
                        onChange={(e) => updateAction(selectedAction, { payload: e.target.value })}
                        disabled={!isEditing}
                        placeholder="Enter JSON payload"
                        rows={8}
                        className="w-full p-3 border rounded-md bg-card text-foreground disabled:opacity-50 font-mono text-sm"
                      />
                    </div>
                  </div>

                  {/* Merge Tags Reference */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Available Merge Tags</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {mergeTags.map((tag) => (
                        <div
                          key={tag.tag}
                          className="flex items-center justify-between p-2 bg-muted rounded-md"
                        >
                          <div>
                            <code className="text-sm font-mono text-primary">{tag.tag}</code>
                            <p className="text-xs text-muted-foreground">{tag.description}</p>
                          </div>
                          <button
                            onClick={() => {
                              const textarea = document.querySelector('textarea[placeholder="Enter JSON payload"]') as HTMLTextAreaElement;
                              if (textarea) {
                                const start = textarea.selectionStart;
                                const end = textarea.selectionEnd;
                                const text = textarea.value;
                                const before = text.substring(0, start);
                                const after = text.substring(end, text.length);
                                const newText = before + tag.tag + after;
                                updateAction(selectedAction, { payload: newText });
                                setTimeout(() => {
                                  textarea.focus();
                                  textarea.setSelectionRange(start + tag.tag.length, start + tag.tag.length);
                                }, 0);
                              }
                            }}
                            className="p-1 hover:bg-accent rounded text-xs"
                          >
                            Insert
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Conditions */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Conditions</h3>
                    <p className="text-sm text-muted-foreground">
                      Add conditions to control when this action should execute
                    </p>
                    <div className="space-y-2">
                      {selectedActionData.conditions.map((condition, index) => (
                        <div key={index} className="flex items-center space-x-2 p-3 bg-muted rounded-md">
                          <select
                            value={condition.field}
                            onChange={(e) => {
                              const newConditions = [...selectedActionData.conditions];
                              newConditions[index].field = e.target.value;
                              updateAction(selectedAction, { conditions: newConditions });
                            }}
                            disabled={!isEditing}
                            className="p-2 border rounded bg-card text-foreground disabled:opacity-50"
                          >
                            <option value="intent">Intent</option>
                            <option value="confidence">Confidence</option>
                            <option value="call_duration">Call Duration</option>
                            <option value="contact_name">Contact Name</option>
                          </select>
                          <select
                            value={condition.operator}
                            onChange={(e) => {
                              const newConditions = [...selectedActionData.conditions];
                              newConditions[index].operator = e.target.value as any;
                              updateAction(selectedAction, { conditions: newConditions });
                            }}
                            disabled={!isEditing}
                            className="p-2 border rounded bg-card text-foreground disabled:opacity-50"
                          >
                            <option value="equals">Equals</option>
                            <option value="contains">Contains</option>
                            <option value="starts_with">Starts With</option>
                            <option value="ends_with">Ends With</option>
                            <option value="greater_than">Greater Than</option>
                            <option value="less_than">Less Than</option>
                          </select>
                          <input
                            type="text"
                            value={condition.value}
                            onChange={(e) => {
                              const newConditions = [...selectedActionData.conditions];
                              newConditions[index].value = e.target.value;
                              updateAction(selectedAction, { conditions: newConditions });
                            }}
                            disabled={!isEditing}
                            placeholder="Value"
                            className="flex-1 p-2 border rounded bg-card text-foreground disabled:opacity-50"
                          />
                          {isEditing && (
                            <button
                              onClick={() => {
                                const newConditions = selectedActionData.conditions.filter((_, i) => i !== index);
                                updateAction(selectedAction, { conditions: newConditions });
                              }}
                              className="p-2 hover:bg-destructive/20 rounded text-destructive"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      ))}
                      {isEditing && (
                        <button
                          onClick={() => {
                            const newConditions = [...selectedActionData.conditions, {
                              field: 'intent',
                              operator: 'equals' as const,
                              value: ''
                            }];
                            updateAction(selectedAction, { conditions: newConditions });
                          }}
                          className="btn btn-outline btn-sm"
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          Add Condition
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="card">
                <div className="card-content">
                  <div className="text-center text-muted-foreground py-12">
                    <Bot className="w-16 h-16 mx-auto mb-4 opacity-50" />
                    <p className="text-lg font-medium mb-2">No Action Selected</p>
                    <p className="text-sm">Select an action from the list to view or edit it</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AICustomActionWorkflowCreator;
