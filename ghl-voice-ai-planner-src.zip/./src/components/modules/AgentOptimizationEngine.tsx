import React, { useState, useEffect } from 'react';
import { 
  Zap, 
  Target, 
  TrendingUp, 
  Brain, 
  Settings, 
  Play, 
  Pause, 
  RefreshCw, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Info, 
  BarChart3, 
  LineChart, 
  PieChart, 
  Activity, 
  Clock, 
  Users, 
  MessageSquare, 
  Phone, 
  Mic, 
  Headphones, 
  Volume2, 
  VolumeX, 
  RotateCcw, 
  Download, 
  Upload, 
  Save, 
  Edit, 
  Trash2, 
  Plus, 
  Minus, 
  ChevronDown, 
  ChevronRight, 
  Eye, 
  EyeOff, 
  Filter, 
  Search, 
  SortAsc, 
  SortDesc, 
  MoreHorizontal, 
  Star, 
  ThumbsUp, 
  ThumbsDown, 
  Heart, 
  Smile, 
  Frown, 
  Meh, 
  Award, 
  Trophy, 
  Medal, 
  Crown, 
  Flame, 
  Lightning, 
  Rocket, 
  Shield, 
  Lock, 
  Unlock, 
  Key, 
  Wrench, 
  Cog, 
  Sliders, 
  ToggleLeft, 
  ToggleRight, 
  Switch, 
  Power, 
  PowerOff, 
  Battery, 
  BatteryCharging, 
  Wifi, 
  WifiOff, 
  Signal, 
  SignalZero, 
  SignalOne, 
  SignalTwo, 
  SignalThree, 
  SignalFour, 
  SignalFive
} from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';

interface OptimizationRule {
  id: string;
  name: string;
  description: string;
  type: 'performance' | 'conversion' | 'efficiency' | 'quality' | 'cost';
  priority: 'low' | 'medium' | 'high' | 'critical';
  status: 'active' | 'inactive' | 'testing' | 'paused';
  agentId: string;
  agentName: string;
  conditions: Array<{
    field: string;
    operator: string;
    value: any;
    weight: number;
  }>;
  actions: Array<{
    type: string;
    parameters: Record<string, any>;
    weight: number;
  }>;
  metrics: {
    before: number;
    after: number;
    improvement: number;
    confidence: number;
  };
  createdAt: string;
  lastRun: string | null;
  runCount: number;
  successRate: number;
}

interface OptimizationResult {
  id: string;
  ruleId: string;
  agentId: string;
  timestamp: string;
  status: 'success' | 'failed' | 'partial';
  metrics: {
    conversionRate: number;
    avgDuration: number;
    satisfactionScore: number;
    costPerCall: number;
    errorRate: number;
  };
  changes: Array<{
    field: string;
    oldValue: any;
    newValue: any;
    impact: number;
  }>;
  logs: Array<{
    timestamp: string;
    level: 'info' | 'warning' | 'error' | 'success';
    message: string;
  }>;
}

interface AgentPerformance {
  id: string;
  name: string;
  type: string;
  status: 'active' | 'inactive' | 'testing' | 'optimizing';
  metrics: {
    totalCalls: number;
    conversionRate: number;
    avgDuration: number;
    satisfactionScore: number;
    costPerCall: number;
    errorRate: number;
    uptime: number;
  };
  trends: {
    conversionRate: number;
    avgDuration: number;
    satisfactionScore: number;
    costPerCall: number;
  };
  optimization: {
    score: number;
    potential: number;
    lastOptimized: string | null;
    activeRules: number;
    totalRules: number;
  };
  recommendations: Array<{
    id: string;
    type: string;
    title: string;
    description: string;
    impact: 'low' | 'medium' | 'high';
    effort: 'low' | 'medium' | 'high';
    priority: number;
  }>;
}

interface OptimizationConfig {
  autoOptimize: boolean;
  optimizationThreshold: number;
  testingDuration: number;
  rollbackThreshold: number;
  maxConcurrentOptimizations: number;
  notificationSettings: {
    email: boolean;
    sms: boolean;
    webhook: boolean;
  };
}

const AgentOptimizationEngine: React.FC = () => {
  const { darkMode } = useStore();
  const [agents, setAgents] = useState<AgentPerformance[]>([]);
  const [rules, setRules] = useState<OptimizationRule[]>([]);
  const [results, setResults] = useState<OptimizationResult[]>([]);
  const [config, setConfig] = useState<OptimizationConfig>({
    autoOptimize: true,
    optimizationThreshold: 0.05,
    testingDuration: 24,
    rollbackThreshold: 0.1,
    maxConcurrentOptimizations: 3,
    notificationSettings: {
      email: true,
      sms: false,
      webhook: true
    }
  });
  const [selectedAgent, setSelectedAgent] = useState<string>('all');
  const [selectedRule, setSelectedRule] = useState<string>('all');
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'agents' | 'rules' | 'results' | 'config'>('overview');

  // Sample data - in real app this would come from optimization API
  useEffect(() => {
    const sampleAgents: AgentPerformance[] = [
      {
        id: 'agent_1',
        name: 'F45 Fitness Agent',
        type: 'fitness',
        status: 'active',
        metrics: {
          totalCalls: 1250,
          conversionRate: 0.23,
          avgDuration: 195,
          satisfactionScore: 0.91,
          costPerCall: 2.45,
          errorRate: 0.02,
          uptime: 99.8
        },
        trends: {
          conversionRate: 0.05,
          avgDuration: -12,
          satisfactionScore: 0.03,
          costPerCall: -0.15
        },
        optimization: {
          score: 87,
          potential: 15,
          lastOptimized: '2024-01-15T10:30:00Z',
          activeRules: 5,
          totalRules: 8
        },
        recommendations: [
          {
            id: 'rec_1',
            type: 'script_optimization',
            title: 'Optimize Trial Booking Script',
            description: 'Refine the trial booking conversation flow to reduce call duration by 15% while maintaining conversion rate.',
            impact: 'high',
            effort: 'medium',
            priority: 1
          },
          {
            id: 'rec_2',
            type: 'intent_recognition',
            title: 'Improve Intent Recognition',
            description: 'Add more training data for fitness-related intents to improve accuracy by 8%.',
            impact: 'medium',
            effort: 'low',
            priority: 2
          }
        ]
      },
      {
        id: 'agent_2',
        name: 'Legal Consultation Agent',
        type: 'legal',
        status: 'optimizing',
        metrics: {
          totalCalls: 890,
          conversionRate: 0.18,
          avgDuration: 240,
          satisfactionScore: 0.88,
          costPerCall: 3.20,
          errorRate: 0.04,
          uptime: 98.5
        },
        trends: {
          conversionRate: 0.02,
          avgDuration: -8,
          satisfactionScore: 0.01,
          costPerCall: -0.10
        },
        optimization: {
          score: 72,
          potential: 25,
          lastOptimized: '2024-01-15T14:15:00Z',
          activeRules: 3,
          totalRules: 6
        },
        recommendations: [
          {
            id: 'rec_3',
            type: 'performance_optimization',
            title: 'Reduce Call Duration',
            description: 'Streamline the case assessment process to reduce average call duration by 20%.',
            impact: 'high',
            effort: 'high',
            priority: 1
          },
          {
            id: 'rec_4',
            type: 'transfer_optimization',
            title: 'Optimize Transfer Logic',
            description: 'Improve the transfer process to reduce wait times and improve customer satisfaction.',
            impact: 'medium',
            effort: 'medium',
            priority: 3
          }
        ]
      }
    ];

    const sampleRules: OptimizationRule[] = [
      {
        id: 'rule_1',
        name: 'Trial Booking Script Optimization',
        description: 'Automatically optimize trial booking scripts based on conversion rate and call duration',
        type: 'conversion',
        priority: 'high',
        status: 'active',
        agentId: 'agent_1',
        agentName: 'F45 Fitness Agent',
        conditions: [
          { field: 'conversion_rate', operator: '<', value: 0.25, weight: 0.4 },
          { field: 'avg_duration', operator: '>', value: 200, weight: 0.3 },
          { field: 'satisfaction_score', operator: '>', value: 0.85, weight: 0.3 }
        ],
        actions: [
          { type: 'script_optimization', parameters: { focus: 'trial_booking', target_duration: 180 }, weight: 0.6 },
          { type: 'intent_training', parameters: { intents: ['trial_interest', 'fitness_goals'] }, weight: 0.4 }
        ],
        metrics: {
          before: 0.18,
          after: 0.23,
          improvement: 0.05,
          confidence: 0.89
        },
        createdAt: '2024-01-10T09:00:00Z',
        lastRun: '2024-01-15T10:30:00Z',
        runCount: 15,
        successRate: 0.87
      },
      {
        id: 'rule_2',
        name: 'Call Duration Reduction',
        description: 'Reduce call duration while maintaining quality metrics',
        type: 'efficiency',
        priority: 'medium',
        status: 'testing',
        agentId: 'agent_2',
        agentName: 'Legal Consultation Agent',
        conditions: [
          { field: 'avg_duration', operator: '>', value: 220, weight: 0.5 },
          { field: 'satisfaction_score', operator: '>', value: 0.80, weight: 0.5 }
        ],
        actions: [
          { type: 'script_condensation', parameters: { target_reduction: 0.15 }, weight: 0.7 },
          { type: 'intent_streamlining', parameters: { focus: 'case_assessment' }, weight: 0.3 }
        ],
        metrics: {
          before: 240,
          after: 220,
          improvement: -20,
          confidence: 0.76
        },
        createdAt: '2024-01-12T14:00:00Z',
        lastRun: '2024-01-15T14:15:00Z',
        runCount: 8,
        successRate: 0.75
      }
    ];

    const sampleResults: OptimizationResult[] = [
      {
        id: 'result_1',
        ruleId: 'rule_1',
        agentId: 'agent_1',
        timestamp: '2024-01-15T10:30:00Z',
        status: 'success',
        metrics: {
          conversionRate: 0.23,
          avgDuration: 195,
          satisfactionScore: 0.91,
          costPerCall: 2.45,
          errorRate: 0.02
        },
        changes: [
          { field: 'script_greeting', oldValue: 'long', newValue: 'optimized', impact: 0.15 },
          { field: 'intent_confidence', oldValue: 0.85, newValue: 0.92, impact: 0.08 }
        ],
        logs: [
          { timestamp: '2024-01-15T10:30:00Z', level: 'info', message: 'Optimization started' },
          { timestamp: '2024-01-15T10:31:00Z', level: 'info', message: 'Script analysis completed' },
          { timestamp: '2024-01-15T10:32:00Z', level: 'success', message: 'Optimization applied successfully' }
        ]
      }
    ];

    setAgents(sampleAgents);
    setRules(sampleRules);
    setResults(sampleResults);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-400 bg-green-100';
      case 'inactive': return 'text-gray-400 bg-gray-100';
      case 'testing': return 'text-blue-400 bg-blue-100';
      case 'optimizing': return 'text-purple-400 bg-purple-100';
      case 'paused': return 'text-yellow-400 bg-yellow-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'text-red-400 bg-red-100';
      case 'high': return 'text-orange-400 bg-orange-100';
      case 'medium': return 'text-yellow-400 bg-yellow-100';
      case 'low': return 'text-green-400 bg-green-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'text-red-400';
      case 'medium': return 'text-yellow-400';
      case 'low': return 'text-green-400';
      default: return 'text-gray-400';
    }
  };

  const getEffortColor = (effort: string) => {
    switch (effort) {
      case 'high': return 'text-red-400';
      case 'medium': return 'text-yellow-400';
      case 'low': return 'text-green-400';
      default: return 'text-gray-400';
    }
  };

  const handleOptimizeAgent = (agentId: string) => {
    setIsOptimizing(true);
    toast.success(`Starting optimization for agent: ${agents.find(a => a.id === agentId)?.name}`);
    
    // Simulate optimization process
    setTimeout(() => {
      setIsOptimizing(false);
      toast.success('Optimization completed successfully!');
    }, 3000);
  };

  const handleToggleRule = (ruleId: string) => {
    setRules(prev => 
      prev.map(rule => 
        rule.id === ruleId 
          ? { 
              ...rule, 
              status: rule.status === 'active' ? 'inactive' : 'active' as any 
            }
          : rule
      )
    );
    toast.success('Rule status updated');
  };

  const renderOverviewTab = () => (
    <div className="space-y-6">
      {/* Optimization Status */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Agents</p>
              <p className="text-2xl font-bold text-foreground">{agents.length}</p>
            </div>
            <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-primary" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Active Rules</p>
              <p className="text-2xl font-bold text-foreground">
                {rules.filter(r => r.status === 'active').length}
              </p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <Zap className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Avg Optimization Score</p>
              <p className="text-2xl font-bold text-foreground">
                {Math.round(agents.reduce((sum, a) => sum + a.optimization.score, 0) / agents.length)}
              </p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Target className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Success Rate</p>
              <p className="text-2xl font-bold text-foreground">
                {Math.round(rules.reduce((sum, r) => sum + r.successRate, 0) / rules.length * 100)}%
              </p>
            </div>
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <Trophy className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Agent Performance Overview */}
      <div className="card p-6">
        <h2 className="text-xl font-semibold text-foreground mb-6">Agent Performance Overview</h2>
        <div className="space-y-4">
          {agents.map((agent) => (
            <div key={agent.id} className="flex items-center justify-between p-4 bg-secondary rounded-lg">
              <div className="flex items-center space-x-4">
                <div className={`w-3 h-3 rounded-full ${getStatusColor(agent.status).split(' ')[0]}`}></div>
                <div>
                  <h3 className="font-semibold text-foreground">{agent.name}</h3>
                  <p className="text-sm text-muted-foreground">
                    {agent.metrics.totalCalls} calls • {Math.round(agent.metrics.conversionRate * 100)}% conversion
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <p className="text-sm font-medium text-foreground">Optimization Score</p>
                  <p className="text-lg font-bold text-primary">{agent.optimization.score}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-foreground">Potential</p>
                  <p className="text-lg font-bold text-orange-400">+{agent.optimization.potential}%</p>
                </div>
                <button
                  onClick={() => handleOptimizeAgent(agent.id)}
                  disabled={isOptimizing || agent.status === 'optimizing'}
                  className="btn btn-primary btn-sm"
                >
                  {isOptimizing ? (
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Zap className="w-4 h-4 mr-2" />
                  )}
                  Optimize
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderAgentsTab = () => (
    <div className="space-y-6">
      {agents.map((agent) => (
        <div key={agent.id} className="card p-6">
          <div className="flex items-start justify-between mb-6">
            <div>
              <h3 className="text-xl font-semibold text-foreground">{agent.name}</h3>
              <p className="text-muted-foreground capitalize">{agent.type} Agent</p>
            </div>
            <div className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(agent.status)}`}>
              {agent.status}
            </div>
          </div>

          {/* Metrics Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-secondary p-4 rounded-lg">
              <p className="text-sm text-muted-foreground">Conversion Rate</p>
              <p className="text-2xl font-bold text-foreground">
                {Math.round(agent.metrics.conversionRate * 100)}%
              </p>
              <p className={`text-sm ${agent.trends.conversionRate > 0 ? 'text-green-400' : 'text-red-400'}`}>
                {agent.trends.conversionRate > 0 ? '+' : ''}{Math.round(agent.trends.conversionRate * 100)}%
              </p>
            </div>
            <div className="bg-secondary p-4 rounded-lg">
              <p className="text-sm text-muted-foreground">Avg Duration</p>
              <p className="text-2xl font-bold text-foreground">{agent.metrics.avgDuration}s</p>
              <p className={`text-sm ${agent.trends.avgDuration < 0 ? 'text-green-400' : 'text-red-400'}`}>
                {agent.trends.avgDuration > 0 ? '+' : ''}{agent.trends.avgDuration}s
              </p>
            </div>
            <div className="bg-secondary p-4 rounded-lg">
              <p className="text-sm text-muted-foreground">Satisfaction</p>
              <p className="text-2xl font-bold text-foreground">
                {Math.round(agent.metrics.satisfactionScore * 100)}%
              </p>
              <p className={`text-sm ${agent.trends.satisfactionScore > 0 ? 'text-green-400' : 'text-red-400'}`}>
                {agent.trends.satisfactionScore > 0 ? '+' : ''}{Math.round(agent.trends.satisfactionScore * 100)}%
              </p>
            </div>
            <div className="bg-secondary p-4 rounded-lg">
              <p className="text-sm text-muted-foreground">Cost per Call</p>
              <p className="text-2xl font-bold text-foreground">${agent.metrics.costPerCall}</p>
              <p className={`text-sm ${agent.trends.costPerCall < 0 ? 'text-green-400' : 'text-red-400'}`}>
                {agent.trends.costPerCall > 0 ? '+' : ''}${agent.trends.costPerCall}
              </p>
            </div>
          </div>

          {/* Recommendations */}
          <div>
            <h4 className="text-lg font-semibold text-foreground mb-4">Optimization Recommendations</h4>
            <div className="space-y-3">
              {agent.recommendations.map((rec) => (
                <div key={rec.id} className="flex items-start space-x-3 p-3 bg-secondary rounded-lg">
                  <div className="flex-1">
                    <h5 className="font-medium text-foreground">{rec.title}</h5>
                    <p className="text-sm text-muted-foreground">{rec.description}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={`text-sm font-medium ${getImpactColor(rec.impact)}`}>
                      {rec.impact} impact
                    </span>
                    <span className={`text-sm font-medium ${getEffortColor(rec.effort)}`}>
                      {rec.effort} effort
                    </span>
                    <button className="btn btn-outline btn-sm">
                      <Play className="w-4 h-4 mr-2" />
                      Apply
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="p-6 bg-background min-h-screen text-foreground">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Agent Optimization Engine</h1>
            <p className="text-muted-foreground">
              AI-powered performance optimization for voice AI agents
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <button className="btn btn-outline">
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </button>
            <button className="btn btn-primary">
              <Zap className="w-4 h-4 mr-2" />
              Run Optimization
            </button>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="mb-6">
        <div className="flex space-x-1 bg-secondary p-1 rounded-lg w-fit">
          {[
            { id: 'overview', label: 'Overview', icon: BarChart3 },
            { id: 'agents', label: 'Agents', icon: Users },
            { id: 'rules', label: 'Rules', icon: Settings },
            { id: 'results', label: 'Results', icon: Activity },
            { id: 'config', label: 'Config', icon: Cog }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-primary text-primary-foreground shadow-lg'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      {activeTab === 'overview' && renderOverviewTab()}
      {activeTab === 'agents' && renderAgentsTab()}
      {activeTab === 'rules' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Optimization Rules</h2>
          <p className="text-muted-foreground">Rule management interface will be displayed here.</p>
        </div>
      )}
      {activeTab === 'results' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Optimization Results</h2>
          <p className="text-muted-foreground">Results and analytics will be displayed here.</p>
        </div>
      )}
      {activeTab === 'config' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Configuration</h2>
          <p className="text-muted-foreground">Optimization settings will be displayed here.</p>
        </div>
      )}
    </div>
  );
};

export default AgentOptimizationEngine;
