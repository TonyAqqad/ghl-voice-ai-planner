import React, { useState } from 'react';
import { Copy, Check, ExternalLink, Database, User, Building, Calendar, DollarSign, Phone, Mail, MapPin, Clock, Star, AlertCircle } from 'lucide-react';
import { toast } from 'react-hot-toast';

interface MergeTag {
  category: string;
  key: string;
  label: string;
  description: string;
  example: string;
  icon: React.ComponentType<any>;
}

const GHLIntegrationHelper: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('contact');
  const [searchTerm, setSearchTerm] = useState('');
  const [copiedTag, setCopiedTag] = useState<string | null>(null);

  const mergeTags: MergeTag[] = [
    // Contact Tags
    { category: 'contact', key: '{{contact.firstName}}', label: 'First Name', description: 'Contact\'s first name', example: 'John', icon: User },
    { category: 'contact', key: '{{contact.lastName}}', label: 'Last Name', description: 'Contact\'s last name', example: 'Doe', icon: User },
    { category: 'contact', key: '{{contact.email}}', label: 'Email', description: 'Contact\'s email address', example: 'john@example.com', icon: Mail },
    { category: 'contact', key: '{{contact.phone}}', label: 'Phone', description: 'Contact\'s phone number', example: '+1234567890', icon: Phone },
    { category: 'contact', key: '{{contact.companyName}}', label: 'Company', description: 'Contact\'s company name', example: 'Acme Corp', icon: Building },
    { category: 'contact', key: '{{contact.address}}', label: 'Address', description: 'Contact\'s full address', example: '123 Main St, City, State', icon: MapPin },
    { category: 'contact', key: '{{contact.source}}', label: 'Source', description: 'How the contact was acquired', example: 'Website Form', icon: ExternalLink },
    { category: 'contact', key: '{{contact.tags}}', label: 'Tags', description: 'Contact\'s tags', example: 'Lead, Hot, VIP', icon: Star },
    
    // Opportunity Tags
    { category: 'opportunity', key: '{{opportunity.title}}', label: 'Opportunity Title', description: 'Title of the opportunity', example: 'Website Redesign Project', icon: Building },
    { category: 'opportunity', key: '{{opportunity.value}}', label: 'Opportunity Value', description: 'Monetary value of the opportunity', example: '$5,000', icon: DollarSign },
    { category: 'opportunity', key: '{{opportunity.stage}}', label: 'Stage', description: 'Current stage of the opportunity', example: 'Qualified', icon: Star },
    { category: 'opportunity', key: '{{opportunity.probability}}', label: 'Probability', description: 'Probability of closing', example: '75%', icon: Star },
    { category: 'opportunity', key: '{{opportunity.closeDate}}', label: 'Close Date', description: 'Expected close date', example: '2024-03-15', icon: Calendar },
    { category: 'opportunity', key: '{{opportunity.notes}}', label: 'Notes', description: 'Opportunity notes', example: 'Client interested in premium package', icon: Database },
    
    // Custom Values
    { category: 'custom', key: '{{custom.budget}}', label: 'Budget', description: 'Client\'s budget range', example: '$10,000 - $15,000', icon: DollarSign },
    { category: 'custom', key: '{{custom.timeline}}', label: 'Timeline', description: 'Project timeline', example: '3 months', icon: Clock },
    { category: 'custom', key: '{{custom.urgency}}', label: 'Urgency', description: 'How urgent the project is', example: 'High', icon: AlertCircle },
    { category: 'custom', key: '{{custom.preferredContact}}', label: 'Preferred Contact', description: 'Preferred contact method', example: 'Phone', icon: Phone },
    { category: 'custom', key: '{{custom.projectType}}', label: 'Project Type', description: 'Type of project', example: 'E-commerce Website', icon: Building },
    
    // System Tags
    { category: 'system', key: '{{system.currentDate}}', label: 'Current Date', description: 'Current date', example: '2024-01-15', icon: Calendar },
    { category: 'system', key: '{{system.currentTime}}', label: 'Current Time', description: 'Current time', example: '2:30 PM', icon: Clock },
    { category: 'system', key: '{{system.businessName}}', label: 'Business Name', description: 'Your business name', example: 'Your Company', icon: Building },
    { category: 'system', key: '{{system.businessPhone}}', label: 'Business Phone', description: 'Your business phone', example: '+1234567890', icon: Phone },
    { category: 'system', key: '{{system.businessEmail}}', label: 'Business Email', description: 'Your business email', example: 'info@yourcompany.com', icon: Mail },
    { category: 'system', key: '{{system.businessAddress}}', label: 'Business Address', description: 'Your business address', example: '123 Business St', icon: MapPin },
  ];

  const categories = [
    { id: 'contact', label: 'Contact', icon: User, count: mergeTags.filter(t => t.category === 'contact').length },
    { id: 'opportunity', label: 'Opportunity', icon: Building, count: mergeTags.filter(t => t.category === 'opportunity').length },
    { id: 'custom', label: 'Custom Values', icon: Database, count: mergeTags.filter(t => t.category === 'custom').length },
    { id: 'system', label: 'System', icon: Settings, count: mergeTags.filter(t => t.category === 'system').length },
  ];

  const filteredTags = mergeTags.filter(tag => 
    tag.category === selectedCategory && 
    (tag.label.toLowerCase().includes(searchTerm.toLowerCase()) ||
     tag.key.toLowerCase().includes(searchTerm.toLowerCase()) ||
     tag.description.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleCopyTag = (tag: string) => {
    navigator.clipboard.writeText(tag);
    setCopiedTag(tag);
    toast.success('Merge tag copied to clipboard!');
    setTimeout(() => setCopiedTag(null), 2000);
  };

  const getCategoryIcon = (category: string) => {
    const cat = categories.find(c => c.id === category);
    return cat?.icon || Database;
  };
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">GHL Integration Helper</h1>
          <p className="text-muted-foreground mt-2">
            Access GoHighLevel merge tags, integration patterns, and implementation guides
          </p>
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Category Sidebar */}
        <div className="lg:col-span-1">
          <div className="card">
            <div className="card-header">
              <h3 className="text-lg font-semibold text-foreground">Categories</h3>
            </div>
            <div className="card-content">
              <div className="space-y-2">
                {categories.map((category) => {
                  const Icon = category.icon;
                  return (
                    <button
                      key={category.id}
                      type="button"
                      onClick={() => setSelectedCategory(category.id)}
                      className={`w-full flex items-center justify-between p-3 rounded-lg transition-colors ${
                        selectedCategory === category.id
                          ? 'bg-primary text-primary-foreground'
                          : 'hover:bg-accent'
                      }`}
                    >
                      <div className="flex items-center space-x-3">
                        <Icon className="w-5 h-5" />
                        <span className="font-medium">{category.label}</span>
                      </div>
                      <span className="text-sm opacity-75">{category.count}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
          {/* Quick Actions */}
          <div className="card mt-6">
            <div className="card-header">
              <h3 className="text-lg font-semibold text-foreground">Quick Actions</h3>
            </div>
            <div className="card-content">
              <div className="space-y-3">
                <a
                  href="https://highlevel.stoplight.io/docs/integrations-api/"
                  className="w-full btn btn-outline flex items-center space-x-2"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="GHL API Docs"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>GHL API Docs</span>
                </a>
                <button
                  type="button"
                  className="w-full btn btn-outline flex items-center space-x-2"
                  onClick={() => {
                    // Optionally, provide a handler to guide or open Custom Fields settings
                    toast.info('Custom Fields feature coming soon!');
                  }}
                  aria-label="Custom Fields"
                >
                  <Database className="w-4 h-4" />
                  <span>Custom Fields</span>
                </button>
                <button
                  type="button"
                  className="w-full btn btn-outline flex items-center space-x-2"
                  onClick={() => {
                    // Ensure to copy only currently shown tags
                    const tagsToCopy = filteredTags.length > 0
                      ? filteredTags.map(tag => tag.key)
                      : mergeTags.filter(tag => tag.category === selectedCategory).map(tag => tag.key);
                    navigator.clipboard.writeText(tagsToCopy.join('\n'));
                    setCopiedTag('ALL_TAGS');
                    toast.success(
                      tagsToCopy.length > 0
                        ? 'All merge tags copied to clipboard!'
                        : 'No tags to copy for this category.'
                    );
                    setTimeout(() => setCopiedTag(null), 2000);
                  }}
                  aria-label="Copy All Tags"
                  disabled={
                    mergeTags.filter(tag => tag.category === selectedCategory).length === 0
                  }
                >
                  {copiedTag === 'ALL_TAGS' ? (
                    <Check className="w-4 h-4 text-green-500" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                  <span>Copy All Tags</span>
                </button>
              </div>
            </div>
          </div>
        </div>
        {/* Main Content */}
        <div className="lg:col-span-3">
          <div className="card">
            <div className="card-header">
              <div className="flex items-center justify-between flex-wrap gap-y-2">
                <div className="flex items-center space-x-3">
                  {React.createElement(getCategoryIcon(selectedCategory), { className: "w-6 h-6 text-primary" })}
                  <h3 className="text-lg font-semibold text-foreground">
                    {categories.find(c => c.id === selectedCategory)?.label} Merge Tags
                  </h3>
                </div>
                <div className="flex items-center space-x-3">
                  <input
                    type="text"
                    aria-label="Search tags"
                    placeholder="Search tags..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="px-3 py-2 border border-input rounded-md text-sm"
                  />
                </div>
              </div>
            </div>
            <div className="card-content">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredTags.map((tag) => {
                  const Icon = tag.icon;
                  return (
                    <div key={tag.key} className="border border-border rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                            <Icon className="w-4 h-4 text-primary" />
                          </div>
                          <div>
                            <h4 className="font-semibold text-foreground">{tag.label}</h4>
                            <p className="text-sm text-muted-foreground">{tag.description}</p>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleCopyTag(tag.key)}
                          className="p-2 rounded-md hover:bg-accent transition-colors"
                          title="Copy merge tag"
                          aria-label={`Copy ${tag.label}`}
                        >
                          {copiedTag === tag.key ? (
                            <Check className="w-4 h-4 text-green-500" />
                          ) : (
                            <Copy className="w-4 h-4 text-muted-foreground" />
                          )}
                        </button>
                      </div>
                      <div className="space-y-2">
                        <div>
                          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide" htmlFor={`mtag-${tag.key}`}>
                            Merge Tag
                          </label>
                          <div
                            id={`mtag-${tag.key}`}
                            className="font-mono text-sm bg-muted px-2 py-1 rounded border overflow-x-auto"
                            style={{ wordBreak: 'break-all' }}
                          >
                            {tag.key}
                          </div>
                        </div>
                        <div>
                          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                            Example Value
                          </label>
                          <div className="text-sm text-foreground">
                            {tag.example}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
              {filteredTags.length === 0 && (
                <div className="text-center py-12">
                  <Database className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-foreground mb-2">No tags found</h3>
                  <p className="text-muted-foreground">
                    Try adjusting your search terms or select a different category
                  </p>
                </div>
              )}
            </div>
          </div>
          {/* Integration Patterns */}
          <div className="card mt-6">
            <div className="card-header">
              <h3 className="text-lg font-semibold text-foreground">Common Integration Patterns</h3>
            </div>
            <div className="card-content">
              <div className="space-y-4">
                <div className="border border-border rounded-lg p-4">
                  <h4 className="font-semibold text-foreground mb-2">Voice Agent Greeting</h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    Personalized greeting using contact information
                  </p>
                  <div className="bg-muted p-3 rounded font-mono text-sm overflow-x-auto">
                    {"Hello {{contact.firstName}}, this is {{system.businessName}}. I'm calling about your interest in {{opportunity.title}}. How are you today?"}
                  </div>
                </div>
                <div className="border border-border rounded-lg p-4">
                  <h4 className="font-semibold text-foreground mb-2">Appointment Confirmation</h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    Confirm appointment details with merge tags
                  </p>
                  <div className="bg-muted p-3 rounded font-mono text-sm overflow-x-auto">
                    {"Perfect! I have you scheduled for {{custom.appointmentDate}} at {{custom.appointmentTime}} for {{opportunity.title}}. I'll send you a confirmation to {{contact.email}}."}
                  </div>
                </div>
                <div className="border border-border rounded-lg p-4">
                  <h4 className="font-semibold text-foreground mb-2">Follow-up Message</h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    Follow up with personalized content
                  </p>
                  <div className="bg-muted p-3 rounded font-mono text-sm overflow-x-auto">
                    {"Hi {{contact.firstName}}, I wanted to follow up on our conversation about {{opportunity.title}}. The {{custom.projectType}} project is worth {{opportunity.value}} and has a {{opportunity.probability}} chance of closing by {{opportunity.closeDate}}."}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GHLIntegrationHelper;
