import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  MessageSquare, 
  Users, 
  Clock, 
  Target, 
  Brain,
  Zap,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Filter,
  Search,
  Download,
  RefreshCw,
  Eye,
  Activity,
  PieChart,
  LineChart,
  Calendar,
  Globe,
  Phone,
  Mic,
  Headphones,
  Volume2,
  VolumeX,
  Pause,
  Play,
  SkipForward,
  SkipBack,
  RotateCcw,
  Settings,
  MoreHorizontal,
  ChevronDown,
  ChevronRight,
  Info,
  HelpCircle,
  Star,
  ThumbsUp,
  ThumbsDown,
  Heart,
  Smile,
  Frown,
  Meh
} from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';

interface ConversationInsight {
  id: string;
  type: 'sentiment' | 'intent' | 'performance' | 'compliance' | 'optimization';
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  confidence: number;
  recommendation: string;
  agentId: string;
  agentName: string;
  timestamp: string;
  metrics: {
    before: number;
    after: number;
    improvement: number;
  };
  tags: string[];
}

interface ConversationMetric {
  id: string;
  name: string;
  value: number;
  change: number;
  trend: 'up' | 'down' | 'stable';
  target: number;
  unit: string;
  category: 'conversion' | 'engagement' | 'quality' | 'efficiency';
}

interface ConversationData {
  id: string;
  agentId: string;
  agentName: string;
  customerId: string;
  customerName: string;
  duration: number;
  startTime: string;
  endTime: string;
  status: 'completed' | 'transferred' | 'abandoned' | 'failed';
  sentiment: 'positive' | 'neutral' | 'negative';
  intent: string;
  confidence: number;
  transcript: string;
  keywords: string[];
  emotions: Array<{
    emotion: string;
    intensity: number;
    timestamp: number;
  }>;
  actions: Array<{
    action: string;
    timestamp: number;
    success: boolean;
  }>;
  outcomes: Array<{
    outcome: string;
    value: number;
    timestamp: number;
  }>;
  quality: {
    clarity: number;
    politeness: number;
    helpfulness: number;
    efficiency: number;
    overall: number;
  };
  compliance: {
    dncChecked: boolean;
    consentRecorded: boolean;
    dataEncrypted: boolean;
    retentionCompliant: boolean;
  };
}

interface ConversationTrend {
  period: string;
  conversations: number;
  avgDuration: number;
  conversionRate: number;
  satisfactionScore: number;
  sentimentScore: number;
}

const ConversationAnalytics: React.FC = () => {
  const { darkMode } = useStore();
  const [conversations, setConversations] = useState<ConversationData[]>([]);
  const [insights, setInsights] = useState<ConversationInsight[]>([]);
  const [metrics, setMetrics] = useState<ConversationMetric[]>([]);
  const [trends, setTrends] = useState<ConversationTrend[]>([]);
  const [selectedAgent, setSelectedAgent] = useState<string>('all');
  const [selectedTimeframe, setSelectedTimeframe] = useState<string>('7d');
  const [selectedMetric, setSelectedMetric] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedConversation, setSelectedConversation] = useState<ConversationData | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'insights' | 'conversations' | 'trends'>('overview');

  // Sample data - in real app this would come from analytics API
  useEffect(() => {
    const sampleConversations: ConversationData[] = [
      {
        id: 'conv_1',
        agentId: 'agent_1',
        agentName: 'F45 Fitness Agent',
        customerId: 'cust_1',
        customerName: 'Sarah Johnson',
        duration: 245,
        startTime: '2024-01-15T14:30:00Z',
        endTime: '2024-01-15T14:34:05Z',
        status: 'completed',
        sentiment: 'positive',
        intent: 'trial_booking',
        confidence: 0.94,
        transcript: 'Agent: Hi Sarah! This is Alex from F45 Training. I\'m calling because you expressed interest in trying our classes. Do you have a few minutes to chat about your fitness goals?\n\nCustomer: Yes, I\'m really interested! I\'ve been wanting to try group fitness classes.\n\nAgent: That\'s fantastic! F45 is perfect for that. What are your main fitness goals?\n\nCustomer: I want to lose weight and get stronger. I\'m a bit nervous about group classes though.\n\nAgent: I completely understand that feeling. The great thing about F45 is that everyone is supportive and the trainers are there to help you every step of the way. What time of day works best for you?\n\nCustomer: I prefer evening classes after work.\n\nAgent: Perfect! We have evening classes at 6:30 PM and 7:30 PM. I\'d love to get you in for a FREE trial class this week. What day works best for you?\n\nCustomer: Tuesday at 6:30 PM sounds great!\n\nAgent: Excellent! I\'ve got you booked for Tuesday at 6:30 PM. You\'ll receive a confirmation text with all the details. Just bring a water bottle and towel, and arrive 10 minutes early for orientation.',
        keywords: ['fitness', 'trial', 'class', 'evening', 'goals', 'weight loss', 'strength'],
        emotions: [
          { emotion: 'excitement', intensity: 0.8, timestamp: 30 },
          { emotion: 'nervousness', intensity: 0.6, timestamp: 90 },
          { emotion: 'confidence', intensity: 0.9, timestamp: 180 },
          { emotion: 'satisfaction', intensity: 0.95, timestamp: 240 }
        ],
        actions: [
          { action: 'greeting', timestamp: 5, success: true },
          { action: 'goal_assessment', timestamp: 45, success: true },
          { action: 'objection_handling', timestamp: 120, success: true },
          { action: 'appointment_booking', timestamp: 200, success: true },
          { action: 'confirmation', timestamp: 240, success: true }
        ],
        outcomes: [
          { outcome: 'trial_booked', value: 1, timestamp: 200 },
          { outcome: 'membership_interest', value: 0.8, timestamp: 220 },
          { outcome: 'referral_potential', value: 0.7, timestamp: 240 }
        ],
        quality: {
          clarity: 0.92,
          politeness: 0.96,
          helpfulness: 0.94,
          efficiency: 0.88,
          overall: 0.93
        },
        compliance: {
          dncChecked: true,
          consentRecorded: true,
          dataEncrypted: true,
          retentionCompliant: true
        }
      },
      {
        id: 'conv_2',
        agentId: 'agent_2',
        agentName: 'Legal Consultation Agent',
        customerId: 'cust_2',
        customerName: 'Michael Chen',
        duration: 180,
        startTime: '2024-01-15T15:15:00Z',
        endTime: '2024-01-15T15:18:00Z',
        status: 'transferred',
        sentiment: 'neutral',
        intent: 'personal_injury',
        confidence: 0.87,
        transcript: 'Agent: Hello Michael, this is Jennifer from Legal Solutions. I understand you\'re looking for legal assistance. Can you tell me briefly what type of legal matter you\'re dealing with?\n\nCustomer: I was in a car accident last month and I\'m not sure if I need a lawyer.\n\nAgent: I\'m sorry to hear about your accident. That must be stressful. For personal injury cases, it\'s often beneficial to have legal representation, especially if there are injuries involved. Let me connect you with one of our personal injury specialists who can give you a free consultation.\n\nCustomer: That would be helpful, thank you.\n\nAgent: Perfect! I\'m transferring you to David Martinez, our personal injury attorney. He\'ll be able to assess your case and provide guidance on next steps.',
        keywords: ['car accident', 'personal injury', 'lawyer', 'legal assistance', 'consultation'],
        emotions: [
          { emotion: 'concern', intensity: 0.7, timestamp: 20 },
          { emotion: 'uncertainty', intensity: 0.8, timestamp: 60 },
          { emotion: 'relief', intensity: 0.6, timestamp: 150 }
        ],
        actions: [
          { action: 'greeting', timestamp: 5, success: true },
          { action: 'case_assessment', timestamp: 30, success: true },
          { action: 'specialist_transfer', timestamp: 120, success: true }
        ],
        outcomes: [
          { outcome: 'consultation_scheduled', value: 1, timestamp: 150 },
          { outcome: 'case_potential', value: 0.8, timestamp: 170 }
        ],
        quality: {
          clarity: 0.89,
          politeness: 0.95,
          helpfulness: 0.91,
          efficiency: 0.85,
          overall: 0.90
        },
        compliance: {
          dncChecked: true,
          consentRecorded: true,
          dataEncrypted: true,
          retentionCompliant: true
        }
      }
    ];

    const sampleInsights: ConversationInsight[] = [
      {
        id: 'insight_1',
        type: 'sentiment',
        title: 'Positive Sentiment Trend in F45 Agent',
        description: 'F45 Fitness Agent shows 15% improvement in positive sentiment over the last week, particularly during trial booking conversations.',
        impact: 'high',
        confidence: 0.92,
        recommendation: 'Continue using the current script approach for trial bookings. Consider applying similar techniques to other agent types.',
        agentId: 'agent_1',
        agentName: 'F45 Fitness Agent',
        timestamp: '2024-01-15T16:00:00Z',
        metrics: {
          before: 0.72,
          after: 0.87,
          improvement: 0.15
        },
        tags: ['sentiment', 'trial_booking', 'script_optimization']
      },
      {
        id: 'insight_2',
        type: 'performance',
        title: 'Call Duration Optimization Opportunity',
        description: 'Legal Consultation Agent calls are 20% longer than optimal. Consider streamlining the case assessment process.',
        impact: 'medium',
        confidence: 0.85,
        recommendation: 'Implement a more structured case assessment flow to reduce call duration while maintaining quality.',
        agentId: 'agent_2',
        agentName: 'Legal Consultation Agent',
        timestamp: '2024-01-15T15:45:00Z',
        metrics: {
          before: 240,
          after: 192,
          improvement: -48
        },
        tags: ['performance', 'duration', 'efficiency']
      }
    ];

    const sampleMetrics: ConversationMetric[] = [
      {
        id: 'metric_1',
        name: 'Conversion Rate',
        value: 0.23,
        change: 0.05,
        trend: 'up',
        target: 0.25,
        unit: '%',
        category: 'conversion'
      },
      {
        id: 'metric_2',
        name: 'Average Call Duration',
        value: 195,
        change: -12,
        trend: 'down',
        target: 180,
        unit: 'seconds',
        category: 'efficiency'
      },
      {
        id: 'metric_3',
        name: 'Customer Satisfaction',
        value: 0.91,
        change: 0.03,
        trend: 'up',
        target: 0.90,
        unit: 'score',
        category: 'quality'
      },
      {
        id: 'metric_4',
        name: 'First Call Resolution',
        value: 0.78,
        change: 0.02,
        trend: 'up',
        target: 0.80,
        unit: '%',
        category: 'efficiency'
      }
    ];

    const sampleTrends: ConversationTrend[] = [
      { period: '2024-01-08', conversations: 45, avgDuration: 210, conversionRate: 0.18, satisfactionScore: 0.88, sentimentScore: 0.72 },
      { period: '2024-01-09', conversations: 52, avgDuration: 205, conversionRate: 0.21, satisfactionScore: 0.89, sentimentScore: 0.75 },
      { period: '2024-01-10', conversations: 48, avgDuration: 200, conversionRate: 0.19, satisfactionScore: 0.87, sentimentScore: 0.73 },
      { period: '2024-01-11', conversations: 61, avgDuration: 195, conversionRate: 0.24, satisfactionScore: 0.91, sentimentScore: 0.78 },
      { period: '2024-01-12', conversations: 55, avgDuration: 190, conversionRate: 0.22, satisfactionScore: 0.90, sentimentScore: 0.76 },
      { period: '2024-01-13', conversations: 38, avgDuration: 185, conversionRate: 0.26, satisfactionScore: 0.92, sentimentScore: 0.80 },
      { period: '2024-01-14', conversations: 42, avgDuration: 192, conversionRate: 0.23, satisfactionScore: 0.91, sentimentScore: 0.79 }
    ];

    setConversations(sampleConversations);
    setInsights(sampleInsights);
    setMetrics(sampleMetrics);
    setTrends(sampleTrends);
  }, []);

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return 'text-green-400 bg-green-100';
      case 'neutral': return 'text-yellow-400 bg-yellow-100';
      case 'negative': return 'text-red-400 bg-red-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'text-red-400 bg-red-100';
      case 'medium': return 'text-yellow-400 bg-yellow-100';
      case 'low': return 'text-green-400 bg-green-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-4 h-4 text-green-400" />;
      case 'down': return <TrendingDown className="w-4 h-4 text-red-400" />;
      case 'stable': return <Activity className="w-4 h-4 text-blue-400" />;
      default: return <Activity className="w-4 h-4 text-gray-400" />;
    }
  };

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}m ${remainingSeconds}s`;
  };

  const renderOverviewTab = () => (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric) => (
          <div key={metric.id} className="card p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground">{metric.name}</p>
                <p className="text-2xl font-bold text-foreground">
                  {metric.value}{metric.unit}
                </p>
              </div>
              <div className="flex items-center space-x-2">
                {getTrendIcon(metric.trend)}
                <span className={`text-sm font-medium ${
                  metric.trend === 'up' ? 'text-green-400' : 
                  metric.trend === 'down' ? 'text-red-400' : 'text-blue-400'
                }`}>
                  {metric.change > 0 ? '+' : ''}{metric.change}{metric.unit}
                </span>
              </div>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div 
                className="bg-primary h-2 rounded-full" 
                style={{ width: `${(metric.value / metric.target) * 100}%` }}
              ></div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Target: {metric.target}{metric.unit}
            </p>
          </div>
        ))}
      </div>

      {/* Recent Insights */}
      <div className="card p-6">
        <h2 className="text-xl font-semibold text-foreground mb-6">Recent AI Insights</h2>
        <div className="space-y-4">
          {insights.map((insight) => (
            <div key={insight.id} className="flex items-start space-x-4 p-4 bg-secondary rounded-lg">
              <div className={`w-3 h-3 rounded-full mt-2 ${
                insight.type === 'sentiment' ? 'bg-purple-400' :
                insight.type === 'intent' ? 'bg-blue-400' :
                insight.type === 'performance' ? 'bg-green-400' :
                insight.type === 'compliance' ? 'bg-red-400' :
                'bg-orange-400'
              }`}></div>
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-2">
                  <h3 className="font-semibold text-foreground">{insight.title}</h3>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${getImpactColor(insight.impact)}`}>
                    {insight.impact} impact
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {Math.round(insight.confidence * 100)}% confidence
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mb-2">{insight.description}</p>
                <p className="text-sm font-medium text-primary">{insight.recommendation}</p>
                <div className="flex items-center space-x-4 mt-2 text-xs text-muted-foreground">
                  <span>{insight.agentName}</span>
                  <span>•</span>
                  <span>{new Date(insight.timestamp).toLocaleString()}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderConversationsTab = () => (
    <div className="space-y-6">
      {/* Filters */}
      <div className="card p-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <input
                type="text"
                placeholder="Search conversations..."
                className="w-full pl-10 input"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          <div className="flex space-x-2">
            <select
              className="input"
              value={selectedAgent}
              onChange={(e) => setSelectedAgent(e.target.value)}
            >
              <option value="all">All Agents</option>
              <option value="agent_1">F45 Fitness Agent</option>
              <option value="agent_2">Legal Consultation Agent</option>
            </select>
            <select
              className="input"
              value={selectedTimeframe}
              onChange={(e) => setSelectedTimeframe(e.target.value)}
            >
              <option value="1d">Last 24 hours</option>
              <option value="7d">Last 7 days</option>
              <option value="30d">Last 30 days</option>
            </select>
          </div>
        </div>
      </div>

      {/* Conversations List */}
      <div className="space-y-4">
        {conversations.map((conversation) => (
          <div key={conversation.id} className="card p-6 hover:shadow-lg transition-all duration-200">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="font-semibold text-foreground">{conversation.customerName}</h3>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${getSentimentColor(conversation.sentiment)}`}>
                    {conversation.sentiment}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {conversation.agentName}
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mb-3">
                  Intent: {conversation.intent} • Confidence: {Math.round(conversation.confidence * 100)}%
                </p>
                <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{formatDuration(conversation.duration)}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Target className="w-4 h-4" />
                    <span>Quality: {Math.round(conversation.quality.overall * 100)}%</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <CheckCircle className="w-4 h-4" />
                    <span>{conversation.status}</span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setSelectedConversation(conversation)}
                className="btn btn-outline btn-sm"
              >
                <Eye className="w-4 h-4 mr-2" />
                View Details
              </button>
            </div>
            
            {/* Transcript Preview */}
            <div className="bg-secondary p-4 rounded-lg">
              <p className="text-sm text-muted-foreground italic">
                "{conversation.transcript.substring(0, 200)}..."
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="p-6 bg-background min-h-screen text-foreground">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Conversation Analytics</h1>
            <p className="text-muted-foreground">
              AI-powered insights and analytics for voice AI agent conversations
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <button className="btn btn-outline">
              <Download className="w-4 h-4 mr-2" />
              Export Data
            </button>
            <button className="btn btn-outline">
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </button>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="mb-6">
        <div className="flex space-x-1 bg-secondary p-1 rounded-lg w-fit">
          {[
            { id: 'overview', label: 'Overview', icon: BarChart3 },
            { id: 'insights', label: 'AI Insights', icon: Brain },
            { id: 'conversations', label: 'Conversations', icon: MessageSquare },
            { id: 'trends', label: 'Trends', icon: TrendingUp }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-primary text-primary-foreground shadow-lg'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      {activeTab === 'overview' && renderOverviewTab()}
      {activeTab === 'insights' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">AI Insights</h2>
          <p className="text-muted-foreground">Advanced AI insights and recommendations will be displayed here.</p>
        </div>
      )}
      {activeTab === 'conversations' && renderConversationsTab()}
      {activeTab === 'trends' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Trends Analysis</h2>
          <p className="text-muted-foreground">Trend analysis and forecasting will be displayed here.</p>
        </div>
      )}
    </div>
  );
};

export default ConversationAnalytics;
