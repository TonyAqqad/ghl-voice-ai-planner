import React, { useState, useEffect } from 'react';
import { Brain, Heart, Smile, Frown, AlertTriangle, TrendingUp, BarChart3, RefreshCw, Eye, MessageSquare, Users, Clock, Zap } from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';
import { v4 as uuidv4 } from 'uuid';

interface SentimentData {
  id: string;
  conversationId: string;
  timestamp: string;
  text: string;
  sentiment: 'positive' | 'negative' | 'neutral' | 'mixed';
  confidence: number;
  emotions: {
    joy: number;
    anger: number;
    fear: number;
    sadness: number;
    surprise: number;
    disgust: number;
  };
  intent: string;
  urgency: 'low' | 'medium' | 'high' | 'critical';
  customerSatisfaction: number;
  agentPerformance: number;
}

interface ConversationInsights {
  id: string;
  conversationId: string;
  duration: number;
  totalSentiments: number;
  averageSentiment: number;
  sentimentTrend: 'improving' | 'declining' | 'stable';
  dominantEmotion: string;
  keyTopics: string[];
  customerSatisfactionScore: number;
  agentEffectivenessScore: number;
  recommendations: string[];
  createdAt: string;
}

interface SentimentMetrics {
  totalConversations: number;
  positiveSentimentRate: number;
  negativeSentimentRate: number;
  averageSatisfaction: number;
  topEmotions: { emotion: string; count: number }[];
  sentimentTrends: { date: string; positive: number; negative: number; neutral: number }[];
}

const ConversationSentimentAnalysis: React.FC = () => {
  const { voiceAgents } = useStore();
  const [sentimentData, setSentimentData] = useState<SentimentData[]>([]);
  const [conversationInsights, setConversationInsights] = useState<ConversationInsights[]>([]);
  const [metrics, setMetrics] = useState<SentimentMetrics>({
    totalConversations: 0,
    positiveSentimentRate: 0,
    negativeSentimentRate: 0,
    averageSatisfaction: 0,
    topEmotions: [],
    sentimentTrends: []
  });
  const [selectedAgentId, setSelectedAgentId] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedTimeRange, setSelectedTimeRange] = useState<'24h' | '7d' | '30d' | '90d'>('7d');

  useEffect(() => {
    // Mock data for sentiment analysis
    const mockSentimentData: SentimentData[] = [
      {
        id: uuidv4(),
        conversationId: 'conv_001',
        timestamp: '2023-10-26T18:30:00Z',
        text: "I'm really excited about this solar installation! The process has been so smooth.",
        sentiment: 'positive',
        confidence: 0.92,
        emotions: { joy: 0.85, anger: 0.02, fear: 0.01, sadness: 0.01, surprise: 0.08, disgust: 0.03 },
        intent: 'appreciation',
        urgency: 'low',
        customerSatisfaction: 9.2,
        agentPerformance: 8.8
      },
      {
        id: uuidv4(),
        conversationId: 'conv_002',
        timestamp: '2023-10-26T18:45:00Z',
        text: "I'm frustrated with the delays. When will my installation actually happen?",
        sentiment: 'negative',
        confidence: 0.88,
        emotions: { joy: 0.05, anger: 0.75, fear: 0.10, sadness: 0.05, surprise: 0.02, disgust: 0.03 },
        intent: 'complaint',
        urgency: 'high',
        customerSatisfaction: 3.1,
        agentPerformance: 7.2
      },
      {
        id: uuidv4(),
        conversationId: 'conv_003',
        timestamp: '2023-10-26T19:00:00Z',
        text: "Can you explain the financing options available?",
        sentiment: 'neutral',
        confidence: 0.76,
        emotions: { joy: 0.15, anger: 0.05, fear: 0.20, sadness: 0.05, surprise: 0.10, disgust: 0.05 },
        intent: 'inquiry',
        urgency: 'medium',
        customerSatisfaction: 7.5,
        agentPerformance: 8.5
      }
    ];

    const mockInsights: ConversationInsights[] = [
      {
        id: uuidv4(),
        conversationId: 'conv_001',
        duration: 420,
        totalSentiments: 15,
        averageSentiment: 0.78,
        sentimentTrend: 'improving',
        dominantEmotion: 'joy',
        keyTopics: ['solar installation', 'process', 'excitement'],
        customerSatisfactionScore: 9.2,
        agentEffectivenessScore: 8.8,
        recommendations: ['Continue current approach', 'Highlight benefits more'],
        createdAt: '2023-10-26T18:30:00Z'
      },
      {
        id: uuidv4(),
        conversationId: 'conv_002',
        duration: 380,
        totalSentiments: 12,
        averageSentiment: 0.25,
        sentimentTrend: 'declining',
        dominantEmotion: 'anger',
        keyTopics: ['delays', 'frustration', 'timeline'],
        customerSatisfactionScore: 3.1,
        agentEffectivenessScore: 7.2,
        recommendations: ['Improve communication', 'Provide more updates', 'Escalate to manager'],
        createdAt: '2023-10-26T18:45:00Z'
      }
    ];

    setSentimentData(mockSentimentData);
    setConversationInsights(mockInsights);

    // Calculate metrics
    const totalConversations = mockInsights.length;
    const positiveCount = mockSentimentData.filter(s => s.sentiment === 'positive').length;
    const negativeCount = mockSentimentData.filter(s => s.sentiment === 'negative').length;
    const avgSatisfaction = mockInsights.reduce((sum, insight) => sum + insight.customerSatisfactionScore, 0) / mockInsights.length;

    setMetrics({
      totalConversations,
      positiveSentimentRate: (positiveCount / mockSentimentData.length) * 100,
      negativeSentimentRate: (negativeCount / mockSentimentData.length) * 100,
      averageSatisfaction: avgSatisfaction,
      topEmotions: [
        { emotion: 'Joy', count: 8 },
        { emotion: 'Anger', count: 5 },
        { emotion: 'Surprise', count: 3 },
        { emotion: 'Fear', count: 2 }
      ],
      sentimentTrends: [
        { date: '2023-10-20', positive: 65, negative: 20, neutral: 15 },
        { date: '2023-10-21', positive: 70, negative: 15, neutral: 15 },
        { date: '2023-10-22', positive: 68, negative: 18, neutral: 14 },
        { date: '2023-10-23', positive: 72, negative: 16, neutral: 12 },
        { date: '2023-10-24', positive: 75, negative: 12, neutral: 13 },
        { date: '2023-10-25', positive: 78, negative: 10, neutral: 12 },
        { date: '2023-10-26', positive: 80, negative: 8, neutral: 12 }
      ]
    });
  }, []);

  const handleAnalyzeConversations = async () => {
    if (!selectedAgentId) {
      toast.error('Please select an agent to analyze.');
      return;
    }

    setIsAnalyzing(true);
    toast.loading('Analyzing conversation sentiment...', { id: 'sentiment-analysis' });

    // Simulate AI analysis
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Generate new analysis data
    const newSentimentData: SentimentData = {
      id: uuidv4(),
      conversationId: `conv_${Date.now()}`,
      timestamp: new Date().toISOString(),
      text: "This is a sample conversation for analysis.",
      sentiment: Math.random() > 0.5 ? 'positive' : 'negative',
      confidence: Math.random() * 0.4 + 0.6,
      emotions: {
        joy: Math.random(),
        anger: Math.random(),
        fear: Math.random(),
        sadness: Math.random(),
        surprise: Math.random(),
        disgust: Math.random()
      },
      intent: ['inquiry', 'complaint', 'appreciation', 'request'][Math.floor(Math.random() * 4)],
      urgency: ['low', 'medium', 'high', 'critical'][Math.floor(Math.random() * 4)] as any,
      customerSatisfaction: Math.random() * 5 + 5,
      agentPerformance: Math.random() * 5 + 5
    };

    setSentimentData(prev => [newSentimentData, ...prev]);
    setIsAnalyzing(false);
    toast.success('Conversation analysis complete!', { id: 'sentiment-analysis' });
  };

  const getSentimentColor = (sentiment: SentimentData['sentiment']) => {
    switch (sentiment) {
      case 'positive': return 'text-green-500';
      case 'negative': return 'text-red-500';
      case 'neutral': return 'text-blue-500';
      case 'mixed': return 'text-yellow-500';
      default: return 'text-muted-foreground';
    }
  };

  const getSentimentIcon = (sentiment: SentimentData['sentiment']) => {
    switch (sentiment) {
      case 'positive': return <Smile className="w-4 h-4 text-green-500" />;
      case 'negative': return <Frown className="w-4 h-4 text-red-500" />;
      case 'neutral': return <MessageSquare className="w-4 h-4 text-blue-500" />;
      case 'mixed': return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      default: return <MessageSquare className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const getUrgencyColor = (urgency: SentimentData['urgency']) => {
    switch (urgency) {
      case 'critical': return 'text-red-600 bg-red-100';
      case 'high': return 'text-orange-600 bg-orange-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-green-600 bg-green-100';
      default: return 'text-muted-foreground bg-gray-100';
    }
  };

  return (
    <div className="p-6 bg-background min-h-screen text-foreground">
      <h1 className="text-3xl font-bold gradient-text mb-6">AI-Powered Conversation Sentiment Analysis & Emotion Detection</h1>
      <p className="text-muted-foreground mb-8">
        Leverage advanced AI to analyze conversation sentiment, detect emotions, and optimize agent performance with real-time insights and recommendations.
      </p>

      {/* Analysis Controls */}
      <div className="card p-6 mb-8">
        <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
          <Brain className="w-6 h-6 mr-2 text-purple-400" /> Real-Time Analysis
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div>
            <label htmlFor="select-agent" className="block text-sm font-medium text-muted-foreground mb-1">
              Select Agent
            </label>
            <select
              id="select-agent"
              className="w-full input"
              value={selectedAgentId}
              onChange={(e) => setSelectedAgentId(e.target.value)}
            >
              <option value="">-- Select an Agent --</option>
              {voiceAgents.map(agent => (
                <option key={agent.id} value={agent.id}>{agent.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="time-range" className="block text-sm font-medium text-muted-foreground mb-1">
              Time Range
            </label>
            <select
              id="time-range"
              className="w-full input"
              value={selectedTimeRange}
              onChange={(e) => setSelectedTimeRange(e.target.value as any)}
            >
              <option value="24h">Last 24 Hours</option>
              <option value="7d">Last 7 Days</option>
              <option value="30d">Last 30 Days</option>
              <option value="90d">Last 90 Days</option>
            </select>
          </div>
          <div className="flex items-end">
            <button
              onClick={handleAnalyzeConversations}
              className="btn btn-primary w-full flex items-center justify-center"
              disabled={isAnalyzing || !selectedAgentId}
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="w-5 h-5 mr-2 animate-spin" /> Analyzing...
                </>
              ) : (
                <>
                  <Zap className="w-5 h-5 mr-2" /> Analyze Conversations
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="card p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-muted-foreground">Total Conversations</h3>
            <MessageSquare className="w-5 h-5 text-blue-400" />
          </div>
          <p className="text-2xl font-bold text-foreground">{metrics.totalConversations}</p>
          <p className="text-xs text-muted-foreground mt-1">Last {selectedTimeRange}</p>
        </div>
        <div className="card p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-muted-foreground">Positive Sentiment</h3>
            <Smile className="w-5 h-5 text-green-400" />
          </div>
          <p className="text-2xl font-bold text-foreground">{metrics.positiveSentimentRate.toFixed(1)}%</p>
          <p className="text-xs text-muted-foreground mt-1">Above industry average</p>
        </div>
        <div className="card p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-muted-foreground">Customer Satisfaction</h3>
            <Heart className="w-5 h-5 text-pink-400" />
          </div>
          <p className="text-2xl font-bold text-foreground">{metrics.averageSatisfaction.toFixed(1)}/10</p>
          <p className="text-xs text-muted-foreground mt-1">Average score</p>
        </div>
        <div className="card p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-muted-foreground">Negative Sentiment</h3>
            <Frown className="w-5 h-5 text-red-400" />
          </div>
          <p className="text-2xl font-bold text-foreground">{metrics.negativeSentimentRate.toFixed(1)}%</p>
          <p className="text-xs text-muted-foreground mt-1">Below threshold</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sentiment Data */}
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
            <BarChart3 className="w-6 h-6 mr-2 text-blue-400" /> Recent Sentiment Analysis
          </h2>
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {sentimentData.slice(0, 10).map((data) => (
              <div key={data.id} className="bg-secondary p-4 rounded-lg border border-border">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    {getSentimentIcon(data.sentiment)}
                    <span className={`font-medium ${getSentimentColor(data.sentiment)}`}>
                      {data.sentiment.charAt(0).toUpperCase() + data.sentiment.slice(1)}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {data.confidence.toFixed(2)} confidence
                    </span>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getUrgencyColor(data.urgency)}`}>
                    {data.urgency}
                  </span>
                </div>
                <p className="text-sm text-foreground mb-2">{data.text}</p>
                <div className="flex justify-between items-center text-xs text-muted-foreground">
                  <span>Intent: {data.intent}</span>
                  <span>Satisfaction: {data.customerSatisfaction.toFixed(1)}/10</span>
                  <span>{new Date(data.timestamp).toLocaleTimeString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Conversation Insights */}
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
            <Eye className="w-6 h-6 mr-2 text-green-400" /> Conversation Insights
          </h2>
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {conversationInsights.map((insight) => (
              <div key={insight.id} className="bg-secondary p-4 rounded-lg border border-border">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-medium text-foreground">Conversation {insight.conversationId}</h3>
                  <span className={`text-sm font-medium ${
                    insight.sentimentTrend === 'improving' ? 'text-green-500' : 
                    insight.sentimentTrend === 'declining' ? 'text-red-500' : 'text-blue-500'
                  }`}>
                    {insight.sentimentTrend}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground mb-3">
                  <div>Duration: {Math.floor(insight.duration / 60)}m {insight.duration % 60}s</div>
                  <div>Sentiments: {insight.totalSentiments}</div>
                  <div>Avg Sentiment: {(insight.averageSentiment * 100).toFixed(1)}%</div>
                  <div>Dominant: {insight.dominantEmotion}</div>
                </div>
                <div className="mb-3">
                  <p className="text-xs text-muted-foreground mb-1">Key Topics:</p>
                  <div className="flex flex-wrap gap-1">
                    {insight.keyTopics.map((topic, index) => (
                      <span key={index} className="px-2 py-1 bg-background rounded text-xs">
                        {topic}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="mb-3">
                  <p className="text-xs text-muted-foreground mb-1">Recommendations:</p>
                  <ul className="text-xs text-foreground list-disc list-inside">
                    {insight.recommendations.map((rec, index) => (
                      <li key={index}>{rec}</li>
                    ))}
                  </ul>
                </div>
                <div className="flex justify-between items-center text-xs text-muted-foreground">
                  <span>Satisfaction: {insight.customerSatisfactionScore.toFixed(1)}/10</span>
                  <span>Agent Score: {insight.agentEffectivenessScore.toFixed(1)}/10</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConversationSentimentAnalysis;
