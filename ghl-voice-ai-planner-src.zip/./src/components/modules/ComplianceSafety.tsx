import React, { useState, useEffect } from 'react';
import { 
  Shield, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  Clock, 
  FileText, 
  Download, 
  Settings,
  Eye,
  Lock,
  Users,
  AlertCircle
} from 'lucide-react';

interface ComplianceCheck {
  id: string;
  name: string;
  description: string;
  status: 'compliant' | 'warning' | 'violation' | 'pending';
  risk: 'low' | 'medium' | 'high';
}

interface ComplianceStats {
  total: number;
  compliant: number;
  warning: number;
  violation: number;
}

const ComplianceSafety: React.FC = () => {
  const [activeTab, setActiveTab] = useState('tcpa');
  const [isAuditing, setIsAuditing] = useState(false);
  const [complianceScore, setComplianceScore] = useState(0);
  const [stats, setStats] = useState<ComplianceStats>({ total: 0, compliant: 0, warning: 0, violation: 0 });
  const [logs, setLogs] = useState<string[]>(['Compliance system initialized. Ready for audit.']);
  
  const [tcpaChecks, setTcpaChecks] = useState<ComplianceCheck[]>([
    { id: '1', name: 'Express Written Consent', description: 'Obtain explicit consent before making calls', status: 'compliant', risk: 'high' },
    { id: '2', name: 'Do Not Call Registry', description: 'Check against DNC registry before calling', status: 'compliant', risk: 'high' },
    { id: '3', name: 'Call Time Restrictions', description: 'Respect calling hours (8 AM - 9 PM local time)', status: 'compliant', risk: 'medium' },
    { id: '4', name: 'Caller ID Requirements', description: 'Display accurate caller ID information', status: 'warning', risk: 'medium' },
    { id: '5', name: 'Opt-out Mechanism', description: 'Provide clear opt-out instructions', status: 'compliant', risk: 'high' },
    { id: '6', name: 'Call Recording Disclosure', description: 'Disclose recording before starting', status: 'compliant', risk: 'high' }
  ]);

  const [gdprChecks, setGdprChecks] = useState<ComplianceCheck[]>([
    { id: '1', name: 'Lawful Basis for Processing', description: 'Identify and document legal basis for data processing', status: 'compliant', risk: 'high' },
    { id: '2', name: 'Data Minimization', description: 'Collect only necessary personal data', status: 'compliant', risk: 'medium' },
    { id: '3', name: 'Consent Management', description: 'Obtain and manage user consent properly', status: 'warning', risk: 'high' },
    { id: '4', name: 'Data Subject Rights', description: 'Enable data subject access, rectification, and deletion', status: 'compliant', risk: 'high' },
    { id: '5', name: 'Data Breach Notification', description: 'Notify authorities within 72 hours of breach', status: 'compliant', risk: 'high' },
    { id: '6', name: 'Privacy by Design', description: 'Implement privacy considerations in system design', status: 'compliant', risk: 'medium' }
  ]);

  const safetyChecks = [
    { name: 'Data Encryption', description: 'All data encrypted in transit and at rest', status: 'compliant' as const },
    { name: 'Access Controls', description: 'Review user access permissions', status: 'warning' as const },
    { name: 'Audit Logging', description: 'All actions logged and monitored', status: 'compliant' as const },
    { name: 'Content Filtering', description: 'Inappropriate content detection active', status: 'compliant' as const },
    { name: 'Call Recording Consent', description: 'Consent obtained before recording', status: 'compliant' as const },
    { name: 'Emergency Escalation', description: 'Human escalation not configured', status: 'violation' as const }
  ];

  const policies = [
    { name: 'Privacy Policy', lastUpdated: '2024-01-15', status: 'compliant' as const },
    { name: 'Terms of Service', lastUpdated: '2023-12-01', status: 'warning' as const },
    { name: 'Data Processing Agreement', lastUpdated: '2024-01-10', status: 'compliant' as const }
  ];

  const riskLevels = [
    { name: 'Data Breach Risk', description: 'Potential exposure of customer data', level: 'low' as const },
    { name: 'Regulatory Violation Risk', description: 'Non-compliance with TCPA/GDPR', level: 'medium' as const },
    { name: 'Voice AI Misuse Risk', description: 'Inappropriate AI responses or actions', level: 'low' as const }
  ];

  useEffect(() => {
    updateStats();
  }, [tcpaChecks, gdprChecks]);

  const updateStats = () => {
    const allChecks = [...tcpaChecks, ...gdprChecks];
    const newStats = {
      total: allChecks.length,
      compliant: allChecks.filter(c => c.status === 'compliant').length,
      warning: allChecks.filter(c => c.status === 'warning').length,
      violation: allChecks.filter(c => c.status === 'violation').length
    };
    setStats(newStats);
    
    const score = Math.round((newStats.compliant / newStats.total) * 100);
    setComplianceScore(score);
  };

  const toggleCheck = (type: 'tcpa' | 'gdpr', checkId: string) => {
    if (type === 'tcpa') {
      setTcpaChecks(prev => prev.map(check => 
        check.id === checkId 
          ? { ...check, status: check.status === 'compliant' ? 'warning' : 'compliant' }
          : check
      ));
    } else {
      setGdprChecks(prev => prev.map(check => 
        check.id === checkId 
          ? { ...check, status: check.status === 'compliant' ? 'warning' : 'compliant' }
          : check
      ));
    }
    addLog('info', `Updated check status`);
  };

  const runComplianceAudit = async () => {
    setIsAuditing(true);
    addLog('info', 'Starting compliance audit...');
    
    // Simulate audit process
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    updateStats();
    setIsAuditing(false);
    addLog('success', `Compliance audit completed. Score: ${complianceScore}%`);
  };

  const exportReport = () => {
    const report = {
      timestamp: new Date().toISOString(),
      complianceScore,
      tcpaChecks,
      gdprChecks,
      summary: stats
    };
    
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `compliance_report_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    addLog('success', 'Compliance report exported');
  };

  const updatePolicies = () => {
    addLog('info', 'Opening policy update interface...');
    alert('Policy update interface would open here');
  };

  const addLog = (type: string, message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setLogs(prev => [...prev, `[${timestamp}] ${message}`]);
  };

  const clearLogs = () => {
    setLogs(['Logs cleared.']);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'compliant': return <CheckCircle className="w-5 h-5 text-success" />;
      case 'warning': return <AlertTriangle className="w-5 h-5 text-warning" />;
      case 'violation': return <XCircle className="w-5 h-5 text-error" />;
      case 'pending': return <Clock className="w-5 h-5 text-info" />;
      default: return <AlertCircle className="w-5 h-5 text-muted-foreground" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'compliant': return 'Compliant';
      case 'warning': return 'Warning';
      case 'violation': return 'Violation';
      case 'pending': return 'Pending';
      default: return 'Unknown';
    }
  };

  const getRiskClass = (risk: string) => {
    switch (risk) {
      case 'low': return 'risk-low';
      case 'medium': return 'risk-medium';
      case 'high': return 'risk-high';
      default: return 'risk-low';
    }
  };

  const renderChecklist = (checks: ComplianceCheck[], type: 'tcpa' | 'gdpr') => (
    <div className="space-y-3">
      {checks.map(check => (
        <div key={check.id} className={`compliance-item ${check.status}`}>
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <h4 className="font-medium text-foreground">{check.name}</h4>
              <p className="text-sm text-muted-foreground">{check.description}</p>
              <div className="flex items-center gap-2 mt-2">
                <span className={`risk-level ${getRiskClass(check.risk)}`}>
                  {check.risk.toUpperCase()} RISK
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1">
                {getStatusIcon(check.status)}
                <span className={`status-${check.status}`}>
                  {getStatusText(check.status)}
                </span>
              </div>
              <button 
                className="btn btn-outline btn-sm"
                onClick={() => toggleCheck(type, check.id)}
              >
                Toggle
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground gradient-text">Compliance & Safety</h1>
          <p className="text-muted-foreground mt-2">Ensure regulatory compliance and safety standards for your voice AI agents.</p>
        </div>
        <div className="flex gap-2">
          <button 
            className="btn btn-primary"
            onClick={runComplianceAudit}
            disabled={isAuditing}
          >
            {isAuditing && <div className="loading-spinner mr-2" />}
            Run Compliance Audit
          </button>
          <button className="btn btn-outline" onClick={exportReport}>
            <Download className="w-4 h-4 mr-2" />
            Export Report
          </button>
          <button className="btn btn-outline" onClick={updatePolicies}>
            <Settings className="w-4 h-4 mr-2" />
            Update Policies
          </button>
        </div>
      </div>

      {/* Compliance Overview */}
      <div className="card p-6">
        <h2 className="text-2xl font-semibold text-foreground mb-6">Compliance Overview</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-center mb-6">
          <div className="card p-4">
            <div className="text-3xl font-bold gradient-text">{stats.total}</div>
            <div className="text-sm text-muted-foreground">Total Checks</div>
          </div>
          <div className="card p-4">
            <div className="text-3xl font-bold text-success">{stats.compliant}</div>
            <div className="text-sm text-muted-foreground">Compliant</div>
          </div>
          <div className="card p-4">
            <div className="text-3xl font-bold text-warning">{stats.warning}</div>
            <div className="text-sm text-muted-foreground">Warnings</div>
          </div>
          <div className="card p-4">
            <div className="text-3xl font-bold text-error">{stats.violation}</div>
            <div className="text-sm text-muted-foreground">Violations</div>
          </div>
        </div>

        {/* Compliance Score */}
        <div className="card p-4">
          <h3 className="text-lg font-semibold text-foreground mb-4">Overall Compliance Score</h3>
          <div className="w-full bg-muted rounded-full h-4 relative overflow-hidden mb-4">
            <div 
              className="progress-bar bg-primary rounded-full" 
              style={{ width: `${complianceScore}%` }}
            />
          </div>
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>
              {complianceScore >= 90 ? 'Excellent compliance' :
               complianceScore >= 70 ? 'Good compliance' :
               complianceScore >= 50 ? 'Needs improvement' :
               'Poor compliance'}
            </span>
            <span>{complianceScore}%</span>
          </div>
        </div>
      </div>

      {/* Main Content Tabs */}
      <div className="tabs">
        <div 
          className={`tab ${activeTab === 'tcpa' ? 'active' : ''}`}
          onClick={() => setActiveTab('tcpa')}
        >
          TCPA Compliance
        </div>
        <div 
          className={`tab ${activeTab === 'gdpr' ? 'active' : ''}`}
          onClick={() => setActiveTab('gdpr')}
        >
          GDPR Compliance
        </div>
        <div 
          className={`tab ${activeTab === 'safety' ? 'active' : ''}`}
          onClick={() => setActiveTab('safety')}
        >
          Safety Checks
        </div>
        <div 
          className={`tab ${activeTab === 'policies' ? 'active' : ''}`}
          onClick={() => setActiveTab('policies')}
        >
          Policies
        </div>
      </div>

      {/* Tab Content */}
      {activeTab === 'tcpa' && (
        <div className="card p-6">
          <h3 className="text-xl font-semibold text-foreground mb-4">TCPA Compliance Checklist</h3>
          {renderChecklist(tcpaChecks, 'tcpa')}
        </div>
      )}

      {activeTab === 'gdpr' && (
        <div className="card p-6">
          <h3 className="text-xl font-semibold text-foreground mb-4">GDPR Compliance Checklist</h3>
          {renderChecklist(gdprChecks, 'gdpr')}
        </div>
      )}

      {activeTab === 'safety' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="card p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
              <Lock className="w-5 h-5" />
              Data Security
            </h3>
            <div className="space-y-3">
              {safetyChecks.slice(0, 3).map((check, index) => (
                <div key={index} className={`compliance-item ${check.status}`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-foreground">{check.name}</h4>
                      <p className="text-sm text-muted-foreground">{check.description}</p>
                    </div>
                    <div className="flex items-center gap-1">
                      {getStatusIcon(check.status)}
                      <span className={`status-${check.status}`}>
                        {getStatusText(check.status)}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="card p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Voice AI Safety
            </h3>
            <div className="space-y-3">
              {safetyChecks.slice(3).map((check, index) => (
                <div key={index} className={`compliance-item ${check.status}`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-foreground">{check.name}</h4>
                      <p className="text-sm text-muted-foreground">{check.description}</p>
                    </div>
                    <div className="flex items-center gap-1">
                      {getStatusIcon(check.status)}
                      <span className={`status-${check.status}`}>
                        {getStatusText(check.status)}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'policies' && (
        <div className="space-y-6">
          <div className="card p-6">
            <h3 className="text-xl font-semibold text-foreground mb-4">Compliance Policies</h3>
            <div className="space-y-4">
              {policies.map((policy, index) => (
                <div key={index} className={`compliance-item ${policy.status}`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-foreground">{policy.name}</h4>
                      <p className="text-sm text-muted-foreground">Last updated: {policy.lastUpdated}</p>
                    </div>
                    <div className="flex gap-2">
                      <div className="flex items-center gap-1">
                        {getStatusIcon(policy.status)}
                        <span className={`status-${policy.status}`}>
                          {policy.status === 'compliant' ? 'Active' : 'Needs Update'}
                        </span>
                      </div>
                      <button className="btn btn-outline btn-sm">Edit</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="card p-6">
            <h3 className="text-xl font-semibold text-foreground mb-4">Risk Assessment</h3>
            <div className="space-y-4">
              {riskLevels.map((risk, index) => (
                <div key={index} className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div>
                    <h4 className="font-medium text-foreground">{risk.name}</h4>
                    <p className="text-sm text-muted-foreground">{risk.description}</p>
                  </div>
                  <span className={`risk-level ${getRiskClass(risk.level)}`}>
                    {risk.level.toUpperCase()} RISK
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Compliance Logs */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold text-foreground">Compliance Logs</h3>
          <button className="btn btn-outline" onClick={clearLogs}>
            Clear Logs
          </button>
        </div>
        <div className="bg-muted p-4 rounded-md h-64 overflow-y-auto font-mono text-sm">
          {logs.map((log, index) => (
            <div key={index} className="log-entry text-info mb-1">
              {log}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ComplianceSafety;
