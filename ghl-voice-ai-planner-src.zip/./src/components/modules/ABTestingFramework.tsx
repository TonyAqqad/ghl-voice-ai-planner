import React, { useState, useEffect } from 'react';
import { 
  TestTube, 
  BarChart3, 
  TrendingUp, 
  Target, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  RefreshCw, 
  Play, 
  Pause, 
  Settings, 
  Download, 
  Upload, 
  Save, 
  Edit, 
  Trash2, 
  Plus, 
  Minus, 
  ChevronDown, 
  ChevronRight, 
  Eye, 
  EyeOff, 
  Filter, 
  Search, 
  SortAsc, 
  SortDesc, 
  MoreHorizontal, 
  Star, 
  ThumbsUp, 
  ThumbsDown, 
  Heart, 
  Smile, 
  Frown, 
  Meh, 
  Award, 
  Trophy, 
  Medal, 
  Crown, 
  Flame, 
  Lightning, 
  Rocket, 
  Shield, 
  Lock, 
  Unlock, 
  Key, 
  Wrench, 
  Cog, 
  Sliders, 
  ToggleLeft, 
  ToggleRight, 
  Switch, 
  Power, 
  PowerOff, 
  Battery, 
  BatteryCharging, 
  Wifi, 
  WifiOff, 
  Signal, 
  SignalZero, 
  SignalOne, 
  SignalTwo, 
  SignalThree, 
  SignalFour, 
  SignalFive,
  MessageSquare,
  Mic,
  Headphones,
  Volume2,
  VolumeX,
  SkipForward,
  SkipBack,
  RotateCcw,
  LineChart,
  PieChart,
  Activity,
  Clock,
  Users,
  Phone,
  Bot,
  Brain,
  Database,
  Server,
  Globe,
  FileText,
  FileCheck,
  FileX,
  FileAlert,
  FileLock,
  FileShield,
  FileSearch,
  FileCode,
  FileImage,
  FileVideo,
  FileAudio,
  FileArchive,
  FileSpreadsheet,
  FilePresentation,
  FilePdf,
  FileWord,
  FileExcel,
  FilePowerpoint,
  FileZip,
  FileRar,
  File7z,
  FileTar,
  FileGz,
  FileBz2,
  FileXz,
  FileLz4,
  FileZstd,
  FileCab,
  FileIso,
  FileDmg,
  FileImg,
  FileVhd,
  FileVdi,
  FileVmdk,
  FileOva,
  FileOvf,
  FileVagrant,
  FileDocker,
  FileKubernetes,
  FileTerraform,
  FileAnsible,
  FileChef,
  FilePuppet,
  FileSalt,
  FileConsul,
  FileVault,
  FileNomad,
  FileDockerCompose,
  FileKustomize,
  FileHelm,
  FileIstio,
  FileLinkerd,
  FileEnvoy,
  FileNginx,
  FileApache,
  FileIis,
  FileTomcat,
  FileJetty,
  FileWildfly,
  FileWeblogic,
  FileWebsphere,
  FileGlassfish,
  FileJboss,
  FileResin,
  FileGeronimo,
  FileOpenliberty,
  FilePayara,
  FileTomee,
  FileWeld,
  FileDeltaspike,
  FileShiro,
  FileSpring,
  FileHibernate,
  FileMybatis,
  FileJpa,
  FileJdbc,
  FileJndi,
  FileJms,
  FileJta,
  FileJca,
  FileJaxb,
  FileJaxrs,
  FileJaxws,
  FileJsf,
  FileStruts,
  FileVaadin,
  FileGwt,
  FileWicket,
  FileTapestry,
  FileSeam,
  FileRichfaces,
  FilePrimefaces,
  FileIcefaces,
  FileOpenfaces,
  FileButterfaces,
  FileBootsfaces,
  FileOmnifaces,
  FileAngularfaces,
  FileAngular,
  FileReact,
  FileVue,
  FileSvelte,
  FileEmber,
  FileBackbone,
  FileKnockout,
  FileMithril,
  FilePreact,
  FileInferno,
  FileRiot,
  FileStencil,
  FileLit,
  FilePolymer,
  FileAurelia,
  FileMithril,
  FileHyperapp,
  FileAlpine,
  FileStimulus,
  FileTurbo,
  FileHotwire,
  FileLivewire,
  FileInertia,
  FileNext,
  FileNuxt,
  FileSapper,
  FileSveltekit,
  FileRemix,
  FileSolid,
  FileQwik,
  FileMarko,
  FileMithril,
  FileHyperapp,
  FileAlpine,
  FileStimulus,
  FileTurbo,
  FileHotwire,
  FileLivewire,
  FileInertia,
  FileNext,
  FileNuxt,
  FileSapper,
  FileSveltekit,
  FileRemix,
  FileSolid,
  FileQwik,
  FileMarko,
  Info,
  ExternalLink,
  Copy,
  Link,
  Unlink,
  Send,
  Receive,
  ArrowRight,
  ArrowLeft,
  ArrowUp,
  ArrowDown,
  RotateCw,
  RotateCcw,
  Move,
  MoveUp,
  MoveDown,
  MoveLeft,
  MoveRight,
  Maximize,
  Minimize,
  Maximize2,
  Minimize2,
  Square,
  Circle,
  Triangle,
  Hexagon,
  Octagon,
  Pentagon,
  Diamond,
  RectangleHorizontal,
  RectangleVertical,
  Ellipse,
  Oval,
  Parallelogram,
  Trapezoid,
  Rhombus,
  Kite,
  Star as StarIcon,
  Heart as HeartIcon,
  Smile as SmileIcon,
  Frown as FrownIcon,
  Meh as MehIcon,
  ThumbsUp as ThumbsUpIcon,
  ThumbsDown as ThumbsDownIcon,
  Award as AwardIcon,
  Trophy as TrophyIcon,
  Medal as MedalIcon,
  Crown as CrownIcon,
  Flame as FlameIcon,
  Lightning as LightningIcon,
  Rocket as RocketIcon,
  Shield as ShieldIcon,
  Lock as LockIcon,
  Unlock as UnlockIcon,
  Key as KeyIcon,
  Wrench as WrenchIcon,
  Cog as CogIcon,
  Sliders as SlidersIcon,
  ToggleLeft as ToggleLeftIcon,
  ToggleRight as ToggleRightIcon,
  Switch as SwitchIcon,
  Power as PowerIcon,
  PowerOff as PowerOffIcon,
  Battery as BatteryIcon,
  BatteryCharging as BatteryChargingIcon,
  Wifi as WifiIcon,
  WifiOff as WifiOffIcon,
  Signal as SignalIcon,
  SignalZero as SignalZeroIcon,
  SignalOne as SignalOneIcon,
  SignalTwo as SignalTwoIcon,
  SignalThree as SignalThreeIcon,
  SignalFour as SignalFourIcon,
  SignalFive as SignalFiveIcon,
  MessageSquare as MessageSquareIcon,
  Mic as MicIcon,
  Headphones as HeadphonesIcon,
  Volume2 as Volume2Icon,
  VolumeX as VolumeXIcon,
  Play as PlayIcon,
  Pause as PauseIcon,
  SkipForward as SkipForwardIcon,
  SkipBack as SkipBackIcon,
  RotateCcw as RotateCcwIcon,
  BarChart3 as BarChart3Icon,
  LineChart as LineChartIcon,
  PieChart as PieChartIcon,
  Activity as ActivityIcon,
  Clock as ClockIcon,
  Phone as PhoneIcon,
  Bot as BotIcon,
  Brain as BrainIcon,
  Target as TargetIcon,
  TrendingUp as TrendingUpIcon,
  TrendingDown,
  Database as DatabaseIcon,
  Server as ServerIcon,
  Globe as GlobeIcon,
  FileText as FileTextIcon,
  FileCheck as FileCheckIcon,
  FileX as FileXIcon,
  FileAlert as FileAlertIcon,
  FileLock as FileLockIcon,
  FileShield as FileShieldIcon,
  FileSearch as FileSearchIcon,
  FileCode as FileCodeIcon,
  FileImage as FileImageIcon,
  FileVideo as FileVideoIcon,
  FileAudio as FileAudioIcon,
  FileArchive as FileArchiveIcon,
  FileSpreadsheet as FileSpreadsheetIcon,
  FilePresentation as FilePresentationIcon,
  FilePdf as FilePdfIcon,
  FileWord as FileWordIcon,
  FileExcel as FileExcelIcon,
  FilePowerpoint as FilePowerpointIcon,
  FileZip as FileZipIcon,
  FileRar as FileRarIcon,
  File7z as File7zIcon,
  FileTar as FileTarIcon,
  FileGz as FileGzIcon,
  FileBz2 as FileBz2Icon,
  FileXz as FileXzIcon,
  FileLz4 as FileLz4Icon,
  FileZstd as FileZstdIcon,
  FileCab as FileCabIcon,
  FileIso as FileIsoIcon,
  FileDmg as FileDmgIcon,
  FileImg as FileImgIcon,
  FileVhd as FileVhdIcon,
  FileVdi as FileVdiIcon,
  FileVmdk as FileVmdkIcon,
  FileOva as FileOvaIcon,
  FileOvf as FileOvfIcon,
  FileVagrant as FileVagrantIcon,
  FileDocker as FileDockerIcon,
  FileKubernetes as FileKubernetesIcon,
  FileTerraform as FileTerraformIcon,
  FileAnsible as FileAnsibleIcon,
  FileChef as FileChefIcon,
  FilePuppet as FilePuppetIcon,
  FileSalt as FileSaltIcon,
  FileConsul as FileConsulIcon,
  FileVault as FileVaultIcon,
  FileNomad as FileNomadIcon,
  FileDockerCompose as FileDockerComposeIcon,
  FileKustomize as FileKustomizeIcon,
  FileHelm as FileHelmIcon,
  FileIstio as FileIstioIcon,
  FileLinkerd as FileLinkerdIcon,
  FileEnvoy as FileEnvoyIcon,
  FileNginx as FileNginxIcon,
  FileApache as FileApacheIcon,
  FileIis as FileIisIcon,
  FileTomcat as FileTomcatIcon,
  FileJetty as FileJettyIcon,
  FileWildfly as FileWildflyIcon,
  FileWeblogic as FileWeblogicIcon,
  FileWebsphere as FileWebsphereIcon,
  FileGlassfish as FileGlassfishIcon,
  FileJboss as FileJbossIcon,
  FileResin as FileResinIcon,
  FileGeronimo as FileGeronimoIcon,
  FileOpenliberty as FileOpenlibertyIcon,
  FilePayara as FilePayaraIcon,
  FileTomee as FileTomeeIcon,
  FileWeld as FileWeldIcon,
  FileDeltaspike as FileDeltaspikeIcon,
  FileShiro as FileShiroIcon,
  FileSpring as FileSpringIcon,
  FileHibernate as FileHibernateIcon,
  FileMybatis as FileMybatisIcon,
  FileJpa as FileJpaIcon,
  FileJdbc as FileJdbcIcon,
  FileJndi as FileJndiIcon,
  FileJms as FileJmsIcon,
  FileJta as FileJtaIcon,
  FileJca as FileJcaIcon,
  FileJaxb as FileJaxbIcon,
  FileJaxrs as FileJaxrsIcon,
  FileJaxws as FileJaxwsIcon,
  FileJsf as FileJsfIcon,
  FileStruts as FileStrutsIcon,
  FileVaadin as FileVaadinIcon,
  FileGwt as FileGwtIcon,
  FileWicket as FileWicketIcon,
  FileTapestry as FileTapestryIcon,
  FileSeam as FileSeamIcon,
  FileRichfaces as FileRichfacesIcon,
  FilePrimefaces as FilePrimefacesIcon,
  FileIcefaces as FileIcefacesIcon,
  FileOpenfaces as FileOpenfacesIcon,
  FileButterfaces as FileButterfacesIcon,
  FileBootsfaces as FileBootsfacesIcon,
  FileOmnifaces as FileOmnifacesIcon,
  FileAngularfaces as FileAngularfacesIcon,
  FileAngular as FileAngularIcon,
  FileReact as FileReactIcon,
  FileVue as FileVueIcon,
  FileSvelte as FileSvelteIcon,
  FileEmber as FileEmberIcon,
  FileBackbone as FileBackboneIcon,
  FileKnockout as FileKnockoutIcon,
  FileMithril as FileMithrilIcon,
  FilePreact as FilePreactIcon,
  FileInferno as FileInfernoIcon,
  FileRiot as FileRiotIcon,
  FileStencil as FileStencilIcon,
  FileLit as FileLitIcon,
  FilePolymer as FilePolymerIcon,
  FileAurelia as FileAureliaIcon,
  FileMithril as FileMithrilIcon,
  FileHyperapp as FileHyperappIcon,
  FileAlpine as FileAlpineIcon,
  FileStimulus as FileStimulusIcon,
  FileTurbo as FileTurboIcon,
  FileHotwire as FileHotwireIcon,
  FileLivewire as FileLivewireIcon,
  FileInertia as FileInertiaIcon,
  FileNext as FileNextIcon,
  FileNuxt as FileNuxtIcon,
  FileSapper as FileSapperIcon,
  FileSveltekit as FileSveltekitIcon,
  FileRemix as FileRemixIcon,
  FileSolid as FileSolidIcon,
  FileQwik as FileQwikIcon,
  FileMarko as FileMarkoIcon,
  FileMithril as FileMithrilIcon,
  FileHyperapp as FileHyperappIcon,
  FileAlpine as FileAlpineIcon,
  FileStimulus as FileStimulusIcon,
  FileTurbo as FileTurboIcon,
  FileHotwire as FileHotwireIcon,
  FileLivewire as FileLivewireIcon,
  FileInertia as FileInertiaIcon,
  FileNext as FileNextIcon,
  FileNuxt as FileNuxtIcon,
  FileSapper as FileSapperIcon,
  FileSveltekit as FileSveltekitIcon,
  FileRemix as FileRemixIcon,
  FileSolid as FileSolidIcon,
  FileQwik as FileQwikIcon,
  FileMarko as FileMarkoIcon
} from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';

interface ABTest {
  id: string;
  name: string;
  description: string;
  agentId: string;
  agentName: string;
  status: 'draft' | 'running' | 'paused' | 'completed' | 'cancelled';
  hypothesis: string;
  successMetric: string;
  confidenceLevel: number;
  minimumDetectableEffect: number;
  trafficSplit: number; // Percentage for variant A
  variants: Array<{
    id: string;
    name: string;
    description: string;
    configuration: any;
    trafficPercentage: number;
  }>;
  results: {
    totalParticipants: number;
    variantA: {
      participants: number;
      conversions: number;
      conversionRate: number;
      avgDuration: number;
      costPerConversion: number;
      confidenceInterval: [number, number];
    };
    variantB: {
      participants: number;
      conversions: number;
      conversionRate: number;
      avgDuration: number;
      costPerConversion: number;
      confidenceInterval: [number, number];
    };
    statisticalSignificance: boolean;
    pValue: number;
    winner: 'A' | 'B' | 'inconclusive';
    improvement: number;
  };
  createdAt: string;
  startedAt: string | null;
  endedAt: string | null;
  createdBy: string;
}

interface TestTemplate {
  id: string;
  name: string;
  description: string;
  category: 'voice_optimization' | 'script_optimization' | 'flow_optimization' | 'timing_optimization' | 'personalization';
  variables: Array<{
    name: string;
    type: 'voice' | 'script' | 'flow' | 'timing' | 'personalization';
    description: string;
    options: string[];
  }>;
  successMetrics: string[];
  estimatedDuration: number;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
}

interface TestInsight {
  id: string;
  testId: string;
  type: 'performance' | 'behavioral' | 'conversion' | 'cost';
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  confidence: number;
  recommendation: string;
  createdAt: string;
}

const ABTestingFramework: React.FC = () => {
  const { darkMode } = useStore();
  const [tests, setTests] = useState<ABTest[]>([]);
  const [templates, setTemplates] = useState<TestTemplate[]>([]);
  const [insights, setInsights] = useState<TestInsight[]>([]);
  const [selectedTest, setSelectedTest] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [activeTab, setActiveTab] = useState<'overview' | 'tests' | 'templates' | 'insights' | 'analytics'>('overview');

  // Sample data
  useEffect(() => {
    const sampleTests: ABTest[] = [
      {
        id: 'test_1',
        name: 'F45 Greeting Optimization',
        description: 'Test different greeting approaches for F45 trial booking calls',
        agentId: 'agent_1',
        agentName: 'F45 Fitness Agent',
        status: 'running',
        hypothesis: 'A more energetic greeting will increase trial booking conversion by 15%',
        successMetric: 'Trial Booking Conversion Rate',
        confidenceLevel: 95,
        minimumDetectableEffect: 0.15,
        trafficSplit: 50,
        variants: [
          {
            id: 'variant_a',
            name: 'Control - Standard Greeting',
            description: 'Current greeting: "Hi, this is Sarah from F45. How can I help you today?"',
            configuration: {
              greeting: 'Hi, this is Sarah from F45. How can I help you today?',
              tone: 'professional',
              energy: 'medium'
            },
            trafficPercentage: 50
          },
          {
            id: 'variant_b',
            name: 'Energetic Greeting',
            description: 'New greeting: "Hey there! Sarah here from F45 - are you ready to transform your fitness journey?"',
            configuration: {
              greeting: 'Hey there! Sarah here from F45 - are you ready to transform your fitness journey?',
              tone: 'enthusiastic',
              energy: 'high'
            },
            trafficPercentage: 50
          }
        ],
        results: {
          totalParticipants: 1247,
          variantA: {
            participants: 623,
            conversions: 89,
            conversionRate: 0.143,
            avgDuration: 195,
            costPerConversion: 2.85,
            confidenceInterval: [0.115, 0.171]
          },
          variantB: {
            participants: 624,
            conversions: 134,
            conversionRate: 0.215,
            avgDuration: 210,
            costPerConversion: 2.45,
            confidenceInterval: [0.183, 0.247]
          },
          statisticalSignificance: true,
          pValue: 0.003,
          winner: 'B',
          improvement: 0.502
        },
        createdAt: '2024-01-10T10:00:00Z',
        startedAt: '2024-01-10T14:00:00Z',
        endedAt: null,
        createdBy: 'Sarah Johnson'
      },
      {
        id: 'test_2',
        name: 'Legal Consultation Script Test',
        description: 'Test different approaches to legal consultation booking',
        agentId: 'agent_2',
        agentName: 'Legal Consultation Agent',
        status: 'completed',
        hypothesis: 'Asking about case type first will improve qualification accuracy',
        successMetric: 'Qualified Lead Rate',
        confidenceLevel: 95,
        minimumDetectableEffect: 0.20,
        trafficSplit: 50,
        variants: [
          {
            id: 'variant_a',
            name: 'Control - General Approach',
            description: 'Current approach: General consultation inquiry',
            configuration: {
              approach: 'general',
              firstQuestion: 'What type of legal assistance are you looking for?'
            },
            trafficPercentage: 50
          },
          {
            id: 'variant_b',
            name: 'Case Type First',
            description: 'New approach: Ask about specific case type immediately',
            configuration: {
              approach: 'specific',
              firstQuestion: 'Are you dealing with a personal injury, family law, or business matter?'
            },
            trafficPercentage: 50
          }
        ],
        results: {
          totalParticipants: 567,
          variantA: {
            participants: 283,
            conversions: 45,
            conversionRate: 0.159,
            avgDuration: 240,
            costPerConversion: 4.20,
            confidenceInterval: [0.118, 0.200]
          },
          variantB: {
            participants: 284,
            conversions: 67,
            conversionRate: 0.236,
            avgDuration: 220,
            costPerConversion: 3.85,
            confidenceInterval: [0.189, 0.283]
          },
          statisticalSignificance: true,
          pValue: 0.012,
          winner: 'B',
          improvement: 0.484
        },
        createdAt: '2024-01-05T09:00:00Z',
        startedAt: '2024-01-05T12:00:00Z',
        endedAt: '2024-01-12T18:00:00Z',
        createdBy: 'Mike Chen'
      }
    ];

    const sampleTemplates: TestTemplate[] = [
      {
        id: 'template_1',
        name: 'Voice Tone Optimization',
        description: 'Test different voice tones and energy levels',
        category: 'voice_optimization',
        variables: [
          {
            name: 'Voice Tone',
            type: 'voice',
            description: 'The emotional tone of the voice',
            options: ['Professional', 'Friendly', 'Enthusiastic', 'Calm', 'Authoritative']
          },
          {
            name: 'Energy Level',
            type: 'voice',
            description: 'The energy and pace of speech',
            options: ['Low', 'Medium', 'High']
          }
        ],
        successMetrics: ['Conversion Rate', 'Customer Satisfaction', 'Call Duration'],
        estimatedDuration: 7,
        difficulty: 'beginner'
      },
      {
        id: 'template_2',
        name: 'Script Personalization',
        description: 'Test personalized vs generic scripts',
        category: 'personalization',
        variables: [
          {
            name: 'Personalization Level',
            type: 'personalization',
            description: 'How much personalization to include',
            options: ['None', 'Basic', 'Advanced', 'Full']
          },
          {
            name: 'Data Points',
            type: 'personalization',
            description: 'Which customer data to use',
            options: ['Name Only', 'Name + Location', 'Name + Location + History', 'All Available']
          }
        ],
        successMetrics: ['Engagement Rate', 'Conversion Rate', 'Customer Satisfaction'],
        estimatedDuration: 14,
        difficulty: 'intermediate'
      }
    ];

    const sampleInsights: TestInsight[] = [
      {
        id: 'insight_1',
        testId: 'test_1',
        type: 'conversion',
        title: 'Energetic Greeting Increases Conversion by 50%',
        description: 'The energetic greeting variant showed a 50.2% improvement in trial booking conversion rate',
        impact: 'high',
        confidence: 0.997,
        recommendation: 'Implement the energetic greeting as the default for all F45 trial booking calls',
        createdAt: '2024-01-15T14:30:00Z'
      },
      {
        id: 'insight_2',
        testId: 'test_2',
        type: 'behavioral',
        title: 'Specific Questions Improve Lead Quality',
        description: 'Asking about case type first resulted in 48% more qualified leads',
        impact: 'high',
        confidence: 0.988,
        recommendation: 'Update all legal consultation agents to ask about case type first',
        createdAt: '2024-01-12T18:00:00Z'
      }
    ];

    setTests(sampleTests);
    setTemplates(sampleTemplates);
    setInsights(sampleInsights);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'text-green-400 bg-green-100';
      case 'completed': return 'text-blue-400 bg-blue-100';
      case 'paused': return 'text-yellow-400 bg-yellow-100';
      case 'draft': return 'text-gray-400 bg-gray-100';
      case 'cancelled': return 'text-red-400 bg-red-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'text-green-400 bg-green-100';
      case 'medium': return 'text-yellow-400 bg-yellow-100';
      case 'low': return 'text-blue-400 bg-blue-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'text-green-400 bg-green-100';
      case 'intermediate': return 'text-yellow-400 bg-yellow-100';
      case 'advanced': return 'text-red-400 bg-red-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const handleStartTest = (testId: string) => {
    toast.success('Starting A/B test...');
    // Simulate starting test
    setTimeout(() => {
      toast.success('A/B test started successfully!');
    }, 1000);
  };

  const handleStopTest = (testId: string) => {
    toast.success('Stopping A/B test...');
    // Simulate stopping test
    setTimeout(() => {
      toast.success('A/B test stopped successfully!');
    }, 1000);
  };

  const renderOverviewTab = () => (
    <div className="space-y-6">
      {/* Test Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Active Tests</p>
              <p className="text-2xl font-bold text-foreground">
                {tests.filter(test => test.status === 'running').length}
              </p>
            </div>
            <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
              <TestTube className="w-6 h-6 text-primary" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Completed Tests</p>
              <p className="text-2xl font-bold text-foreground">
                {tests.filter(test => test.status === 'completed').length}
              </p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Avg Improvement</p>
              <p className="text-2xl font-bold text-blue-400">
                {Math.round(tests.filter(test => test.status === 'completed').reduce((acc, test) => acc + test.results.improvement, 0) / tests.filter(test => test.status === 'completed').length * 100)}%
              </p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Participants</p>
              <p className="text-2xl font-bold text-foreground">
                {tests.reduce((acc, test) => acc + test.results.totalParticipants, 0).toLocaleString()}
              </p>
            </div>
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Recent Test Results */}
      <div className="card p-6">
        <h2 className="text-xl font-semibold text-foreground mb-6">Recent Test Results</h2>
        <div className="space-y-4">
          {tests.slice(0, 3).map((test) => (
            <div key={test.id} className="flex items-center justify-between p-4 bg-secondary rounded-lg">
              <div className="flex items-center space-x-4">
                <div className={`w-3 h-3 rounded-full ${getStatusColor(test.status).split(' ')[0]}`}></div>
                <div>
                  <p className="font-medium text-foreground">{test.name}</p>
                  <p className="text-sm text-muted-foreground">{test.agentName}</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <p className="text-sm font-medium text-foreground">
                    {test.status === 'completed' ? `${Math.round(test.results.improvement * 100)}% improvement` : 'In Progress'}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {test.results.totalParticipants} participants
                  </p>
                </div>
                <div className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(test.status)}`}>
                  {test.status}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderTestsTab = () => (
    <div className="space-y-6">
      {/* A/B Tests */}
      <div className="space-y-4">
        {tests.map((test) => (
          <div key={test.id} className="card p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="text-lg font-semibold text-foreground">{test.name}</h3>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(test.status)}`}>
                    {test.status}
                  </div>
                  {test.status === 'completed' && test.results.winner !== 'inconclusive' && (
                    <div className="px-2 py-1 rounded-full text-xs font-medium text-green-400 bg-green-100">
                      Winner: {test.results.winner}
                    </div>
                  )}
                </div>
                <p className="text-muted-foreground mb-3">{test.description}</p>
                <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Bot className="w-4 h-4" />
                    <span>{test.agentName}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Users className="w-4 h-4" />
                    <span>{test.results.totalParticipants} participants</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Target className="w-4 h-4" />
                    <span>{test.successMetric}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{test.confidenceLevel}% confidence</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                {test.status === 'running' ? (
                  <button
                    onClick={() => handleStopTest(test.id)}
                    className="btn btn-outline btn-sm"
                  >
                    <Pause className="w-4 h-4 mr-2" />
                    Stop
                  </button>
                ) : test.status === 'draft' ? (
                  <button
                    onClick={() => handleStartTest(test.id)}
                    className="btn btn-primary btn-sm"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Start
                  </button>
                ) : null}
                <button className="btn btn-outline btn-sm">
                  <Eye className="w-4 h-4 mr-2" />
                  View
                </button>
              </div>
            </div>

            {/* Test Results */}
            {test.status === 'completed' && (
              <div className="mt-4">
                <h4 className="font-medium text-foreground mb-3">Test Results</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-secondary p-4 rounded-lg">
                    <h5 className="font-medium text-foreground mb-2">Variant A (Control)</h5>
                    <div className="space-y-1 text-sm">
                      <p className="text-muted-foreground">Participants: {test.results.variantA.participants}</p>
                      <p className="text-muted-foreground">Conversions: {test.results.variantA.conversions}</p>
                      <p className="text-foreground font-medium">Conversion Rate: {(test.results.variantA.conversionRate * 100).toFixed(1)}%</p>
                      <p className="text-muted-foreground">Avg Duration: {test.results.variantA.avgDuration}s</p>
                    </div>
                  </div>
                  <div className="bg-secondary p-4 rounded-lg">
                    <h5 className="font-medium text-foreground mb-2">Variant B (Test)</h5>
                    <div className="space-y-1 text-sm">
                      <p className="text-muted-foreground">Participants: {test.results.variantB.participants}</p>
                      <p className="text-muted-foreground">Conversions: {test.results.variantB.conversions}</p>
                      <p className="text-foreground font-medium">Conversion Rate: {(test.results.variantB.conversionRate * 100).toFixed(1)}%</p>
                      <p className="text-muted-foreground">Avg Duration: {test.results.variantB.avgDuration}s</p>
                    </div>
                  </div>
                </div>
                <div className="mt-4 p-3 bg-muted rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-foreground">
                        {test.results.statisticalSignificance ? 'Statistically Significant' : 'Not Statistically Significant'}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        P-value: {test.results.pValue.toFixed(3)} | Improvement: {Math.round(test.results.improvement * 100)}%
                      </p>
                    </div>
                    <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                      test.results.statisticalSignificance ? 'text-green-400 bg-green-100' : 'text-yellow-400 bg-yellow-100'
                    }`}>
                      {test.results.winner === 'inconclusive' ? 'Inconclusive' : `Winner: ${test.results.winner}`}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );

  const renderTemplatesTab = () => (
    <div className="space-y-6">
      {/* Test Templates */}
      <div className="space-y-4">
        {templates.map((template) => (
          <div key={template.id} className="card p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="text-lg font-semibold text-foreground">{template.name}</h3>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(template.difficulty)}`}>
                    {template.difficulty}
                  </div>
                </div>
                <p className="text-muted-foreground mb-3">{template.description}</p>
                <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Target className="w-4 h-4" />
                    <span>{template.category.replace('_', ' ')}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{template.estimatedDuration} days</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <TestTube className="w-4 h-4" />
                    <span>{template.variables.length} variables</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <button className="btn btn-outline btn-sm">
                  <Eye className="w-4 h-4 mr-2" />
                  Preview
                </button>
                <button className="btn btn-primary btn-sm">
                  <Plus className="w-4 h-4 mr-2" />
                  Use Template
                </button>
              </div>
            </div>

            {/* Variables */}
            <div className="mt-4">
              <h4 className="font-medium text-foreground mb-2">Test Variables</h4>
              <div className="space-y-2">
                {template.variables.map((variable, idx) => (
                  <div key={idx} className="flex items-center justify-between p-2 bg-secondary rounded">
                    <div>
                      <p className="text-sm font-medium text-foreground">{variable.name}</p>
                      <p className="text-xs text-muted-foreground">{variable.description}</p>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {variable.options.length} options
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Success Metrics */}
            <div className="mt-4">
              <h4 className="font-medium text-foreground mb-2">Success Metrics</h4>
              <div className="flex flex-wrap gap-2">
                {template.successMetrics.map((metric, idx) => (
                  <span key={idx} className="px-2 py-1 bg-primary/10 text-primary text-xs rounded">
                    {metric}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="p-6 bg-background min-h-screen text-foreground">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">A/B Testing Framework</h1>
            <p className="text-muted-foreground">
              Advanced A/B testing for voice AI agents with statistical analysis
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <button className="btn btn-outline">
              <Download className="w-4 h-4 mr-2" />
              Export Results
            </button>
            <button className="btn btn-outline">
              <Settings className="w-4 h-4 mr-2" />
              Test Settings
            </button>
            <button className="btn btn-primary">
              <Plus className="w-4 h-4 mr-2" />
              New Test
            </button>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="mb-6">
        <div className="flex space-x-1 bg-secondary p-1 rounded-lg w-fit">
          {[
            { id: 'overview', label: 'Overview', icon: BarChart3 },
            { id: 'tests', label: 'A/B Tests', icon: TestTube },
            { id: 'templates', label: 'Templates', icon: FileText },
            { id: 'insights', label: 'Insights', icon: Brain },
            { id: 'analytics', label: 'Analytics', icon: TrendingUp }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-primary text-primary-foreground shadow-lg'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      {activeTab === 'overview' && renderOverviewTab()}
      {activeTab === 'tests' && renderTestsTab()}
      {activeTab === 'templates' && renderTemplatesTab()}
      {activeTab === 'insights' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Test Insights</h2>
          <p className="text-muted-foreground">AI-powered insights from A/B test results will be displayed here.</p>
        </div>
      )}
      {activeTab === 'analytics' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Test Analytics</h2>
          <p className="text-muted-foreground">Advanced analytics and reporting interface will be displayed here.</p>
        </div>
      )}
    </div>
  );
};

export default ABTestingFramework;
