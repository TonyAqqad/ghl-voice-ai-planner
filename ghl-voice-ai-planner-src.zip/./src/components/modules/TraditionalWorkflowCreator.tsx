import React, { useState } from 'react';
import { Plus, Trash2, Save, Play, Settings, Filter, Zap, Phone, Mail, Calendar, User, Tag, MessageSquare, ExternalLink, ChevronDown, ChevronRight } from 'lucide-react';
import { useStore } from '../../store/useStore';

interface WorkflowStep {
  id: string;
  type: 'trigger' | 'filter' | 'action' | 'condition' | 'delay' | 'webhook';
  name: string;
  config: Record<string, any>;
  position: { x: number; y: number };
}

interface WorkflowConnection {
  id: string;
  from: string;
  to: string;
  condition?: string;
}

const TraditionalWorkflowCreator: React.FC = () => {
  const { addWorkflow } = useStore();
  const [workflowName, setWorkflowName] = useState('');
  const [workflowDescription, setWorkflowDescription] = useState('');
  const [steps, setSteps] = useState<WorkflowStep[]>([]);
  const [connections, setConnections] = useState<WorkflowConnection[]>([]);
  const [selectedStep, setSelectedStep] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  // GHL Trigger Categories
  const triggerCategories = {
    'Contact Triggers': [
      { id: 'contact_created', name: 'Contact Created', icon: User, description: 'New contact added to system' },
      { id: 'contact_changed', name: 'Contact Changed', icon: User, description: 'Any contact info modification' },
      { id: 'contact_tag', name: 'Contact Tag', icon: Tag, description: 'Tag added/removed from contact' },
      { id: 'contact_dnd', name: 'Contact DND', icon: Phone, description: 'Contact opts out of communication' },
      { id: 'birthday_reminder', name: 'Birthday Reminder', icon: Calendar, description: 'Fires daily at 8 AM based on DOB field' },
      { id: 'custom_date_reminder', name: 'Custom Date Reminder', icon: Calendar, description: 'Based on custom date field' },
      { id: 'note_added', name: 'Note Added/Changed', icon: MessageSquare, description: 'Note added to contact profile' },
      { id: 'task_added', name: 'Task Added/Completed', icon: Settings, description: 'Manual task created/completed' },
      { id: 'engagement_score', name: 'Contact Engagement Score', icon: Zap, description: 'Engagement score threshold met' }
    ],
    'Event Triggers': [
      { id: 'inbound_webhook', name: 'Inbound Webhook', icon: ExternalLink, description: 'External data received' },
      { id: 'call_status', name: 'Call Status', icon: Phone, description: 'Call activity occurs' },
      { id: 'email_events', name: 'Email Events', icon: Mail, description: 'Email interaction' },
      { id: 'conversations_applied', name: 'Conversations Applied', icon: MessageSquare, description: 'Customer responds on channel' },
      { id: 'form_submitted', name: 'Form Submitted', icon: Settings, description: 'Form submission' },
      { id: 'trigger_links_clicked', name: 'Trigger Links Clicked', icon: ExternalLink, description: 'Specific link clicked' },
      { id: 'facebook_lead_form', name: 'Facebook Lead Form', icon: ExternalLink, description: 'FB form submission' },
      { id: 'instagram_lead_form', name: 'Instagram Lead Form', icon: ExternalLink, description: 'IG form submission' },
      { id: 'video_tracking', name: 'Video Tracking', icon: Settings, description: 'Video interaction' },
      { id: 'twilio_validation_error', name: 'Twilio Validation Error', icon: Phone, description: 'Phone number error' },
      { id: 'transcript_generated', name: 'Transcript Generated', icon: MessageSquare, description: 'Call transcript ready' }
    ],
    'Appointment Triggers': [
      { id: 'appointment_status', name: 'Appointment Status', icon: Calendar, description: 'Appointment status changes' },
      { id: 'customer_booked_appointment', name: 'Customer Booked Appointment', icon: Calendar, description: 'Customer books appointment' }
    ],
    'Opportunity Triggers': [
      { id: 'opportunity_status_change', name: 'Opportunity Status Change', icon: Settings, description: 'Opportunity status updated' },
      { id: 'opportunity_created', name: 'Opportunity Created', icon: User, description: 'New opportunity' },
      { id: 'opportunity_changed', name: 'Opportunity Changed', icon: Settings, description: 'Any opportunity field changed' },
      { id: 'pipeline_stage_changed', name: 'Pipeline Stage Changed', icon: Settings, description: 'Opportunity moves stages' },
      { id: 'stale_opportunity', name: 'Stale Opportunity', icon: Settings, description: 'Opportunity inactive for X days' }
    ]
  };

  // GHL Action Categories
  const actionCategories = {
    'Communication Actions': [
      { id: 'send_sms', name: 'Send SMS', icon: MessageSquare, description: 'Send text message to contact' },
      { id: 'send_email', name: 'Send Email', icon: Mail, description: 'Send email to contact' },
      { id: 'make_call', name: 'Make Call', icon: Phone, description: 'Initiate outbound call' },
      { id: 'send_voicemail', name: 'Send Voicemail', icon: Phone, description: 'Send voicemail message' }
    ],
    'Contact Actions': [
      { id: 'add_tag', name: 'Add Tag', icon: Tag, description: 'Add tag to contact' },
      { id: 'remove_tag', name: 'Remove Tag', icon: Tag, description: 'Remove tag from contact' },
      { id: 'update_field', name: 'Update Field', icon: Settings, description: 'Update contact field value' },
      { id: 'add_note', name: 'Add Note', icon: MessageSquare, description: 'Add note to contact' },
      { id: 'create_task', name: 'Create Task', icon: Settings, description: 'Create task for contact' }
    ],
    'Appointment Actions': [
      { id: 'book_appointment', name: 'Book Appointment', icon: Calendar, description: 'Schedule appointment' },
      { id: 'reschedule_appointment', name: 'Reschedule Appointment', icon: Calendar, description: 'Change appointment time' },
      { id: 'cancel_appointment', name: 'Cancel Appointment', icon: Calendar, description: 'Cancel appointment' }
    ],
    'Opportunity Actions': [
      { id: 'create_opportunity', name: 'Create Opportunity', icon: User, description: 'Create new opportunity' },
      { id: 'update_opportunity', name: 'Update Opportunity', icon: Settings, description: 'Update opportunity fields' },
      { id: 'move_opportunity', name: 'Move Opportunity', icon: Settings, description: 'Change opportunity stage' }
    ],
    'System Actions': [
      { id: 'webhook', name: 'Webhook', icon: ExternalLink, description: 'Send data to external URL' },
      { id: 'delay', name: 'Delay', icon: Settings, description: 'Wait for specified time' },
      { id: 'condition', name: 'Condition', icon: Filter, description: 'If/Else logic branch' }
    ]
  };

  const addStep = (type: WorkflowStep['type'], triggerId?: string) => {
    const newStep: WorkflowStep = {
      id: `step_${Date.now()}`,
      type,
      name: triggerId ? triggerCategories[Object.keys(triggerCategories).find(cat => 
        triggerCategories[cat].some(t => t.id === triggerId)
      ) as keyof typeof triggerCategories]?.find(t => t.id === triggerId)?.name || 'New Step' : 'New Step',
      config: {},
      position: { x: 100 + (steps.length * 200), y: 100 }
    };
    setSteps([...steps, newStep]);
  };

  const updateStep = (stepId: string, updates: Partial<WorkflowStep>) => {
    setSteps(steps.map(step => 
      step.id === stepId ? { ...step, ...updates } : step
    ));
  };

  const deleteStep = (stepId: string) => {
    setSteps(steps.filter(step => step.id !== stepId));
    setConnections(connections.filter(conn => conn.from !== stepId && conn.to !== stepId));
  };

  const saveWorkflow = () => {
    if (!workflowName.trim()) return;
    
    const workflow = {
      id: `workflow_${Date.now()}`,
      name: workflowName,
      description: workflowDescription,
      trigger: {
        type: 'traditional' as const,
        conditions: {}
      },
      nodes: steps.map(step => ({
        id: step.id,
        type: step.type,
        config: step.config,
        position: step.position
      })),
      edges: connections.map(conn => ({
        id: conn.id,
        source: conn.from,
        target: conn.to,
        condition: conn.condition
      })),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    addWorkflow(workflow);
    // Reset form
    setWorkflowName('');
    setWorkflowDescription('');
    setSteps([]);
    setConnections([]);
  };

  const renderStepConfig = (step: WorkflowStep) => {
    switch (step.type) {
      case 'trigger':
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Trigger Configuration</h3>
            <div className="space-y-2">
              <label className="block text-sm font-medium">Trigger Type</label>
              <select 
                className="w-full p-2 border rounded-md bg-card text-foreground"
                value={step.config.triggerType || ''}
                onChange={(e) => updateStep(step.id, { 
                  config: { ...step.config, triggerType: e.target.value }
                })}
              >
                <option value="">Select Trigger</option>
                {Object.entries(triggerCategories).map(([category, triggers]) => (
                  <optgroup key={category} label={category}>
                    {triggers.map(trigger => (
                      <option key={trigger.id} value={trigger.id}>
                        {trigger.name}
                      </option>
                    ))}
                  </optgroup>
                ))}
              </select>
            </div>
          </div>
        );
      
      case 'action':
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Action Configuration</h3>
            <div className="space-y-2">
              <label className="block text-sm font-medium">Action Type</label>
              <select 
                className="w-full p-2 border rounded-md bg-card text-foreground"
                value={step.config.actionType || ''}
                onChange={(e) => updateStep(step.id, { 
                  config: { ...step.config, actionType: e.target.value }
                })}
              >
                <option value="">Select Action</option>
                {Object.entries(actionCategories).map(([category, actions]) => (
                  <optgroup key={category} label={category}>
                    {actions.map(action => (
                      <option key={action.id} value={action.id}>
                        {action.name}
                      </option>
                    ))}
                  </optgroup>
                ))}
              </select>
            </div>
          </div>
        );
      
      default:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">{step.type.charAt(0).toUpperCase() + step.type.slice(1)} Configuration</h3>
            <p className="text-muted-foreground">Configuration options will appear here based on the selected type.</p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Traditional Workflow Creator</h1>
          <p className="text-muted-foreground">
            Build GoHighLevel workflows with triggers, filters, actions, and conditions
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Workflow Canvas */}
          <div className="lg:col-span-3">
            <div className="card">
              <div className="card-header">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold">Workflow Builder</h2>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => addStep('trigger')}
                      className="btn btn-primary btn-sm"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add Trigger
                    </button>
                    <button
                      onClick={() => addStep('action')}
                      className="btn btn-outline btn-sm"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add Action
                    </button>
                    <button
                      onClick={saveWorkflow}
                      className="btn btn-primary btn-sm"
                      disabled={!workflowName.trim() || steps.length === 0}
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Save Workflow
                    </button>
                  </div>
                </div>
              </div>

              <div className="card-content">
                {/* Workflow Name */}
                <div className="mb-6 space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Workflow Name</label>
                    <input
                      type="text"
                      value={workflowName}
                      onChange={(e) => setWorkflowName(e.target.value)}
                      placeholder="Enter workflow name"
                      className="w-full p-3 border rounded-md bg-card text-foreground"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Description</label>
                    <textarea
                      value={workflowDescription}
                      onChange={(e) => setWorkflowDescription(e.target.value)}
                      placeholder="Describe what this workflow does"
                      rows={3}
                      className="w-full p-3 border rounded-md bg-card text-foreground"
                    />
                  </div>
                </div>

                {/* Workflow Canvas */}
                <div className="relative min-h-[400px] border-2 border-dashed border-border rounded-lg p-4">
                  {steps.length === 0 ? (
                    <div className="flex items-center justify-center h-64 text-muted-foreground">
                      <div className="text-center">
                        <Settings className="w-12 h-12 mx-auto mb-4 opacity-50" />
                        <p className="text-lg font-medium mb-2">Start Building Your Workflow</p>
                        <p className="text-sm">Add triggers and actions to create your automation</p>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {steps.map((step, index) => (
                        <div
                          key={step.id}
                          className={`card cursor-pointer transition-all duration-200 ${
                            selectedStep === step.id ? 'ring-2 ring-primary' : 'hover:shadow-md'
                          }`}
                          onClick={() => setSelectedStep(step.id)}
                        >
                          <div className="card-content">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-3">
                                <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                                  {step.type === 'trigger' && <Zap className="w-4 h-4 text-primary" />}
                                  {step.type === 'action' && <Settings className="w-4 h-4 text-primary" />}
                                  {step.type === 'condition' && <Filter className="w-4 h-4 text-primary" />}
                                  {step.type === 'delay' && <Settings className="w-4 h-4 text-primary" />}
                                  {step.type === 'webhook' && <ExternalLink className="w-4 h-4 text-primary" />}
                                </div>
                                <div>
                                  <h3 className="font-medium">{step.name}</h3>
                                  <p className="text-sm text-muted-foreground capitalize">{step.type}</p>
                                </div>
                              </div>
                              <div className="flex items-center space-x-2">
                                <span className="text-xs bg-muted px-2 py-1 rounded">
                                  Step {index + 1}
                                </span>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    deleteStep(step.id);
                                  }}
                                  className="p-1 hover:bg-destructive/20 rounded text-destructive"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Configuration Panel */}
          <div className="lg:col-span-1">
            <div className="card sticky top-6">
              <div className="card-header">
                <h3 className="text-lg font-semibold">Configuration</h3>
              </div>
              <div className="card-content">
                {selectedStep ? (
                  renderStepConfig(steps.find(s => s.id === selectedStep)!)
                ) : (
                  <div className="text-center text-muted-foreground">
                    <Settings className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p>Select a step to configure</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TraditionalWorkflowCreator;
