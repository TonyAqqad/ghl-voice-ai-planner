import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  Phone, 
  Users, 
  Clock, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  CheckCircle, 
  Zap, 
  BarChart3, 
  PieChart, 
  LineChart,
  Eye,
  RefreshCw,
  Play,
  Pause,
  Settings,
  Filter,
  Download,
  Calendar,
  MapPin,
  MessageSquare,
  Target,
  DollarSign
} from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';

interface CallMetrics {
  totalCalls: number;
  activeCalls: number;
  completedCalls: number;
  averageDuration: number;
  successRate: number;
  conversionRate: number;
  revenue: number;
}

interface AgentPerformance {
  id: string;
  name: string;
  callsHandled: number;
  successRate: number;
  averageDuration: number;
  conversionRate: number;
  revenue: number;
  status: 'online' | 'offline' | 'busy';
  lastActivity: string;
}

interface RealTimeCall {
  id: string;
  agentId: string;
  agentName: string;
  contactName: string;
  contactPhone: string;
  status: 'ringing' | 'connected' | 'on_hold' | 'transferred' | 'completed';
  duration: number;
  intent: string;
  confidence: number;
  location: string;
  startTime: string;
}

interface PerformanceAlert {
  id: string;
  type: 'success_rate' | 'call_volume' | 'response_time' | 'revenue';
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  timestamp: string;
  resolved: boolean;
}

const RealTimeMonitoring: React.FC = () => {
  const { darkMode } = useStore();
  const [callMetrics, setCallMetrics] = useState<CallMetrics>({
    totalCalls: 0,
    activeCalls: 0,
    completedCalls: 0,
    averageDuration: 0,
    successRate: 0,
    conversionRate: 0,
    revenue: 0
  });
  const [agentPerformance, setAgentPerformance] = useState<AgentPerformance[]>([]);
  const [realTimeCalls, setRealTimeCalls] = useState<RealTimeCall[]>([]);
  const [alerts, setAlerts] = useState<PerformanceAlert[]>([]);
  const [isLive, setIsLive] = useState(true);
  const [selectedTimeRange, setSelectedTimeRange] = useState<'1h' | '24h' | '7d' | '30d'>('24h');
  const [selectedAgent, setSelectedAgent] = useState<string>('all');

  // Simulate real-time data updates
  useEffect(() => {
    if (!isLive) return;

    const interval = setInterval(() => {
      // Update call metrics
      setCallMetrics(prev => ({
        totalCalls: prev.totalCalls + Math.floor(Math.random() * 3),
        activeCalls: Math.floor(Math.random() * 10) + 1,
        completedCalls: prev.completedCalls + Math.floor(Math.random() * 2),
        averageDuration: Math.floor(Math.random() * 60) + 120,
        successRate: Math.min(0.95, prev.successRate + (Math.random() - 0.5) * 0.02),
        conversionRate: Math.min(0.25, prev.conversionRate + (Math.random() - 0.5) * 0.01),
        revenue: prev.revenue + Math.floor(Math.random() * 500)
      }));

      // Update real-time calls
      setRealTimeCalls(prev => {
        const newCalls = prev.map(call => ({
          ...call,
          duration: call.duration + 1,
          confidence: Math.min(1, call.confidence + (Math.random() - 0.5) * 0.1)
        }));

        // Add new calls occasionally
        if (Math.random() < 0.1) {
          const newCall: RealTimeCall = {
            id: `call_${Date.now()}`,
            agentId: `agent_${Math.floor(Math.random() * 5) + 1}`,
            agentName: `Agent ${Math.floor(Math.random() * 5) + 1}`,
            contactName: `Contact ${Math.floor(Math.random() * 100) + 1}`,
            contactPhone: `+1-555-${Math.floor(Math.random() * 9000) + 1000}`,
            status: 'ringing',
            duration: 0,
            intent: ['appointment_booking', 'information_request', 'complaint', 'support'][Math.floor(Math.random() * 4)],
            confidence: Math.random() * 0.4 + 0.6,
            location: ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix'][Math.floor(Math.random() * 5)],
            startTime: new Date().toISOString()
          };
          newCalls.push(newCall);
        }

        // Remove completed calls
        return newCalls.filter(call => call.duration < 300);
      });

      // Generate alerts occasionally
      if (Math.random() < 0.05) {
        const alertTypes = ['success_rate', 'call_volume', 'response_time', 'revenue'];
        const severities = ['low', 'medium', 'high', 'critical'];
        const newAlert: PerformanceAlert = {
          id: `alert_${Date.now()}`,
          type: alertTypes[Math.floor(Math.random() * alertTypes.length)] as any,
          severity: severities[Math.floor(Math.random() * severities.length)] as any,
          message: `Performance alert: ${alertTypes[Math.floor(Math.random() * alertTypes.length)]} threshold exceeded`,
          timestamp: new Date().toISOString(),
          resolved: false
        };
        setAlerts(prev => [newAlert, ...prev.slice(0, 9)]);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [isLive]);

  // Initialize sample data
  useEffect(() => {
    setCallMetrics({
      totalCalls: 1247,
      activeCalls: 8,
      completedCalls: 1239,
      averageDuration: 187,
      successRate: 0.87,
      conversionRate: 0.23,
      revenue: 45600
    });

    setAgentPerformance([
      {
        id: 'agent_1',
        name: 'F45 Fitness Agent',
        callsHandled: 156,
        successRate: 0.92,
        averageDuration: 203,
        conversionRate: 0.28,
        revenue: 8900,
        status: 'online',
        lastActivity: '2024-01-15T12:30:00Z'
      },
      {
        id: 'agent_2',
        name: 'Legal Consultation Agent',
        callsHandled: 89,
        successRate: 0.85,
        averageDuration: 245,
        conversionRate: 0.19,
        revenue: 12400,
        status: 'busy',
        lastActivity: '2024-01-15T12:28:00Z'
      },
      {
        id: 'agent_3',
        name: 'Plumbing Emergency Agent',
        callsHandled: 203,
        successRate: 0.94,
        averageDuration: 156,
        conversionRate: 0.31,
        revenue: 15200,
        status: 'online',
        lastActivity: '2024-01-15T12:32:00Z'
      },
      {
        id: 'agent_4',
        name: 'Martial Arts Agent',
        callsHandled: 78,
        successRate: 0.88,
        averageDuration: 189,
        conversionRate: 0.24,
        revenue: 6100,
        status: 'offline',
        lastActivity: '2024-01-15T11:45:00Z'
      },
      {
        id: 'agent_5',
        name: 'Construction Agent',
        callsHandled: 112,
        successRate: 0.81,
        averageDuration: 267,
        conversionRate: 0.16,
        revenue: 3000,
        status: 'online',
        lastActivity: '2024-01-15T12:25:00Z'
      }
    ]);

    setRealTimeCalls([
      {
        id: 'call_1',
        agentId: 'agent_1',
        agentName: 'F45 Fitness Agent',
        contactName: 'Sarah Johnson',
        contactPhone: '+1-555-0123',
        status: 'connected',
        duration: 45,
        intent: 'appointment_booking',
        confidence: 0.87,
        location: 'New York',
        startTime: '2024-01-15T12:15:00Z'
      },
      {
        id: 'call_2',
        agentId: 'agent_3',
        agentName: 'Plumbing Emergency Agent',
        contactName: 'Mike Chen',
        contactPhone: '+1-555-0456',
        status: 'connected',
        duration: 23,
        intent: 'emergency_service',
        confidence: 0.95,
        location: 'Los Angeles',
        startTime: '2024-01-15T12:20:00Z'
      }
    ]);

    setAlerts([
      {
        id: 'alert_1',
        type: 'success_rate',
        severity: 'medium',
        message: 'Agent 5 success rate dropped below 85%',
        timestamp: '2024-01-15T12:00:00Z',
        resolved: false
      },
      {
        id: 'alert_2',
        type: 'call_volume',
        severity: 'high',
        message: 'Call volume increased by 40% in the last hour',
        timestamp: '2024-01-15T11:45:00Z',
        resolved: false
      }
    ]);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'text-green-400';
      case 'busy': return 'text-yellow-400';
      case 'offline': return 'text-gray-400';
      case 'connected': return 'text-green-400';
      case 'ringing': return 'text-blue-400';
      case 'on_hold': return 'text-yellow-400';
      case 'transferred': return 'text-purple-400';
      case 'completed': return 'text-gray-400';
      default: return 'text-gray-400';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low': return 'text-blue-400 bg-blue-100';
      case 'medium': return 'text-yellow-400 bg-yellow-100';
      case 'high': return 'text-orange-400 bg-orange-100';
      case 'critical': return 'text-red-400 bg-red-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="p-6 bg-background min-h-screen text-foreground">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Real-Time Monitoring</h1>
            <p className="text-muted-foreground">
              Live monitoring of voice AI agents, call performance, and system health
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className={`w-3 h-3 rounded-full ${isLive ? 'bg-green-400 animate-pulse' : 'bg-gray-400'}`}></div>
              <span className="text-sm text-muted-foreground">
                {isLive ? 'Live' : 'Paused'}
              </span>
            </div>
            <button
              onClick={() => setIsLive(!isLive)}
              className={`btn ${isLive ? 'btn-secondary' : 'btn-primary'}`}
            >
              {isLive ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
              {isLive ? 'Pause' : 'Resume'}
            </button>
            <button className="btn btn-outline">
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </button>
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Calls</p>
              <p className="text-2xl font-bold text-foreground">{callMetrics.totalCalls.toLocaleString()}</p>
              <div className="flex items-center mt-1">
                <TrendingUp className="w-4 h-4 text-green-400 mr-1" />
                <span className="text-sm text-green-400">+12%</span>
              </div>
            </div>
            <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
              <Phone className="w-6 h-6 text-primary" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Active Calls</p>
              <p className="text-2xl font-bold text-foreground">{callMetrics.activeCalls}</p>
              <div className="flex items-center mt-1">
                <Activity className="w-4 h-4 text-blue-400 mr-1" />
                <span className="text-sm text-blue-400">Live</span>
              </div>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <Activity className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Success Rate</p>
              <p className="text-2xl font-bold text-foreground">{Math.round(callMetrics.successRate * 100)}%</p>
              <div className="flex items-center mt-1">
                <TrendingUp className="w-4 h-4 text-green-400 mr-1" />
                <span className="text-sm text-green-400">+2.3%</span>
              </div>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Revenue</p>
              <p className="text-2xl font-bold text-foreground">${callMetrics.revenue.toLocaleString()}</p>
              <div className="flex items-center mt-1">
                <TrendingUp className="w-4 h-4 text-green-400 mr-1" />
                <span className="text-sm text-green-400">+8.5%</span>
              </div>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Real-Time Calls */}
        <div className="lg:col-span-2">
          <div className="card p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-foreground">Live Calls</h2>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-sm text-muted-foreground">{realTimeCalls.length} active</span>
              </div>
            </div>
            <div className="space-y-3">
              {realTimeCalls.map((call) => (
                <div key={call.id} className="flex items-center justify-between p-4 bg-secondary rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className={`w-3 h-3 rounded-full ${getStatusColor(call.status)}`}></div>
                    <div>
                      <p className="font-medium text-foreground">{call.contactName}</p>
                      <p className="text-sm text-muted-foreground">{call.contactPhone}</p>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      <div className="flex items-center space-x-1">
                        <MapPin className="w-4 h-4" />
                        <span>{call.location}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-foreground">{call.agentName}</p>
                    <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                      <span>{formatDuration(call.duration)}</span>
                      <span className="capitalize">{call.intent.replace('_', ' ')}</span>
                      <span>{Math.round(call.confidence * 100)}%</span>
                    </div>
                  </div>
                </div>
              ))}
              {realTimeCalls.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  <Phone className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No active calls</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Alerts */}
        <div>
          <div className="card p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-foreground">Alerts</h2>
              <div className="flex items-center space-x-2">
                <AlertTriangle className="w-4 h-4 text-yellow-400" />
                <span className="text-sm text-muted-foreground">{alerts.filter(a => !a.resolved).length} active</span>
              </div>
            </div>
            <div className="space-y-3">
              {alerts.map((alert) => (
                <div key={alert.id} className={`p-3 rounded-lg ${getSeverityColor(alert.severity)}`}>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <p className="text-sm font-medium">{alert.message}</p>
                      <p className="text-xs opacity-75 mt-1">
                        {new Date(alert.timestamp).toLocaleTimeString()}
                      </p>
                    </div>
                    {!alert.resolved && (
                      <button className="text-xs px-2 py-1 bg-white/20 rounded">
                        Resolve
                      </button>
                    )}
                  </div>
                </div>
              ))}
              {alerts.length === 0 && (
                <div className="text-center py-4 text-muted-foreground">
                  <CheckCircle className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No alerts</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Agent Performance */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-foreground">Agent Performance</h2>
          <div className="flex items-center space-x-2">
            <select
              className="input"
              value={selectedAgent}
              onChange={(e) => setSelectedAgent(e.target.value)}
            >
              <option value="all">All Agents</option>
              {agentPerformance.map(agent => (
                <option key={agent.id} value={agent.id}>{agent.name}</option>
              ))}
            </select>
            <button className="btn btn-outline">
              <Download className="w-4 h-4 mr-2" />
              Export
            </button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">Agent</th>
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">Status</th>
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">Calls</th>
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">Success Rate</th>
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">Avg Duration</th>
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">Conversion</th>
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">Revenue</th>
              </tr>
            </thead>
            <tbody>
              {agentPerformance.map((agent) => (
                <tr key={agent.id} className="border-b border-border hover:bg-secondary/50">
                  <td className="py-3 px-4">
                    <div>
                      <p className="font-medium text-foreground">{agent.name}</p>
                      <p className="text-sm text-muted-foreground">
                        Last: {new Date(agent.lastActivity).toLocaleTimeString()}
                      </p>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center space-x-2">
                      <div className={`w-2 h-2 rounded-full ${getStatusColor(agent.status)}`}></div>
                      <span className="text-sm capitalize">{agent.status}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-foreground">{agent.callsHandled}</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center space-x-2">
                      <span className="text-foreground">{Math.round(agent.successRate * 100)}%</span>
                      <div className="w-16 bg-muted rounded-full h-2">
                        <div 
                          className="bg-primary h-2 rounded-full" 
                          style={{ width: `${agent.successRate * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-foreground">{formatDuration(agent.averageDuration)}</td>
                  <td className="py-3 px-4 text-foreground">{Math.round(agent.conversionRate * 100)}%</td>
                  <td className="py-3 px-4 text-foreground">${agent.revenue.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default RealTimeMonitoring;
