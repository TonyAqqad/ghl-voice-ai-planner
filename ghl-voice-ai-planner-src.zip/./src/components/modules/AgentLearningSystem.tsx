import React, { useState, useEffect } from 'react';
import { Brain, GraduationCap, Target, TrendingUp, RefreshCw, Play, Pause, Settings, BarChart3, Lightbulb, Zap, CheckCircle, AlertTriangle } from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';
import { v4 as uuidv4 } from 'uuid';

interface LearningSession {
  id: string;
  agentId: string;
  sessionType: 'conversation_analysis' | 'performance_optimization' | 'script_improvement' | 'intent_recognition';
  status: 'active' | 'completed' | 'paused' | 'failed';
  startTime: string;
  endTime: string | null;
  duration: number | null;
  improvements: string[];
  metrics: {
    beforeScore: number;
    afterScore: number;
    improvement: number;
  };
  dataProcessed: number;
  insightsGenerated: number;
}

interface LearningInsight {
  id: string;
  agentId: string;
  category: 'performance' | 'conversation' | 'script' | 'intent' | 'compliance';
  title: string;
  description: string;
  impact: 'low' | 'medium' | 'high' | 'critical';
  confidence: number;
  recommendations: string[];
  implementation: {
    difficulty: 'easy' | 'medium' | 'hard';
    timeRequired: number; // in minutes
    automated: boolean;
  };
  status: 'new' | 'implemented' | 'testing' | 'rejected';
  createdAt: string;
}

interface AgentLearningProfile {
  agentId: string;
  learningLevel: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  totalSessions: number;
  totalImprovements: number;
  averageImprovement: number;
  learningStrengths: string[];
  learningAreas: string[];
  lastLearningSession: string | null;
  nextRecommendedSession: string | null;
  adaptiveCapabilities: {
    scriptOptimization: boolean;
    intentRecognition: boolean;
    conversationFlow: boolean;
    performanceTuning: boolean;
  };
}

const AgentLearningSystem: React.FC = () => {
  const { voiceAgents } = useStore();
  const [learningSessions, setLearningSessions] = useState<LearningSession[]>([]);
  const [learningInsights, setLearningInsights] = useState<LearningInsight[]>([]);
  const [agentProfiles, setAgentProfiles] = useState<AgentLearningProfile[]>([]);
  const [selectedAgentId, setSelectedAgentId] = useState<string>('');
  const [isLearning, setIsLearning] = useState(false);
  const [selectedSessionType, setSelectedSessionType] = useState<LearningSession['sessionType']>('conversation_analysis');

  useEffect(() => {
    // Mock data for learning sessions
    const mockSessions: LearningSession[] = [
      {
        id: uuidv4(),
        agentId: voiceAgents[0]?.id || '',
        sessionType: 'conversation_analysis',
        status: 'completed',
        startTime: '2023-10-26T16:00:00Z',
        endTime: '2023-10-26T16:45:00Z',
        duration: 45,
        improvements: [
          'Improved response time by 23%',
          'Enhanced customer satisfaction scoring',
          'Better intent recognition accuracy'
        ],
        metrics: {
          beforeScore: 7.2,
          afterScore: 8.8,
          improvement: 22.2
        },
        dataProcessed: 1250,
        insightsGenerated: 8
      },
      {
        id: uuidv4(),
        agentId: voiceAgents[1]?.id || '',
        sessionType: 'script_improvement',
        status: 'active',
        startTime: '2023-10-26T17:30:00Z',
        endTime: null,
        duration: null,
        improvements: [],
        metrics: {
          beforeScore: 6.8,
          afterScore: 0,
          improvement: 0
        },
        dataProcessed: 890,
        insightsGenerated: 0
      }
    ];

    const mockInsights: LearningInsight[] = [
      {
        id: uuidv4(),
        agentId: voiceAgents[0]?.id || '',
        category: 'performance',
        title: 'Response Time Optimization',
        description: 'Agent shows 15% slower response times during peak hours. Implementing dynamic scaling could improve performance.',
        impact: 'high',
        confidence: 0.87,
        recommendations: [
          'Implement dynamic resource allocation',
          'Add response time monitoring',
          'Optimize conversation flow logic'
        ],
        implementation: {
          difficulty: 'medium',
          timeRequired: 30,
          automated: true
        },
        status: 'new',
        createdAt: '2023-10-26T16:45:00Z'
      },
      {
        id: uuidv4(),
        agentId: voiceAgents[0]?.id || '',
        category: 'conversation',
        title: 'Intent Recognition Enhancement',
        description: 'Customer intent recognition accuracy is 78%. Training on recent conversation data could improve to 92%.',
        impact: 'critical',
        confidence: 0.94,
        recommendations: [
          'Retrain intent classification model',
          'Add new intent categories',
          'Implement confidence scoring'
        ],
        implementation: {
          difficulty: 'hard',
          timeRequired: 120,
          automated: false
        },
        status: 'testing',
        createdAt: '2023-10-26T17:00:00Z'
      }
    ];

    const mockProfiles: AgentLearningProfile[] = voiceAgents.map(agent => ({
      agentId: agent.id,
      learningLevel: ['beginner', 'intermediate', 'advanced', 'expert'][Math.floor(Math.random() * 4)] as any,
      totalSessions: Math.floor(Math.random() * 20) + 5,
      totalImprovements: Math.floor(Math.random() * 50) + 10,
      averageImprovement: Math.random() * 30 + 10,
      learningStrengths: ['conversation flow', 'intent recognition', 'script optimization'],
      learningAreas: ['response time', 'customer satisfaction', 'compliance'],
      lastLearningSession: '2023-10-26T16:45:00Z',
      nextRecommendedSession: '2023-10-27T10:00:00Z',
      adaptiveCapabilities: {
        scriptOptimization: true,
        intentRecognition: true,
        conversationFlow: true,
        performanceTuning: false
      }
    }));

    setLearningSessions(mockSessions);
    setLearningInsights(mockInsights);
    setAgentProfiles(mockProfiles);
    setSelectedAgentId(voiceAgents[0]?.id || '');
  }, [voiceAgents]);

  const handleStartLearningSession = async () => {
    if (!selectedAgentId) {
      toast.error('Please select an agent for learning.');
      return;
    }

    setIsLearning(true);
    toast.loading('Starting AI learning session...', { id: 'learning-start' });

    // Simulate learning process
    await new Promise(resolve => setTimeout(resolve, 3000));

    const newSession: LearningSession = {
      id: uuidv4(),
      agentId: selectedAgentId,
      sessionType: selectedSessionType,
      status: 'active',
      startTime: new Date().toISOString(),
      endTime: null,
      duration: null,
      improvements: [],
      metrics: {
        beforeScore: Math.random() * 3 + 6,
        afterScore: 0,
        improvement: 0
      },
      dataProcessed: 0,
      insightsGenerated: 0
    };

    setLearningSessions(prev => [newSession, ...prev]);
    setIsLearning(false);
    toast.success('AI learning session started!', { id: 'learning-start' });
  };

  const handleImplementInsight = (insightId: string) => {
    setLearningInsights(prev => 
      prev.map(insight => 
        insight.id === insightId 
          ? { ...insight, status: 'implemented' as const }
          : insight
      )
    );
    toast.success('Insight implementation started!');
  };

  const getImpactColor = (impact: LearningInsight['impact']) => {
    switch (impact) {
      case 'critical': return 'text-red-600 bg-red-100';
      case 'high': return 'text-orange-600 bg-orange-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-green-600 bg-green-100';
      default: return 'text-muted-foreground bg-gray-100';
    }
  };

  const getStatusColor = (status: LearningSession['status']) => {
    switch (status) {
      case 'active': return 'text-green-500';
      case 'completed': return 'text-blue-500';
      case 'paused': return 'text-yellow-500';
      case 'failed': return 'text-red-500';
      default: return 'text-muted-foreground';
    }
  };

  const getLearningLevelColor = (level: AgentLearningProfile['learningLevel']) => {
    switch (level) {
      case 'expert': return 'text-purple-500';
      case 'advanced': return 'text-blue-500';
      case 'intermediate': return 'text-green-500';
      case 'beginner': return 'text-yellow-500';
      default: return 'text-muted-foreground';
    }
  };

  const selectedAgent = voiceAgents.find(a => a.id === selectedAgentId);
  const selectedProfile = agentProfiles.find(p => p.agentId === selectedAgentId);

  return (
    <div className="p-6 bg-background min-h-screen text-foreground">
      <h1 className="text-3xl font-bold gradient-text mb-6">Intelligent Agent Learning & Adaptation System</h1>
      <p className="text-muted-foreground mb-8">
        Enable your Voice AI agents to continuously learn, adapt, and improve their performance through advanced machine learning and AI-powered optimization.
      </p>

      {/* Learning Controls */}
      <div className="card p-6 mb-8">
        <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
          <Brain className="w-6 h-6 mr-2 text-purple-400" /> Start Learning Session
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div>
            <label htmlFor="select-agent" className="block text-sm font-medium text-muted-foreground mb-1">
              Select Agent
            </label>
            <select
              id="select-agent"
              className="w-full input"
              value={selectedAgentId}
              onChange={(e) => setSelectedAgentId(e.target.value)}
            >
              <option value="">-- Select an Agent --</option>
              {voiceAgents.map(agent => (
                <option key={agent.id} value={agent.id}>{agent.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="session-type" className="block text-sm font-medium text-muted-foreground mb-1">
              Learning Type
            </label>
            <select
              id="session-type"
              className="w-full input"
              value={selectedSessionType}
              onChange={(e) => setSelectedSessionType(e.target.value as LearningSession['sessionType'])}
            >
              <option value="conversation_analysis">Conversation Analysis</option>
              <option value="performance_optimization">Performance Optimization</option>
              <option value="script_improvement">Script Improvement</option>
              <option value="intent_recognition">Intent Recognition</option>
            </select>
          </div>
          <div className="flex items-end">
            <button
              onClick={handleStartLearningSession}
              className="btn btn-primary w-full flex items-center justify-center"
              disabled={isLearning || !selectedAgentId}
            >
              {isLearning ? (
                <>
                  <RefreshCw className="w-5 h-5 mr-2 animate-spin" /> Learning...
                </>
              ) : (
                <>
                  <Play className="w-5 h-5 mr-2" /> Start Learning
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Agent Learning Profile */}
      {selectedProfile && (
        <div className="card p-6 mb-8">
          <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
            <GraduationCap className="w-6 h-6 mr-2 text-blue-400" /> Agent Learning Profile: {selectedAgent?.name}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Learning Level</p>
              <p className={`text-lg font-semibold ${getLearningLevelColor(selectedProfile.learningLevel)}`}>
                {selectedProfile.learningLevel.charAt(0).toUpperCase() + selectedProfile.learningLevel.slice(1)}
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground mb-1">Total Sessions</p>
              <p className="text-lg font-semibold text-foreground">{selectedProfile.totalSessions}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground mb-1">Improvements</p>
              <p className="text-lg font-semibold text-foreground">{selectedProfile.totalImprovements}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground mb-1">Avg Improvement</p>
              <p className="text-lg font-semibold text-foreground">{selectedProfile.averageImprovement.toFixed(1)}%</p>
            </div>
          </div>
          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-medium text-foreground mb-2">Learning Strengths</h3>
              <div className="flex flex-wrap gap-2">
                {selectedProfile.learningStrengths.map((strength, index) => (
                  <span key={index} className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                    {strength}
                  </span>
                ))}
              </div>
            </div>
            <div>
              <h3 className="font-medium text-foreground mb-2">Areas for Improvement</h3>
              <div className="flex flex-wrap gap-2">
                {selectedProfile.learningAreas.map((area, index) => (
                  <span key={index} className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm">
                    {area}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Learning Sessions */}
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
            <Target className="w-6 h-6 mr-2 text-green-400" /> Learning Sessions
          </h2>
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {learningSessions.map((session) => (
              <div key={session.id} className="bg-secondary p-4 rounded-lg border border-border">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-medium text-foreground">
                      {session.sessionType.replace('_', ' ').replace(/\b\w/g, char => char.toUpperCase())}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      Agent: {voiceAgents.find(a => a.id === session.agentId)?.name || 'Unknown'}
                    </p>
                  </div>
                  <span className={`text-sm font-medium ${getStatusColor(session.status)}`}>
                    {session.status.charAt(0).toUpperCase() + session.status.slice(1)}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground mb-3">
                  <div>Started: {new Date(session.startTime).toLocaleTimeString()}</div>
                  <div>Duration: {session.duration ? `${session.duration}m` : 'Ongoing'}</div>
                  <div>Data Processed: {session.dataProcessed.toLocaleString()}</div>
                  <div>Insights: {session.insightsGenerated}</div>
                </div>
                {session.metrics.improvement > 0 && (
                  <div className="mb-3">
                    <p className="text-sm text-foreground mb-1">Performance Improvement:</p>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-muted-foreground">
                        {session.metrics.beforeScore.toFixed(1)} → {session.metrics.afterScore.toFixed(1)}
                      </span>
                      <span className="text-sm font-medium text-green-500">
                        +{session.metrics.improvement.toFixed(1)}%
                      </span>
                    </div>
                  </div>
                )}
                {session.improvements.length > 0 && (
                  <div>
                    <p className="text-sm text-foreground mb-1">Key Improvements:</p>
                    <ul className="text-xs text-muted-foreground list-disc list-inside">
                      {session.improvements.map((improvement, index) => (
                        <li key={index}>{improvement}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Learning Insights */}
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
            <Lightbulb className="w-6 h-6 mr-2 text-yellow-400" /> AI-Generated Insights
          </h2>
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {learningInsights.map((insight) => (
              <div key={insight.id} className="bg-secondary p-4 rounded-lg border border-border">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-medium text-foreground">{insight.title}</h3>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getImpactColor(insight.impact)}`}>
                    {insight.impact}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground mb-3">{insight.description}</p>
                <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground mb-3">
                  <div>Category: {insight.category}</div>
                  <div>Confidence: {(insight.confidence * 100).toFixed(1)}%</div>
                  <div>Difficulty: {insight.implementation.difficulty}</div>
                  <div>Time: {insight.implementation.timeRequired}m</div>
                </div>
                <div className="mb-3">
                  <p className="text-sm text-foreground mb-1">Recommendations:</p>
                  <ul className="text-xs text-muted-foreground list-disc list-inside">
                    {insight.recommendations.map((rec, index) => (
                      <li key={index}>{rec}</li>
                    ))}
                  </ul>
                </div>
                <div className="flex justify-between items-center">
                  <span className={`text-xs font-medium ${
                    insight.status === 'implemented' ? 'text-green-500' :
                    insight.status === 'testing' ? 'text-yellow-500' :
                    insight.status === 'rejected' ? 'text-red-500' : 'text-blue-500'
                  }`}>
                    {insight.status.charAt(0).toUpperCase() + insight.status.slice(1)}
                  </span>
                  {insight.status === 'new' && (
                    <button
                      onClick={() => handleImplementInsight(insight.id)}
                      className="btn btn-sm btn-primary"
                    >
                      <CheckCircle className="w-4 h-4 mr-1" /> Implement
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AgentLearningSystem;
