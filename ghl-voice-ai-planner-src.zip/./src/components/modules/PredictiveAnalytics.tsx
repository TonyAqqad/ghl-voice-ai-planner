import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  BarChart3, 
  LineChart, 
  PieChart, 
  Target, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  RefreshCw, 
  Play, 
  Pause, 
  Settings, 
  Download, 
  Upload, 
  Save, 
  Edit, 
  Trash2, 
  Plus, 
  Minus, 
  ChevronDown, 
  ChevronRight, 
  Eye, 
  EyeOff, 
  Filter, 
  Search, 
  SortAsc, 
  SortDesc, 
  MoreHorizontal, 
  Star, 
  ThumbsUp, 
  ThumbsDown, 
  Heart, 
  Smile, 
  Frown, 
  Meh, 
  Award, 
  Trophy, 
  Medal, 
  Crown, 
  Flame, 
  Lightning, 
  Rocket, 
  Shield, 
  Lock, 
  Unlock, 
  Key, 
  Wrench, 
  Cog, 
  Sliders, 
  ToggleLeft, 
  ToggleRight, 
  Switch, 
  Power, 
  PowerOff, 
  Battery, 
  BatteryCharging, 
  Wifi, 
  WifiOff, 
  Signal, 
  SignalZero, 
  SignalOne, 
  SignalTwo, 
  SignalThree, 
  SignalFour, 
  SignalFive,
  MessageSquare,
  Mic,
  Headphones,
  Volume2,
  VolumeX,
  SkipForward,
  SkipBack,
  RotateCcw,
  Activity,
  Clock,
  Users,
  Phone,
  Bot,
  Brain,
  Database,
  Server,
  Globe,
  FileText,
  FileCheck,
  FileX,
  FileAlert,
  FileLock,
  FileShield,
  FileSearch,
  FileCode,
  FileImage,
  FileVideo,
  FileAudio,
  FileArchive,
  FileSpreadsheet,
  FilePresentation,
  FilePdf,
  FileWord,
  FileExcel,
  FilePowerpoint,
  FileZip,
  FileRar,
  File7z,
  FileTar,
  FileGz,
  FileBz2,
  FileXz,
  FileLz4,
  FileZstd,
  FileCab,
  FileIso,
  FileDmg,
  FileImg,
  FileVhd,
  FileVdi,
  FileVmdk,
  FileOva,
  FileOvf,
  FileVagrant,
  FileDocker,
  FileKubernetes,
  FileTerraform,
  FileAnsible,
  FileChef,
  FilePuppet,
  FileSalt,
  FileConsul,
  FileVault,
  FileNomad,
  FileDockerCompose,
  FileKustomize,
  FileHelm,
  FileIstio,
  FileLinkerd,
  FileEnvoy,
  FileNginx,
  FileApache,
  FileIis,
  FileTomcat,
  FileJetty,
  FileWildfly,
  FileWeblogic,
  FileWebsphere,
  FileGlassfish,
  FileJboss,
  FileResin,
  FileGeronimo,
  FileOpenliberty,
  FilePayara,
  FileTomee,
  FileWeld,
  FileDeltaspike,
  FileShiro,
  FileSpring,
  FileHibernate,
  FileMybatis,
  FileJpa,
  FileJdbc,
  FileJndi,
  FileJms,
  FileJta,
  FileJca,
  FileJaxb,
  FileJaxrs,
  FileJaxws,
  FileJsf,
  FileStruts,
  FileVaadin,
  FileGwt,
  FileWicket,
  FileTapestry,
  FileSeam,
  FileRichfaces,
  FilePrimefaces,
  FileIcefaces,
  FileOpenfaces,
  FileButterfaces,
  FileBootsfaces,
  FileOmnifaces,
  FileAngularfaces,
  FileAngular,
  FileReact,
  FileVue,
  FileSvelte,
  FileEmber,
  FileBackbone,
  FileKnockout,
  FileMithril,
  FilePreact,
  FileInferno,
  FileRiot,
  FileStencil,
  FileLit,
  FilePolymer,
  FileAurelia,
  FileMithril,
  FileHyperapp,
  FileAlpine,
  FileStimulus,
  FileTurbo,
  FileHotwire,
  FileLivewire,
  FileInertia,
  FileNext,
  FileNuxt,
  FileSapper,
  FileSveltekit,
  FileRemix,
  FileSolid,
  FileQwik,
  FileMarko,
  FileMithril,
  FileHyperapp,
  FileAlpine,
  FileStimulus,
  FileTurbo,
  FileHotwire,
  FileLivewire,
  FileInertia,
  FileNext,
  FileNuxt,
  FileSapper,
  FileSveltekit,
  FileRemix,
  FileSolid,
  FileQwik,
  FileMarko,
  Info,
  ExternalLink,
  Copy,
  Link,
  Unlink,
  Send,
  Receive,
  ArrowRight,
  ArrowLeft,
  ArrowUp,
  ArrowDown,
  RotateCw,
  RotateCcw,
  Move,
  MoveUp,
  MoveDown,
  MoveLeft,
  MoveRight,
  Maximize,
  Minimize,
  Maximize2,
  Minimize2,
  Square,
  Circle,
  Triangle,
  Hexagon,
  Octagon,
  Pentagon,
  Diamond,
  RectangleHorizontal,
  RectangleVertical,
  Ellipse,
  Oval,
  Parallelogram,
  Trapezoid,
  Rhombus,
  Kite,
  Star as StarIcon,
  Heart as HeartIcon,
  Smile as SmileIcon,
  Frown as FrownIcon,
  Meh as MehIcon,
  ThumbsUp as ThumbsUpIcon,
  ThumbsDown as ThumbsDownIcon,
  Award as AwardIcon,
  Trophy as TrophyIcon,
  Medal as MedalIcon,
  Crown as CrownIcon,
  Flame as FlameIcon,
  Lightning as LightningIcon,
  Rocket as RocketIcon,
  Shield as ShieldIcon,
  Lock as LockIcon,
  Unlock as UnlockIcon,
  Key as KeyIcon,
  Wrench as WrenchIcon,
  Cog as CogIcon,
  Sliders as SlidersIcon,
  ToggleLeft as ToggleLeftIcon,
  ToggleRight as ToggleRightIcon,
  Switch as SwitchIcon,
  Power as PowerIcon,
  PowerOff as PowerOffIcon,
  Battery as BatteryIcon,
  BatteryCharging as BatteryChargingIcon,
  Wifi as WifiIcon,
  WifiOff as WifiOffIcon,
  Signal as SignalIcon,
  SignalZero as SignalZeroIcon,
  SignalOne as SignalOneIcon,
  SignalTwo as SignalTwoIcon,
  SignalThree as SignalThreeIcon,
  SignalFour as SignalFourIcon,
  SignalFive as SignalFiveIcon,
  MessageSquare as MessageSquareIcon,
  Mic as MicIcon,
  Headphones as HeadphonesIcon,
  Volume2 as Volume2Icon,
  VolumeX as VolumeXIcon,
  Play as PlayIcon,
  Pause as PauseIcon,
  SkipForward as SkipForwardIcon,
  SkipBack as SkipBackIcon,
  RotateCcw as RotateCcwIcon,
  BarChart3 as BarChart3Icon,
  LineChart as LineChartIcon,
  PieChart as PieChartIcon,
  Activity as ActivityIcon,
  Clock as ClockIcon,
  Phone as PhoneIcon,
  Bot as BotIcon,
  Brain as BrainIcon,
  Target as TargetIcon,
  TrendingDown,
  Database as DatabaseIcon,
  Server as ServerIcon,
  Globe as GlobeIcon,
  FileText as FileTextIcon,
  FileCheck as FileCheckIcon,
  FileX as FileXIcon,
  FileAlert as FileAlertIcon,
  FileLock as FileLockIcon,
  FileShield as FileShieldIcon,
  FileSearch as FileSearchIcon,
  FileCode as FileCodeIcon,
  FileImage as FileImageIcon,
  FileVideo as FileVideoIcon,
  FileAudio as FileAudioIcon,
  FileArchive as FileArchiveIcon,
  FileSpreadsheet as FileSpreadsheetIcon,
  FilePresentation as FilePresentationIcon,
  FilePdf as FilePdfIcon,
  FileWord as FileWordIcon,
  FileExcel as FileExcelIcon,
  FilePowerpoint as FilePowerpointIcon,
  FileZip as FileZipIcon,
  FileRar as FileRarIcon,
  File7z as File7zIcon,
  FileTar as FileTarIcon,
  FileGz as FileGzIcon,
  FileBz2 as FileBz2Icon,
  FileXz as FileXzIcon,
  FileLz4 as FileLz4Icon,
  FileZstd as FileZstdIcon,
  FileCab as FileCabIcon,
  FileIso as FileIsoIcon,
  FileDmg as FileDmgIcon,
  FileImg as FileImgIcon,
  FileVhd as FileVhdIcon,
  FileVdi as FileVdiIcon,
  FileVmdk as FileVmdkIcon,
  FileOva as FileOvaIcon,
  FileOvf as FileOvfIcon,
  FileVagrant as FileVagrantIcon,
  FileDocker as FileDockerIcon,
  FileKubernetes as FileKubernetesIcon,
  FileTerraform as FileTerraformIcon,
  FileAnsible as FileAnsibleIcon,
  FileChef as FileChefIcon,
  FilePuppet as FilePuppetIcon,
  FileSalt as FileSaltIcon,
  FileConsul as FileConsulIcon,
  FileVault as FileVaultIcon,
  FileNomad as FileNomadIcon,
  FileDockerCompose as FileDockerComposeIcon,
  FileKustomize as FileKustomizeIcon,
  FileHelm as FileHelmIcon,
  FileIstio as FileIstioIcon,
  FileLinkerd as FileLinkerdIcon,
  FileEnvoy as FileEnvoyIcon,
  FileNginx as FileNginxIcon,
  FileApache as FileApacheIcon,
  FileIis as FileIisIcon,
  FileTomcat as FileTomcatIcon,
  FileJetty as FileJettyIcon,
  FileWildfly as FileWildflyIcon,
  FileWeblogic as FileWeblogicIcon,
  FileWebsphere as FileWebsphereIcon,
  FileGlassfish as FileGlassfishIcon,
  FileJboss as FileJbossIcon,
  FileResin as FileResinIcon,
  FileGeronimo as FileGeronimoIcon,
  FileOpenliberty as FileOpenlibertyIcon,
  FilePayara as FilePayaraIcon,
  FileTomee as FileTomeeIcon,
  FileWeld as FileWeldIcon,
  FileDeltaspike as FileDeltaspikeIcon,
  FileShiro as FileShiroIcon,
  FileSpring as FileSpringIcon,
  FileHibernate as FileHibernateIcon,
  FileMybatis as FileMybatisIcon,
  FileJpa as FileJpaIcon,
  FileJdbc as FileJdbcIcon,
  FileJndi as FileJndiIcon,
  FileJms as FileJmsIcon,
  FileJta as FileJtaIcon,
  FileJca as FileJcaIcon,
  FileJaxb as FileJaxbIcon,
  FileJaxrs as FileJaxrsIcon,
  FileJaxws as FileJaxwsIcon,
  FileJsf as FileJsfIcon,
  FileStruts as FileStrutsIcon,
  FileVaadin as FileVaadinIcon,
  FileGwt as FileGwtIcon,
  FileWicket as FileWicketIcon,
  FileTapestry as FileTapestryIcon,
  FileSeam as FileSeamIcon,
  FileRichfaces as FileRichfacesIcon,
  FilePrimefaces as FilePrimefacesIcon,
  FileIcefaces as FileIcefacesIcon,
  FileOpenfaces as FileOpenfacesIcon,
  FileButterfaces as FileButterfacesIcon,
  FileBootsfaces as FileBootsfacesIcon,
  FileOmnifaces as FileOmnifacesIcon,
  FileAngularfaces as FileAngularfacesIcon,
  FileAngular as FileAngularIcon,
  FileReact as FileReactIcon,
  FileVue as FileVueIcon,
  FileSvelte as FileSvelteIcon,
  FileEmber as FileEmberIcon,
  FileBackbone as FileBackboneIcon,
  FileKnockout as FileKnockoutIcon,
  FileMithril as FileMithrilIcon,
  FilePreact as FilePreactIcon,
  FileInferno as FileInfernoIcon,
  FileRiot as FileRiotIcon,
  FileStencil as FileStencilIcon,
  FileLit as FileLitIcon,
  FilePolymer as FilePolymerIcon,
  FileAurelia as FileAureliaIcon,
  FileMithril as FileMithrilIcon,
  FileHyperapp as FileHyperappIcon,
  FileAlpine as FileAlpineIcon,
  FileStimulus as FileStimulusIcon,
  FileTurbo as FileTurboIcon,
  FileHotwire as FileHotwireIcon,
  FileLivewire as FileLivewireIcon,
  FileInertia as FileInertiaIcon,
  FileNext as FileNextIcon,
  FileNuxt as FileNuxtIcon,
  FileSapper as FileSapperIcon,
  FileSveltekit as FileSveltekitIcon,
  FileRemix as FileRemixIcon,
  FileSolid as FileSolidIcon,
  FileQwik as FileQwikIcon,
  FileMarko as FileMarkoIcon,
  FileMithril as FileMithrilIcon,
  FileHyperapp as FileHyperappIcon,
  FileAlpine as FileAlpineIcon,
  FileStimulus as FileStimulusIcon,
  FileTurbo as FileTurboIcon,
  FileHotwire as FileHotwireIcon,
  FileLivewire as FileLivewireIcon,
  FileInertia as FileInertiaIcon,
  FileNext as FileNextIcon,
  FileNuxt as FileNuxtIcon,
  FileSapper as FileSapperIcon,
  FileSveltekit as FileSveltekitIcon,
  FileRemix as FileRemixIcon,
  FileSolid as FileSolidIcon,
  FileQwik as FileQwikIcon,
  FileMarko as FileMarkoIcon
} from 'lucide-react';
import { useStore } from '../../store/useStore';
import { toast } from 'react-hot-toast';

interface Forecast {
  id: string;
  name: string;
  description: string;
  metric: string;
  timeframe: '7d' | '30d' | '90d' | '1y';
  confidence: number;
  currentValue: number;
  predictedValue: number;
  change: number;
  changePercent: number;
  trend: 'up' | 'down' | 'stable';
  dataPoints: Array<{
    date: string;
    actual: number;
    predicted: number;
    confidence: number;
  }>;
  factors: Array<{
    name: string;
    impact: 'high' | 'medium' | 'low';
    description: string;
    weight: number;
  }>;
  recommendations: Array<{
    action: string;
    impact: 'high' | 'medium' | 'low';
    timeframe: string;
    description: string;
  }>;
  createdAt: string;
  updatedAt: string;
}

interface PredictionInsight {
  id: string;
  type: 'trend' | 'anomaly' | 'opportunity' | 'risk';
  title: string;
  description: string;
  confidence: number;
  impact: 'high' | 'medium' | 'low';
  timeframe: string;
  affectedMetrics: string[];
  recommendations: string[];
  createdAt: string;
}

interface ScenarioAnalysis {
  id: string;
  name: string;
  description: string;
  scenario: 'optimistic' | 'realistic' | 'pessimistic';
  probability: number;
  outcomes: {
    metric: string;
    currentValue: number;
    predictedValue: number;
    change: number;
  }[];
  assumptions: string[];
  createdAt: string;
}

const PredictiveAnalytics: React.FC = () => {
  const { darkMode } = useStore();
  const [forecasts, setForecasts] = useState<Forecast[]>([]);
  const [insights, setInsights] = useState<PredictionInsight[]>([]);
  const [scenarios, setScenarios] = useState<ScenarioAnalysis[]>([]);
  const [selectedTimeframe, setSelectedTimeframe] = useState<'7d' | '30d' | '90d' | '1y'>('30d');
  const [selectedMetric, setSelectedMetric] = useState<string>('all');
  const [activeTab, setActiveTab] = useState<'overview' | 'forecasts' | 'insights' | 'scenarios' | 'models'>('overview');

  // Sample data
  useEffect(() => {
    const sampleForecasts: Forecast[] = [
      {
        id: 'forecast_1',
        name: 'Conversion Rate Forecast',
        description: 'Predicted conversion rate for F45 trial booking agent',
        metric: 'Conversion Rate',
        timeframe: '30d',
        confidence: 0.87,
        currentValue: 0.215,
        predictedValue: 0.248,
        change: 0.033,
        changePercent: 15.3,
        trend: 'up',
        dataPoints: [
          { date: '2024-01-01', actual: 0.18, predicted: 0.19, confidence: 0.85 },
          { date: '2024-01-02', actual: 0.22, predicted: 0.20, confidence: 0.87 },
          { date: '2024-01-03', actual: 0.19, predicted: 0.21, confidence: 0.89 },
          { date: '2024-01-04', actual: 0.24, predicted: 0.22, confidence: 0.88 },
          { date: '2024-01-05', actual: 0.21, predicted: 0.23, confidence: 0.86 },
          { date: '2024-01-06', actual: 0.23, predicted: 0.24, confidence: 0.87 },
          { date: '2024-01-07', actual: 0.25, predicted: 0.25, confidence: 0.88 },
          { date: '2024-01-08', actual: 0.22, predicted: 0.26, confidence: 0.89 },
          { date: '2024-01-09', actual: 0.26, predicted: 0.27, confidence: 0.87 },
          { date: '2024-01-10', actual: 0.24, predicted: 0.28, confidence: 0.88 },
          { date: '2024-01-11', actual: 0.27, predicted: 0.29, confidence: 0.86 },
          { date: '2024-01-12', actual: 0.25, predicted: 0.30, confidence: 0.87 },
          { date: '2024-01-13', actual: 0.28, predicted: 0.31, confidence: 0.88 },
          { date: '2024-01-14', actual: 0.26, predicted: 0.32, confidence: 0.89 },
          { date: '2024-01-15', actual: 0.29, predicted: 0.33, confidence: 0.87 }
        ],
        factors: [
          {
            name: 'Seasonal Trends',
            impact: 'high',
            description: 'Fitness industry typically sees 20% increase in January',
            weight: 0.35
          },
          {
            name: 'Agent Optimization',
            impact: 'medium',
            description: 'Recent A/B test improvements showing positive results',
            weight: 0.25
          },
          {
            name: 'Market Competition',
            impact: 'low',
            description: 'New competitors entering the market',
            weight: 0.15
          }
        ],
        recommendations: [
          {
            action: 'Increase marketing budget by 15%',
            impact: 'high',
            timeframe: '2 weeks',
            description: 'Capitalize on seasonal fitness trends'
          },
          {
            action: 'Implement voice optimization',
            impact: 'medium',
            timeframe: '1 month',
            description: 'Apply A/B test learnings to all agents'
          }
        ],
        createdAt: '2024-01-01T00:00:00Z',
        updatedAt: '2024-01-15T14:30:00Z'
      },
      {
        id: 'forecast_2',
        name: 'Cost Per Conversion Forecast',
        description: 'Predicted cost per conversion for legal consultation agent',
        metric: 'Cost Per Conversion',
        timeframe: '30d',
        confidence: 0.92,
        currentValue: 3.85,
        predictedValue: 3.45,
        change: -0.40,
        changePercent: -10.4,
        trend: 'down',
        dataPoints: [
          { date: '2024-01-01', actual: 4.20, predicted: 4.15, confidence: 0.90 },
          { date: '2024-01-02', actual: 4.10, predicted: 4.05, confidence: 0.91 },
          { date: '2024-01-03', actual: 3.95, predicted: 3.95, confidence: 0.92 },
          { date: '2024-01-04', actual: 3.85, predicted: 3.85, confidence: 0.93 },
          { date: '2024-01-05', actual: 3.75, predicted: 3.75, confidence: 0.91 },
          { date: '2024-01-06', actual: 3.65, predicted: 3.65, confidence: 0.92 },
          { date: '2024-01-07', actual: 3.55, predicted: 3.55, confidence: 0.93 },
          { date: '2024-01-08', actual: 3.45, predicted: 3.45, confidence: 0.91 },
          { date: '2024-01-09', actual: 3.35, predicted: 3.35, confidence: 0.92 },
          { date: '2024-01-10', actual: 3.25, predicted: 3.25, confidence: 0.93 },
          { date: '2024-01-11', actual: 3.15, predicted: 3.15, confidence: 0.91 },
          { date: '2024-01-12', actual: 3.05, predicted: 3.05, confidence: 0.92 },
          { date: '2024-01-13', actual: 2.95, predicted: 2.95, confidence: 0.93 },
          { date: '2024-01-14', actual: 2.85, predicted: 2.85, confidence: 0.91 },
          { date: '2024-01-15', actual: 2.75, predicted: 2.75, confidence: 0.92 }
        ],
        factors: [
          {
            name: 'LLM Cost Optimization',
            impact: 'high',
            description: 'Switching to more cost-effective models',
            weight: 0.40
          },
          {
            name: 'Agent Efficiency',
            impact: 'medium',
            description: 'Improved conversation flow reducing call duration',
            weight: 0.30
          },
          {
            name: 'Volume Scaling',
            impact: 'medium',
            description: 'Higher volume leading to better rates',
            weight: 0.20
          }
        ],
        recommendations: [
          {
            action: 'Implement smart model selection',
            impact: 'high',
            timeframe: '1 week',
            description: 'Use GPT-3.5 for simple queries, GPT-4 for complex ones'
          },
          {
            action: 'Optimize conversation flow',
            impact: 'medium',
            timeframe: '2 weeks',
            description: 'Reduce average call duration by 15%'
          }
        ],
        createdAt: '2024-01-01T00:00:00Z',
        updatedAt: '2024-01-15T14:30:00Z'
      }
    ];

    const sampleInsights: PredictionInsight[] = [
      {
        id: 'insight_1',
        type: 'trend',
        title: 'Conversion Rate Trending Up 15%',
        description: 'F45 agent conversion rate is showing strong upward trend with 87% confidence',
        confidence: 0.87,
        impact: 'high',
        timeframe: '30 days',
        affectedMetrics: ['Conversion Rate', 'Revenue', 'ROI'],
        recommendations: [
          'Increase marketing spend to capitalize on trend',
          'Scale successful agent configurations',
          'Monitor for trend continuation'
        ],
        createdAt: '2024-01-15T14:30:00Z'
      },
      {
        id: 'insight_2',
        type: 'opportunity',
        title: 'Cost Reduction Opportunity Identified',
        description: 'Legal consultation agent shows 10% cost reduction potential',
        confidence: 0.92,
        impact: 'medium',
        timeframe: '2 weeks',
        affectedMetrics: ['Cost Per Conversion', 'Profit Margin'],
        recommendations: [
          'Implement smart model selection',
          'Optimize conversation flow',
          'Monitor cost trends closely'
        ],
        createdAt: '2024-01-15T13:45:00Z'
      },
      {
        id: 'insight_3',
        type: 'anomaly',
        title: 'Unusual Spike in Call Volume',
        description: 'Detected 25% increase in call volume for solar agent',
        confidence: 0.78,
        impact: 'medium',
        timeframe: '3 days',
        affectedMetrics: ['Call Volume', 'Response Time', 'Cost'],
        recommendations: [
          'Investigate cause of volume spike',
          'Scale infrastructure if needed',
          'Monitor for sustained increase'
        ],
        createdAt: '2024-01-15T12:00:00Z'
      }
    ];

    const sampleScenarios: ScenarioAnalysis[] = [
      {
        id: 'scenario_1',
        name: 'F45 Fitness Growth Scenarios',
        description: 'Different growth scenarios for F45 trial booking agent',
        scenario: 'optimistic',
        probability: 0.25,
        outcomes: [
          { metric: 'Conversion Rate', currentValue: 0.215, predictedValue: 0.28, change: 0.065 },
          { metric: 'Monthly Revenue', currentValue: 45000, predictedValue: 58000, change: 13000 },
          { metric: 'Cost Per Conversion', currentValue: 2.85, predictedValue: 2.45, change: -0.40 }
        ],
        assumptions: [
          'Strong seasonal fitness trends continue',
          'No major competitors enter market',
          'Marketing budget increased by 20%'
        ],
        createdAt: '2024-01-15T10:00:00Z'
      },
      {
        id: 'scenario_2',
        name: 'Legal Consultation Cost Scenarios',
        description: 'Cost optimization scenarios for legal consultation agent',
        scenario: 'realistic',
        probability: 0.50,
        outcomes: [
          { metric: 'Cost Per Conversion', currentValue: 3.85, predictedValue: 3.45, change: -0.40 },
          { metric: 'Monthly Savings', currentValue: 0, predictedValue: 2500, change: 2500 },
          { metric: 'Profit Margin', currentValue: 0.35, predictedValue: 0.42, change: 0.07 }
        ],
        assumptions: [
          'Smart model selection implemented',
          'Conversation flow optimized',
          'Volume remains stable'
        ],
        createdAt: '2024-01-15T11:00:00Z'
      }
    ];

    setForecasts(sampleForecasts);
    setInsights(sampleInsights);
    setScenarios(sampleScenarios);
  }, []);

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-4 h-4 text-green-400" />;
      case 'down': return <TrendingDown className="w-4 h-4 text-red-400" />;
      case 'stable': return <Minus className="w-4 h-4 text-gray-400" />;
      default: return <Minus className="w-4 h-4 text-gray-400" />;
    }
  };

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case 'up': return 'text-green-400';
      case 'down': return 'text-red-400';
      case 'stable': return 'text-gray-400';
      default: return 'text-gray-400';
    }
  };

  const getInsightTypeColor = (type: string) => {
    switch (type) {
      case 'trend': return 'text-blue-400 bg-blue-100';
      case 'anomaly': return 'text-red-400 bg-red-100';
      case 'opportunity': return 'text-green-400 bg-green-100';
      case 'risk': return 'text-yellow-400 bg-yellow-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const getScenarioColor = (scenario: string) => {
    switch (scenario) {
      case 'optimistic': return 'text-green-400 bg-green-100';
      case 'realistic': return 'text-blue-400 bg-blue-100';
      case 'pessimistic': return 'text-red-400 bg-red-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const renderOverviewTab = () => (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Active Forecasts</p>
              <p className="text-2xl font-bold text-foreground">{forecasts.length}</p>
            </div>
            <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-primary" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Avg Confidence</p>
              <p className="text-2xl font-bold text-foreground">
                {Math.round(forecasts.reduce((acc, f) => acc + f.confidence, 0) / forecasts.length * 100)}%
              </p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <Target className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Insights Generated</p>
              <p className="text-2xl font-bold text-foreground">{insights.length}</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Brain className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Scenario Models</p>
              <p className="text-2xl font-bold text-foreground">{scenarios.length}</p>
            </div>
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <BarChart3 className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Recent Insights */}
      <div className="card p-6">
        <h2 className="text-xl font-semibold text-foreground mb-6">Recent Insights</h2>
        <div className="space-y-4">
          {insights.slice(0, 3).map((insight) => (
            <div key={insight.id} className="flex items-start justify-between p-4 bg-secondary rounded-lg">
              <div className="flex items-start space-x-4">
                <div className={`w-3 h-3 rounded-full mt-2 ${getInsightTypeColor(insight.type).split(' ')[0]}`}></div>
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <h3 className="font-medium text-foreground">{insight.title}</h3>
                    <div className={`px-2 py-1 rounded-full text-xs font-medium ${getInsightTypeColor(insight.type)}`}>
                      {insight.type}
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{insight.description}</p>
                  <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                    <span>Confidence: {Math.round(insight.confidence * 100)}%</span>
                    <span>Impact: {insight.impact}</span>
                    <span>Timeframe: {insight.timeframe}</span>
                  </div>
                </div>
              </div>
              <button className="btn btn-outline btn-sm">
                <Eye className="w-4 h-4 mr-2" />
                View
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderForecastsTab = () => (
    <div className="space-y-6">
      {/* Forecasts */}
      <div className="space-y-4">
        {forecasts.map((forecast) => (
          <div key={forecast.id} className="card p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="text-lg font-semibold text-foreground">{forecast.name}</h3>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                    forecast.confidence > 0.9 ? 'text-green-400 bg-green-100' :
                    forecast.confidence > 0.8 ? 'text-blue-400 bg-blue-100' :
                    'text-yellow-400 bg-yellow-100'
                  }`}>
                    {Math.round(forecast.confidence * 100)}% confidence
                  </div>
                </div>
                <p className="text-muted-foreground mb-3">{forecast.description}</p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Current Value</p>
                    <p className="text-lg font-bold text-foreground">
                      {forecast.metric === 'Conversion Rate' ? `${(forecast.currentValue * 100).toFixed(1)}%` : `$${forecast.currentValue.toFixed(2)}`}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Predicted Value</p>
                    <p className="text-lg font-bold text-blue-400">
                      {forecast.metric === 'Conversion Rate' ? `${(forecast.predictedValue * 100).toFixed(1)}%` : `$${forecast.predictedValue.toFixed(2)}`}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Change</p>
                    <div className="flex items-center space-x-1">
                      {getTrendIcon(forecast.trend)}
                      <span className={`text-lg font-bold ${getTrendColor(forecast.trend)}`}>
                        {forecast.changePercent > 0 ? '+' : ''}{forecast.changePercent.toFixed(1)}%
                      </span>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Timeframe</p>
                    <p className="text-lg font-bold text-foreground">{forecast.timeframe}</p>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <button className="btn btn-outline btn-sm">
                  <Eye className="w-4 h-4 mr-2" />
                  Details
                </button>
                <button className="btn btn-outline btn-sm">
                  <Download className="w-4 h-4 mr-2" />
                  Export
                </button>
              </div>
            </div>

            {/* Forecast Chart Placeholder */}
            <div className="mt-4 p-4 bg-secondary rounded-lg">
              <h4 className="font-medium text-foreground mb-2">Forecast Trend</h4>
              <div className="h-32 bg-muted rounded flex items-center justify-center">
                <p className="text-muted-foreground">Interactive chart would be displayed here</p>
              </div>
            </div>

            {/* Key Factors */}
            <div className="mt-4">
              <h4 className="font-medium text-foreground mb-2">Key Factors</h4>
              <div className="space-y-2">
                {forecast.factors.map((factor, idx) => (
                  <div key={idx} className="flex items-center justify-between p-2 bg-muted rounded">
                    <div>
                      <p className="text-sm font-medium text-foreground">{factor.name}</p>
                      <p className="text-xs text-muted-foreground">{factor.description}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                        factor.impact === 'high' ? 'text-red-400 bg-red-100' :
                        factor.impact === 'medium' ? 'text-yellow-400 bg-yellow-100' :
                        'text-green-400 bg-green-100'
                      }`}>
                        {factor.impact}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {Math.round(factor.weight * 100)}%
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recommendations */}
            <div className="mt-4">
              <h4 className="font-medium text-foreground mb-2">Recommendations</h4>
              <div className="space-y-2">
                {forecast.recommendations.map((rec, idx) => (
                  <div key={idx} className="p-3 bg-muted rounded-lg">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="font-medium text-foreground">{rec.action}</p>
                        <p className="text-sm text-muted-foreground">{rec.description}</p>
                      </div>
                      <div className="flex items-center space-x-2 ml-4">
                        <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                          rec.impact === 'high' ? 'text-red-400 bg-red-100' :
                          rec.impact === 'medium' ? 'text-yellow-400 bg-yellow-100' :
                          'text-green-400 bg-green-100'
                        }`}>
                          {rec.impact}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {rec.timeframe}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="p-6 bg-background min-h-screen text-foreground">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text mb-2">Predictive Analytics</h1>
            <p className="text-muted-foreground">
              AI-powered forecasting and predictive insights for voice AI performance
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <button className="btn btn-outline">
              <Download className="w-4 h-4 mr-2" />
              Export Data
            </button>
            <button className="btn btn-outline">
              <Settings className="w-4 h-4 mr-2" />
              Model Settings
            </button>
            <button className="btn btn-primary">
              <Plus className="w-4 h-4 mr-2" />
              New Forecast
            </button>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="mb-6">
        <div className="flex space-x-1 bg-secondary p-1 rounded-lg w-fit">
          {[
            { id: 'overview', label: 'Overview', icon: BarChart3 },
            { id: 'forecasts', label: 'Forecasts', icon: TrendingUp },
            { id: 'insights', label: 'Insights', icon: Brain },
            { id: 'scenarios', label: 'Scenarios', icon: Target },
            { id: 'models', label: 'Models', icon: Cog }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-primary text-primary-foreground shadow-lg'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      {activeTab === 'overview' && renderOverviewTab()}
      {activeTab === 'forecasts' && renderForecastsTab()}
      {activeTab === 'insights' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Prediction Insights</h2>
          <p className="text-muted-foreground">AI-generated insights and recommendations will be displayed here.</p>
        </div>
      )}
      {activeTab === 'scenarios' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Scenario Analysis</h2>
          <p className="text-muted-foreground">What-if scenario analysis interface will be displayed here.</p>
        </div>
      )}
      {activeTab === 'models' && (
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Prediction Models</h2>
          <p className="text-muted-foreground">Machine learning model management interface will be displayed here.</p>
        </div>
      )}
    </div>
  );
};

export default PredictiveAnalytics;
